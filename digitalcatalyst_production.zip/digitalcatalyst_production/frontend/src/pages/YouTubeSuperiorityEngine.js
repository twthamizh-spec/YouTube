import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Play, Eye, Clock, Target, Trophy, Zap, TrendingUp, AlertTriangle } from 'lucide-react';
import { Button } from '../components/ui/button';

const YouTubeSuperiorityEngine = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('hooks');

  const createWithHook = (hookPattern, format = 'Shorts') => {
    navigate('/creative-studio', {
      state: {
        source: 'YouTube Engine',
        hook: hookPattern.pattern,
        hookExample: hookPattern.example,
        format: format === 'Shorts' ? 'Shorts (45s)' : 'Long-form (8m)',
        aspectRatio: format === 'Shorts' ? '9:16' : '16:9',
        captionStyle: 'pop',
        bestFor: hookPattern.bestFor,
        expectedRetention: hookPattern.avgRetention
      }
    });
  };

  const createFromFormat = (format) => {
    navigate('/creative-studio', {
      state: {
        source: 'YouTube Engine',
        format: format.format,
        platform: format.platform,
        aspectRatio: format.platform === 'Shorts' ? '9:16' : '16:9',
        captionStyle: 'pop',
        expectedViews: format.avgViews,
        difficulty: format.difficulty
      }
    });
  };

  // Hook Analysis Data
  const hookPatterns = [
    {
      pattern: 'Problem → Solution',
      example: '"Struggling with views? Here\'s what changed everything..."',
      avgRetention: '78%',
      effectiveness: 'Very High',
      bestFor: 'Tutorial, How-to'
    },
    {
      pattern: 'Shocking Statement',
      example: '"This AI tool replaced my entire team..."',
      avgRetention: '85%',
      effectiveness: 'Very High',
      bestFor: 'Tech, Business'
    },
    {
      pattern: 'Question Hook',
      example: '"Want to 10x your productivity in 2025?"',
      avgRetention: '62%',
      effectiveness: 'Medium',
      bestFor: 'Lifestyle, Self-help'
    },
    {
      pattern: 'Pattern Interrupt',
      example: '"STOP doing this right now..."',
      avgRetention: '91%',
      effectiveness: 'Extreme',
      bestFor: 'Finance, Career'
    }
  ];

  // Retention Analysis
  const retentionInsights = [
    {
      timeRange: '0-3 seconds',
      criticalPoint: 'Hook',
      avgDropoff: '45%',
      recommendation: 'Use pattern interrupt or shocking visual',
      priority: 'Critical'
    },
    {
      timeRange: '3-10 seconds',
      criticalPoint: 'Promise',
      avgDropoff: '25%',
      recommendation: 'State clear value proposition',
      priority: 'High'
    },
    {
      timeRange: '10-30 seconds',
      criticalPoint: 'Delivery',
      avgDropoff: '15%',
      recommendation: 'Fast-paced editing, no fluff',
      priority: 'High'
    },
    {
      timeRange: '30-60 seconds',
      criticalPoint: 'Engagement',
      avgDropoff: '10%',
      recommendation: 'Visual variety, B-roll',
      priority: 'Medium'
    }
  ];

  // Viral Format Analysis
  const viralFormats = [
    {
      format: 'Before/After Transformation',
      platform: 'Shorts',
      avgViews: '2.4M',
      avgRetention: '89%',
      difficulty: 'Easy',
      saturation: 'Medium',
      signal: 'Hot'
    },
    {
      format: 'Quick Tutorial (30-60s)',
      platform: 'Shorts',
      avgViews: '1.8M',
      avgRetention: '76%',
      difficulty: 'Easy',
      saturation: 'High',
      signal: 'Warm'
    },
    {
      format: 'Myth Debunking',
      platform: 'Long-form',
      avgViews: '890K',
      avgRetention: '68%',
      difficulty: 'Medium',
      saturation: 'Low',
      signal: 'Hot'
    },
    {
      format: 'Day in the Life',
      platform: 'Long-form',
      avgViews: '1.2M',
      avgRetention: '55%',
      difficulty: 'Hard',
      saturation: 'Very High',
      signal: 'Cold'
    },
    {
      format: 'AI Tool Showcase',
      platform: 'Shorts',
      avgViews: '3.1M',
      avgRetention: '92%',
      difficulty: 'Easy',
      saturation: 'Low',
      signal: 'Extreme Hot'
    }
  ];

  // Competitor Analysis
  const topPerformers = [
    {
      niche: 'AI/Tech',
      avgViews: '2.8M',
      topHook: 'Problem → AI Solution',
      avgLength: '45s',
      postingFrequency: '3x/day',
      bestTime: '6-8 PM EST'
    },
    {
      niche: 'Finance',
      avgViews: '1.9M',
      topHook: 'Money Mistake',
      avgLength: '8m',
      postingFrequency: '1x/day',
      bestTime: '7-9 AM EST'
    },
    {
      niche: 'Productivity',
      avgViews: '1.5M',
      topHook: 'STOP doing X',
      avgLength: '35s',
      postingFrequency: '2x/day',
      bestTime: '12-2 PM EST'
    }
  ];

  // Title/Thumbnail Patterns
  const winningPatterns = [
    {
      type: 'Title',
      pattern: '[Number] + [Benefit] + [Timeframe]',
      example: '5 AI Tools That Will Save You 10 Hours',
      clickRate: '12.4%'
    },
    {
      type: 'Title',
      pattern: '[Negative] + [Problem] + [Solution]',
      example: 'STOP Wasting Time - Use This Instead',
      clickRate: '15.8%'
    },
    {
      type: 'Thumbnail',
      pattern: 'Before/After Split',
      example: 'Left side: chaos, Right side: organized',
      clickRate: '18.2%'
    },
    {
      type: 'Thumbnail',
      pattern: 'Face + Text Overlay',
      example: 'Shocked face + "This Changed Everything"',
      clickRate: '16.5%'
    }
  ];

  const getEffectivenessColor = (effectiveness) => {
    if (effectiveness === 'Very High' || effectiveness === 'Extreme') return 'text-green-400';
    if (effectiveness === 'Medium') return 'text-yellow-400';
    return 'text-red-400';
  };

  const getPriorityBadge = (priority) => {
    if (priority === 'Critical') {
      return <span className="px-2 py-1 rounded text-xs font-bold bg-red-500/20 text-red-400">Critical</span>;
    }
    if (priority === 'High') {
      return <span className="px-2 py-1 rounded text-xs font-bold bg-orange-500/20 text-orange-400">High</span>;
    }
    return <span className="px-2 py-1 rounded text-xs font-bold bg-blue-500/20 text-blue-400">Medium</span>;
  };

  const getSignalBadge = (signal) => {
    if (signal === 'Extreme Hot' || signal === 'Hot') {
      return <span className="px-3 py-1 rounded-full text-xs font-bold bg-red-500/20 text-red-400">🔥 {signal}</span>;
    }
    if (signal === 'Warm') {
      return <span className="px-3 py-1 rounded-full text-xs font-bold bg-yellow-500/20 text-yellow-400">⚡ {signal}</span>;
    }
    return <span className="px-3 py-1 rounded-full text-xs font-bold bg-blue-500/20 text-blue-400">❄️ {signal}</span>;
  };

  return (
    <div className="p-8 max-w-[1800px] mx-auto fade-in">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
          <Trophy className="text-primary" />
          YouTube Superiority Engine
        </h1>
        <p className="text-muted-foreground">Hook engineering, retention modeling & viral format identification</p>
      </div>

      {/* Tab Navigation */}
      <div className="glass-panel p-4 mb-6">
        <div className="flex gap-4">
          {[
            { id: 'hooks', label: 'Hook Analysis', icon: Target },
            { id: 'retention', label: 'Retention Curves', icon: TrendingUp },
            { id: 'formats', label: 'Viral Formats', icon: Zap },
            { id: 'competitors', label: 'Top Performers', icon: Trophy }
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <Button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={activeTab === tab.id ? 'btn-primary' : 'btn-secondary'}
              >
                <Icon size={18} className="mr-2" />
                {tab.label}
              </Button>
            );
          })}
        </div>
      </div>

      {/* Hook Analysis Tab */}
      {activeTab === 'hooks' && (
        <div className="space-y-6">
          <div className="glass-panel p-6">
            <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
              <Target className="text-primary" />
              High-Performing Hook Patterns
            </h2>
            <div className="space-y-4">
              {hookPatterns.map((hook, idx) => (
                <div key={idx} className="p-5 bg-background/50 rounded-lg border border-border hover:border-primary/50 transition-colors">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h3 className="font-bold text-lg mb-1">{hook.pattern}</h3>
                      <p className="text-sm italic text-muted-foreground">"{hook.example}"</p>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-bold ${getEffectivenessColor(hook.effectiveness)}`}>
                      {hook.effectiveness}
                    </span>
                  </div>
                  <div className="grid grid-cols-4 gap-4 text-sm">
                    <div>
                      <div className="text-muted-foreground text-xs mb-1">Avg Retention</div>
                      <div className="font-bold text-green-400">{hook.avgRetention}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground text-xs mb-1">Best For</div>
                      <div className="font-semibold">{hook.bestFor}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground text-xs mb-1">Effectiveness</div>
                      <div className={`font-bold ${getEffectivenessColor(hook.effectiveness)}`}>
                        {hook.effectiveness}
                      </div>
                    </div>
                    <div className="flex items-end justify-end">
                      <Button
                        onClick={() => createWithHook(hook)}
                        className="btn-primary text-xs px-3 py-1 h-auto"
                        size="sm"
                      >
                        Use Hook →
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Title/Thumbnail Patterns */}
          <div className="glass-panel p-6">
            <h2 className="text-2xl font-bold mb-4">Winning Title & Thumbnail Patterns</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {winningPatterns.map((pattern, idx) => (
                <div key={idx} className="p-4 bg-background/50 rounded-lg border border-border">
                  <div className="flex items-center justify-between mb-2">
                    <span className="px-2 py-1 rounded text-xs bg-primary/20 text-primary font-semibold">
                      {pattern.type}
                    </span>
                    <span className="text-sm font-bold text-green-400">{pattern.clickRate} CTR</span>
                  </div>
                  <h3 className="font-semibold mb-1">{pattern.pattern}</h3>
                  <p className="text-xs text-muted-foreground italic">Example: "{pattern.example}"</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Retention Analysis Tab */}
      {activeTab === 'retention' && (
        <div className="glass-panel p-6">
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
            <TrendingUp className="text-primary" />
            Retention Curve Critical Points
          </h2>
          <p className="text-sm text-muted-foreground mb-6">
            Focus on these key moments to maximize audience retention
          </p>
          <div className="space-y-4">
            {retentionInsights.map((insight, idx) => (
              <div key={idx} className="p-5 bg-background/50 rounded-lg border border-border">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h3 className="font-bold text-lg">{insight.timeRange}</h3>
                    <span className="text-sm text-muted-foreground">{insight.criticalPoint}</span>
                  </div>
                  <div className="text-right">
                    {getPriorityBadge(insight.priority)}
                    <div className="text-sm text-red-400 font-bold mt-1">
                      {insight.avgDropoff} dropoff
                    </div>
                  </div>
                </div>
                <div className="p-3 bg-primary/10 rounded border-l-4 border-primary">
                  <div className="text-xs text-muted-foreground mb-1">Recommendation:</div>
                  <div className="font-semibold">{insight.recommendation}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Visual Retention Curve (Mock) */}
          <div className="mt-8 p-6 bg-background/50 rounded-lg border border-border">
            <h3 className="font-bold mb-4">Average Retention Curve (Shorts)</h3>
            <div className="h-64 flex items-end gap-2">
              {[100, 85, 72, 65, 58, 52, 48, 45, 42, 40].map((val, idx) => (
                <div key={idx} className="flex-1 flex flex-col items-center gap-1">
                  <div 
                    className="w-full bg-gradient-to-t from-primary to-accent rounded-t"
                    style={{ height: `${val}%` }}
                  />
                  <span className="text-xs text-muted-foreground">{idx * 6}s</span>
                </div>
              ))}
            </div>
            <div className="mt-4 text-xs text-muted-foreground text-center">
              First 3 seconds are critical - 45% average dropoff
            </div>
          </div>
        </div>
      )}

      {/* Viral Formats Tab */}
      {activeTab === 'formats' && (
        <div className="glass-panel p-6">
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
            <Zap className="text-accent" />
            Viral Format Rankings
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4">Format</th>
                  <th className="text-left py-3 px-4">Platform</th>
                  <th className="text-left py-3 px-4">Avg Views</th>
                  <th className="text-left py-3 px-4">Retention</th>
                  <th className="text-left py-3 px-4">Difficulty</th>
                  <th className="text-left py-3 px-4">Saturation</th>
                  <th className="text-left py-3 px-4">Signal</th>
                </tr>
              </thead>
              <tbody>
                {viralFormats.map((format, idx) => (
                  <tr key={idx} className="border-b border-border/50 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-4 font-semibold">{format.format}</td>
                    <td className="py-4 px-4">
                      <span className="px-2 py-1 rounded text-xs bg-primary/20 text-primary">
                        {format.platform}
                      </span>
                    </td>
                    <td className="py-4 px-4 font-mono font-bold">{format.avgViews}</td>
                    <td className="py-4 px-4 text-green-400 font-bold">{format.avgRetention}</td>
                    <td className="py-4 px-4 text-sm">{format.difficulty}</td>
                    <td className="py-4 px-4 text-sm">{format.saturation}</td>
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-2">
                        {getSignalBadge(format.signal)}
                        {(format.signal === 'Extreme Hot' || format.signal === 'Hot') && (
                          <Button
                            onClick={() => createFromFormat(format)}
                            className="btn-primary text-xs px-3 py-1 h-auto"
                            size="sm"
                          >
                            Produce →
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Top Performers Tab */}
      {activeTab === 'competitors' && (
        <div className="glass-panel p-6">
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
            <Trophy className="text-primary" />
            Top Performers by Niche
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {topPerformers.map((performer, idx) => (
              <div key={idx} className="p-5 bg-background/50 rounded-lg border border-border">
                <h3 className="font-bold text-xl mb-4 text-primary">{performer.niche}</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Avg Views:</span>
                    <span className="font-bold">{performer.avgViews}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Top Hook:</span>
                    <span className="font-semibold">{performer.topHook}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Avg Length:</span>
                    <span className="font-semibold">{performer.avgLength}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Frequency:</span>
                    <span className="font-semibold">{performer.postingFrequency}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Best Time:</span>
                    <span className="font-semibold text-green-400">{performer.bestTime}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Info Banner */}
      <div className="glass-panel p-6 bg-primary/10 border border-primary/30 mt-6">
        <div className="flex items-start gap-4">
          <AlertTriangle className="text-primary mt-1" size={24} />
          <div>
            <h3 className="font-semibold mb-2">Dashboard Status: Mock Data</h3>
            <p className="text-sm text-muted-foreground">
              Currently displaying simulated performance data. YouTube Data API integration will provide real-time hook analysis, retention curves, and competitor insights in future updates.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default YouTubeSuperiorityEngine;
