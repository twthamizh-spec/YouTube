import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { toast } from 'sonner';
import { 
  Wand2, Image as ImageIcon, Film, Mic, Music, Play, Pause, 
  Square, Layers, Type, Trash2, Download, Upload, Save, 
  RotateCw, FlipHorizontal, FlipVertical, ZoomIn, ZoomOut, 
  Move, Scissors, Copy, ChevronUp, ChevronDown, Eye, EyeOff,
  Palette, Sliders, Clock, Volume2, VolumeX, Plus, Minus,
  Grid, Maximize, Settings, Sparkles, FileText, Video,
  GripVertical, Lock, Unlock, Loader2, Check, X, RefreshCw,
  Cpu, Brain, Zap, Target, Lightbulb, Camera, Speaker
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

// ============ UNIFIED CREATIVE INTELLIGENCE SYSTEM ============
const UnifiedCreativeStudio = () => {
  const { user } = useAuth();
  
  // ===== CORE STATE =====
  const [activeMode, setActiveMode] = useState('image'); // image, video, audio, timeline
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  
  // ===== LAYER SYSTEM =====
  const [layers, setLayers] = useState([]);
  const [selectedLayerId, setSelectedLayerId] = useState(null);
  const [layerCounter, setLayerCounter] = useState(0);
  
  // ===== CANVAS STATE =====
  const canvasRef = useRef(null);
  const [canvasSize, setCanvasSize] = useState({ width: 1280, height: 720 });
  const [zoom, setZoom] = useState(1);
  const [panOffset, setPanOffset] = useState({ x: 0, y: 0 });
  
  // ===== IMAGE GENERATION STATE =====
  const [imagePrompt, setImagePrompt] = useState('');
  const [imageStyle, setImageStyle] = useState('cinematic');
  const [imageAspectRatio, setImageAspectRatio] = useState('16:9');
  const [imageQuality, setImageQuality] = useState('high');
  const [negativePrompt, setNegativePrompt] = useState('');
  const [referenceImages, setReferenceImages] = useState([]);
  
  // ===== VIDEO GENERATION STATE =====
  const [scriptText, setScriptText] = useState('');
  const [scenes, setScenes] = useState([]);
  const [videoStyle, setVideoStyle] = useState('cinematic');
  const [videoDuration, setVideoDuration] = useState(4);
  
  // ===== AUDIO STATE =====
  const [voiceText, setVoiceText] = useState('');
  const [voiceStyle, setVoiceStyle] = useState('alloy');
  const [voiceSpeed, setVoiceSpeed] = useState(1.0);
  const [audioLayers, setAudioLayers] = useState([]);
  
  // ===== TIMELINE STATE =====
  const [timelinePosition, setTimelinePosition] = useState(0);
  const [timelineDuration, setTimelineDuration] = useState(60);
  const [isPlaying, setIsPlaying] = useState(false);
  const [timelineTracks, setTimelineTracks] = useState([
    { id: 'video', name: 'Video', type: 'video', clips: [] },
    { id: 'audio', name: 'Voice', type: 'audio', clips: [] },
    { id: 'music', name: 'Music', type: 'audio', clips: [] },
    { id: 'effects', name: 'Effects', type: 'effect', clips: [] }
  ]);
  
  // ===== EDITING STATE =====
  const [editMode, setEditMode] = useState('select'); // select, crop, mask, draw
  const [brushSize, setBrushSize] = useState(20);
  const [brushColor, setBrushColor] = useState('#ffffff');
  
  // ===== HISTORY =====
  const [history, setHistory] = useState([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  
  // ===== STYLE OPTIONS =====
  const styleOptions = [
    { id: 'cinematic', name: 'Cinematic', desc: 'Film-like dramatic lighting' },
    { id: 'photoreal', name: 'Photorealistic', desc: 'Hyper-realistic photography' },
    { id: 'product', name: 'Product', desc: 'Clean studio shots' },
    { id: 'illustration', name: 'Illustration', desc: 'Digital art style' },
    { id: 'minimal', name: 'Minimal', desc: 'Simple compositions' },
    { id: 'anime', name: 'Anime', desc: 'Japanese animation' },
    { id: 'fantasy', name: 'Fantasy', desc: 'Magical & ethereal' },
    { id: 'noir', name: 'Film Noir', desc: 'High contrast B&W' },
    { id: 'vintage', name: 'Vintage', desc: 'Retro film aesthetic' },
    { id: 'neon', name: 'Neon Cyberpunk', desc: 'Futuristic neon glow' }
  ];
  
  const aspectRatios = [
    { id: '1:1', name: '1:1 Square', width: 1024, height: 1024 },
    { id: '16:9', name: '16:9 Landscape', width: 1280, height: 720 },
    { id: '9:16', name: '9:16 Portrait', width: 720, height: 1280 },
    { id: '4:3', name: '4:3 Standard', width: 1024, height: 768 },
    { id: '3:2', name: '3:2 Photo', width: 1080, height: 720 },
    { id: '21:9', name: '21:9 Ultrawide', width: 1920, height: 820 }
  ];
  
  const voiceOptions = [
    { id: 'alloy', name: 'Alloy', desc: 'Neutral & balanced' },
    { id: 'echo', name: 'Echo', desc: 'Warm & engaging' },
    { id: 'fable', name: 'Fable', desc: 'British accent' },
    { id: 'onyx', name: 'Onyx', desc: 'Deep & authoritative' },
    { id: 'nova', name: 'Nova', desc: 'Friendly & upbeat' },
    { id: 'shimmer', name: 'Shimmer', desc: 'Soft & expressive' }
  ];

  // ===== LAYER MANAGEMENT =====
  const addLayer = useCallback((type, data) => {
    const newLayer = {
      id: `layer-${layerCounter}`,
      type, // 'image', 'text', 'video', 'audio', 'effect'
      name: `${type.charAt(0).toUpperCase() + type.slice(1)} ${layerCounter + 1}`,
      visible: true,
      locked: false,
      opacity: 100,
      blendMode: 'normal',
      position: { x: 0, y: 0 },
      size: { width: canvasSize.width, height: canvasSize.height },
      rotation: 0,
      filters: {
        brightness: 100,
        contrast: 100,
        saturation: 100,
        blur: 0,
        hue: 0
      },
      data
    };
    
    setLayers(prev => [newLayer, ...prev]);
    setLayerCounter(prev => prev + 1);
    setSelectedLayerId(newLayer.id);
    saveToHistory();
    return newLayer.id;
  }, [layerCounter, canvasSize]);

  const updateLayer = useCallback((layerId, updates) => {
    setLayers(prev => prev.map(layer => 
      layer.id === layerId ? { ...layer, ...updates } : layer
    ));
  }, []);

  const deleteLayer = useCallback((layerId) => {
    setLayers(prev => prev.filter(layer => layer.id !== layerId));
    if (selectedLayerId === layerId) {
      setSelectedLayerId(null);
    }
    saveToHistory();
  }, [selectedLayerId]);

  const moveLayer = useCallback((layerId, direction) => {
    setLayers(prev => {
      const index = prev.findIndex(l => l.id === layerId);
      if (index === -1) return prev;
      
      const newIndex = direction === 'up' ? index - 1 : index + 1;
      if (newIndex < 0 || newIndex >= prev.length) return prev;
      
      const newLayers = [...prev];
      [newLayers[index], newLayers[newIndex]] = [newLayers[newIndex], newLayers[index]];
      return newLayers;
    });
    saveToHistory();
  }, []);

  // ===== HISTORY MANAGEMENT =====
  const saveToHistory = useCallback(() => {
    const state = { layers, timelineTracks, scenes };
    setHistory(prev => [...prev.slice(0, historyIndex + 1), state]);
    setHistoryIndex(prev => prev + 1);
  }, [layers, timelineTracks, scenes, historyIndex]);

  const undo = useCallback(() => {
    if (historyIndex > 0) {
      const prevState = history[historyIndex - 1];
      setLayers(prevState.layers);
      setTimelineTracks(prevState.timelineTracks);
      setScenes(prevState.scenes);
      setHistoryIndex(prev => prev - 1);
    }
  }, [history, historyIndex]);

  const redo = useCallback(() => {
    if (historyIndex < history.length - 1) {
      const nextState = history[historyIndex + 1];
      setLayers(nextState.layers);
      setTimelineTracks(nextState.timelineTracks);
      setScenes(nextState.scenes);
      setHistoryIndex(prev => prev + 1);
    }
  }, [history, historyIndex]);

  // ===== AI IMAGE GENERATION =====
  const generateImage = async () => {
    if (!imagePrompt.trim()) {
      toast.error('Enter a prompt to generate');
      return;
    }

    setIsGenerating(true);
    setGenerationProgress(10);
    toast.info('🎨 Generating AI image...');

    try {
      // Build enhanced prompt
      const styleModifier = styleOptions.find(s => s.id === imageStyle)?.desc || '';
      const enhancedPrompt = `${imagePrompt}. Style: ${styleModifier}. ${imageQuality === 'high' ? 'High quality, detailed, professional.' : ''}${negativePrompt ? ` Avoid: ${negativePrompt}` : ''}`;
      
      setGenerationProgress(30);
      
      const response = await fetch(`${BACKEND_URL}/api/generate/image`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: enhancedPrompt,
          style: imageStyle,
          aspect_ratio: imageAspectRatio
        })
      });

      setGenerationProgress(70);

      if (!response.ok) {
        throw new Error('Image generation failed');
      }

      const data = await response.json();
      
      if (data.success && data.image_base64) {
        setGenerationProgress(90);
        
        // Add as editable layer
        const ratio = aspectRatios.find(r => r.id === imageAspectRatio);
        addLayer('image', {
          base64: data.image_base64,
          prompt: imagePrompt,
          style: imageStyle,
          width: ratio?.width || 1024,
          height: ratio?.height || 1024
        });
        
        setGenerationProgress(100);
        toast.success('✨ Image generated and added as editable layer!');
      } else {
        throw new Error('No image data received');
      }
    } catch (error) {
      console.error('Image generation error:', error);
      toast.error(`Generation failed: ${error.message}`);
    } finally {
      setIsGenerating(false);
      setGenerationProgress(0);
    }
  };

  // ===== SCRIPT TO SCENES =====
  const generateScript = async () => {
    if (!scriptText.trim()) {
      toast.error('Enter text or topic for script');
      return;
    }

    setIsGenerating(true);
    toast.info('📝 Generating AI script...');

    try {
      const response = await fetch(`${BACKEND_URL}/api/script/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: scriptText,
          hook_style: 'Problem → Solution',
          format: 'Shorts (45s)',
          platform: 'YouTube Shorts',
          language: 'English'
        })
      });

      if (!response.ok) throw new Error('Script generation failed');
      
      const data = await response.json();
      
      if (data.success && data.script) {
        // Parse script into scenes
        const sceneMatches = data.script.match(/SCENE \d+:.*?(?=SCENE \d+:|$)/gs) || [data.script];
        const parsedScenes = sceneMatches.map((scene, index) => ({
          id: `scene-${index}`,
          content: scene.trim(),
          duration: 5,
          visualDescription: scene.match(/Visual: (.+)/)?.[1] || 'Generate visual',
          status: 'pending',
          imageBase64: null,
          videoBase64: null
        }));
        
        setScenes(parsedScenes);
        toast.success(`✨ Script generated with ${parsedScenes.length} scenes!`);
      }
    } catch (error) {
      toast.error(`Script generation failed: ${error.message}`);
    } finally {
      setIsGenerating(false);
    }
  };

  // ===== SCENE TO IMAGE =====
  const generateSceneImage = async (sceneId) => {
    const scene = scenes.find(s => s.id === sceneId);
    if (!scene) return;

    setScenes(prev => prev.map(s => 
      s.id === sceneId ? { ...s, status: 'generating' } : s
    ));

    try {
      const response = await fetch(`${BACKEND_URL}/api/generate/image`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: scene.visualDescription,
          style: videoStyle,
          aspect_ratio: '16:9'
        })
      });

      if (!response.ok) throw new Error('Scene image generation failed');
      
      const data = await response.json();
      
      if (data.success && data.image_base64) {
        setScenes(prev => prev.map(s => 
          s.id === sceneId ? { ...s, status: 'ready', imageBase64: data.image_base64 } : s
        ));
        toast.success(`Scene ${sceneId} image ready!`);
      }
    } catch (error) {
      setScenes(prev => prev.map(s => 
        s.id === sceneId ? { ...s, status: 'failed' } : s
      ));
      toast.error(`Scene generation failed: ${error.message}`);
    }
  };

  // ===== GENERATE ALL SCENE IMAGES =====
  const generateAllSceneImages = async () => {
    for (const scene of scenes) {
      if (scene.status === 'pending' || scene.status === 'failed') {
        await generateSceneImage(scene.id);
        await new Promise(r => setTimeout(r, 1000)); // Rate limiting
      }
    }
    toast.success('All scenes generated!');
  };

  // ===== AI VOICE GENERATION =====
  const generateVoice = async () => {
    if (!voiceText.trim()) {
      toast.error('Enter text for voice generation');
      return;
    }

    setIsGenerating(true);
    toast.info('🎤 Generating AI voice...');

    try {
      const response = await fetch(`${BACKEND_URL}/api/generate/voice`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: voiceText,
          voice: voiceStyle,
          speed: voiceSpeed
        })
      });

      if (!response.ok) throw new Error('Voice generation failed');
      
      const data = await response.json();
      
      if (data.success && data.audio_base64) {
        // Add to audio layers
        setAudioLayers(prev => [...prev, {
          id: `audio-${Date.now()}`,
          type: 'voice',
          name: `Voice ${audioLayers.length + 1}`,
          base64: data.audio_base64,
          text: voiceText,
          voice: voiceStyle,
          startTime: 0,
          duration: 10 // Will be calculated from audio
        }]);
        
        // Add to timeline
        setTimelineTracks(prev => prev.map(track => {
          if (track.id === 'audio') {
            return {
              ...track,
              clips: [...track.clips, {
                id: `clip-${Date.now()}`,
                name: `Voice ${track.clips.length + 1}`,
                start: timelinePosition,
                duration: 10,
                data: { base64: data.audio_base64, text: voiceText }
              }]
            };
          }
          return track;
        }));
        
        toast.success('✨ Voice generated and added to timeline!');
      }
    } catch (error) {
      toast.error(`Voice generation failed: ${error.message}`);
    } finally {
      setIsGenerating(false);
    }
  };

  // ===== MUSIC GENERATION =====
  const [musicPrompt, setMusicPrompt] = useState('');
  const [musicStyle, setMusicStyle] = useState('cinematic');
  const [musicDuration, setMusicDuration] = useState(30);

  const musicStyles = [
    { id: 'cinematic', name: 'Cinematic' },
    { id: 'upbeat', name: 'Upbeat' },
    { id: 'calm', name: 'Calm/Ambient' },
    { id: 'electronic', name: 'Electronic' },
    { id: 'acoustic', name: 'Acoustic' },
    { id: 'epic', name: 'Epic/Orchestral' }
  ];

  const generateMusic = async () => {
    if (!musicPrompt.trim()) {
      toast.error('Enter a description for music generation');
      return;
    }

    setIsGenerating(true);
    toast.info('🎵 Generating AI music...');

    try {
      const response = await fetch(`${BACKEND_URL}/api/generate/music`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: musicPrompt,
          style: musicStyle,
          duration: musicDuration
        })
      });

      if (!response.ok) throw new Error('Music generation failed');
      
      const data = await response.json();
      
      if (data.success && data.music_base64) {
        // Add to timeline music track
        setTimelineTracks(prev => prev.map(track => {
          if (track.id === 'music') {
            return {
              ...track,
              clips: [...track.clips, {
                id: `music-${Date.now()}`,
                name: `Music ${track.clips.length + 1}`,
                start: 0,
                duration: musicDuration,
                data: { base64: data.music_base64, prompt: musicPrompt }
              }]
            };
          }
          return track;
        }));
        
        toast.success('🎵 Music generated and added to timeline!');
      }
    } catch (error) {
      toast.error(`Music generation failed: ${error.message}`);
    } finally {
      setIsGenerating(false);
    }
  };

  // ===== ASSEMBLE VIDEO FROM SCENES =====
  const [assembledVideo, setAssembledVideo] = useState(null);

  const assembleVideo = async () => {
    const readyScenes = scenes.filter(s => s.status === 'ready' && s.imageBase64);
    if (readyScenes.length === 0) {
      toast.error('No ready scenes to assemble');
      return;
    }

    setIsGenerating(true);
    toast.info('🎬 Assembling video from scenes...');

    try {
      // Get voice audio if available
      const voiceTrack = timelineTracks.find(t => t.id === 'audio');
      const voiceClip = voiceTrack?.clips[0];
      
      const response = await fetch(`${BACKEND_URL}/api/video/assemble`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          scenes: readyScenes.map(s => ({
            image_base64: s.imageBase64,
            duration: s.duration
          })),
          audio_base64: voiceClip?.data?.base64 || null,
          fps: 30
        })
      });

      if (!response.ok) throw new Error('Video assembly failed');
      
      const data = await response.json();
      
      if (data.success && data.video_base64) {
        setAssembledVideo(data.video_base64);
        toast.success(`🎬 Video assembled! ${data.scene_count} scenes, ${data.total_duration}s total`);
      }
    } catch (error) {
      toast.error(`Video assembly failed: ${error.message}`);
    } finally {
      setIsGenerating(false);
    }
  };

  // ===== ADD SCENES TO TIMELINE =====
  const addScenesToTimeline = () => {
    const readyScenes = scenes.filter(s => s.status === 'ready' && s.imageBase64);
    if (readyScenes.length === 0) {
      toast.error('No ready scenes to add');
      return;
    }

    let currentTime = 0;
    const newClips = readyScenes.map((scene, index) => {
      const clip = {
        id: `clip-${Date.now()}-${index}`,
        name: `Scene ${index + 1}`,
        start: currentTime,
        duration: scene.duration,
        data: { imageBase64: scene.imageBase64, content: scene.content }
      };
      currentTime += scene.duration;
      return clip;
    });

    setTimelineTracks(prev => prev.map(track => {
      if (track.id === 'video') {
        return { ...track, clips: [...track.clips, ...newClips] };
      }
      return track;
    }));

    setTimelineDuration(Math.max(timelineDuration, currentTime + 10));
    toast.success(`Added ${newClips.length} scenes to timeline!`);
  };

  // ===== REFERENCE IMAGE UPLOAD =====
  const handleReferenceUpload = (e) => {
    const files = Array.from(e.target.files);
    files.forEach(file => {
      const reader = new FileReader();
      reader.onload = () => {
        setReferenceImages(prev => [...prev, {
          id: `ref-${Date.now()}-${Math.random()}`,
          name: file.name,
          base64: reader.result.split(',')[1],
          preview: reader.result
        }]);
      };
      reader.readAsDataURL(file);
    });
  };

  // ===== CANVAS RENDERING =====
  const renderCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Draw background
    ctx.fillStyle = '#1a1a2e';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Draw layers (bottom to top)
    const layersToRender = [...layers].reverse();
    
    const renderLayer = async (layer) => {
      if (!layer.visible) return;
      
      ctx.save();
      ctx.globalAlpha = layer.opacity / 100;
      ctx.translate(layer.position.x, layer.position.y);
      ctx.rotate((layer.rotation * Math.PI) / 180);
      
      // Apply filters
      ctx.filter = `brightness(${layer.filters.brightness}%) contrast(${layer.filters.contrast}%) saturate(${layer.filters.saturation}%) blur(${layer.filters.blur}px) hue-rotate(${layer.filters.hue}deg)`;
      
      if (layer.type === 'image' && layer.data.base64) {
        const img = new Image();
        img.src = `data:image/png;base64,${layer.data.base64}`;
        await new Promise((resolve) => {
          if (img.complete) {
            ctx.drawImage(img, 0, 0, layer.size.width, layer.size.height);
            resolve();
          } else {
            img.onload = () => {
              ctx.drawImage(img, 0, 0, layer.size.width, layer.size.height);
              resolve();
            };
            img.onerror = resolve;
          }
        });
      } else if (layer.type === 'text') {
        ctx.font = `${layer.data.fontSize || 48}px ${layer.data.fontFamily || 'Arial'}`;
        ctx.fillStyle = layer.data.color || '#ffffff';
        ctx.fillText(layer.data.text || '', 0, layer.data.fontSize || 48);
      }
      
      ctx.restore();
    };

    // Render all layers sequentially
    (async () => {
      for (const layer of layersToRender) {
        await renderLayer(layer);
      }
      
      // Draw selection border
      const selectedLayer = layers.find(l => l.id === selectedLayerId);
      if (selectedLayer) {
        ctx.strokeStyle = '#00ff88';
        ctx.lineWidth = 2;
        ctx.setLineDash([5, 5]);
        ctx.strokeRect(
          selectedLayer.position.x,
          selectedLayer.position.y,
          selectedLayer.size.width,
          selectedLayer.size.height
        );
      }
    })();
  }, [layers, selectedLayerId, canvasSize]);

  useEffect(() => {
    renderCanvas();
  }, [renderCanvas]);

  // ===== EXPORT =====
  const exportProject = async (format = 'png') => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const dataUrl = canvas.toDataURL(`image/${format}`);
    const link = document.createElement('a');
    link.download = `digital-catalyzt-export-${Date.now()}.${format}`;
    link.href = dataUrl;
    link.click();
    toast.success('Exported successfully!');
  };

  // ===== SELECTED LAYER =====
  const selectedLayer = layers.find(l => l.id === selectedLayerId);

  return (
    <div className="h-screen flex flex-col bg-background overflow-hidden">
      {/* ===== TOP BAR ===== */}
      <div className="h-14 border-b border-border flex items-center justify-between px-4 bg-card/50 backdrop-blur">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Brain className="w-6 h-6 text-accent" />
            <span className="font-bold text-lg">UNIFIED CREATIVE INTELLIGENCE</span>
          </div>
          <div className="flex items-center gap-1 ml-4">
            <Button size="sm" variant="ghost" onClick={undo} disabled={historyIndex <= 0}>
              <RotateCw className="w-4 h-4 rotate-180" />
            </Button>
            <Button size="sm" variant="ghost" onClick={redo} disabled={historyIndex >= history.length - 1}>
              <RotateCw className="w-4 h-4" />
            </Button>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button size="sm" variant="outline" onClick={() => exportProject('png')}>
            <Download className="w-4 h-4 mr-2" /> Export PNG
          </Button>
          <Button size="sm" variant="outline">
            <Save className="w-4 h-4 mr-2" /> Save Project
          </Button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* ===== LEFT PANEL - GENERATION CONTROLS ===== */}
        <div className="w-80 border-r border-border flex flex-col bg-card/30 overflow-y-auto">
          {/* Mode Tabs */}
          <Tabs value={activeMode} onValueChange={setActiveMode} className="w-full">
            <TabsList className="w-full rounded-none border-b border-border h-12 bg-transparent">
              <TabsTrigger value="image" className="flex-1 data-[state=active]:bg-accent/20">
                <ImageIcon className="w-4 h-4 mr-1" /> Image
              </TabsTrigger>
              <TabsTrigger value="video" className="flex-1 data-[state=active]:bg-accent/20">
                <Film className="w-4 h-4 mr-1" /> Video
              </TabsTrigger>
              <TabsTrigger value="audio" className="flex-1 data-[state=active]:bg-accent/20">
                <Mic className="w-4 h-4 mr-1" /> Audio
              </TabsTrigger>
            </TabsList>

            {/* ===== IMAGE GENERATION TAB ===== */}
            <TabsContent value="image" className="p-4 space-y-4 mt-0">
              <div className="space-y-2">
                <label className="text-sm font-semibold flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-accent" /> Prompt
                </label>
                <textarea
                  value={imagePrompt}
                  onChange={(e) => setImagePrompt(e.target.value)}
                  placeholder="Describe your image in detail..."
                  className="w-full h-24 p-3 rounded-lg bg-background border border-border resize-none text-sm"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-semibold">Negative Prompt (Avoid)</label>
                <Input
                  value={negativePrompt}
                  onChange={(e) => setNegativePrompt(e.target.value)}
                  placeholder="blur, low quality, text..."
                  className="bg-background"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-semibold">Style</label>
                <div className="grid grid-cols-2 gap-2 max-h-40 overflow-y-auto">
                  {styleOptions.map(style => (
                    <button
                      key={style.id}
                      onClick={() => setImageStyle(style.id)}
                      className={`p-2 rounded-lg border text-left transition-all ${
                        imageStyle === style.id
                          ? 'border-accent bg-accent/20'
                          : 'border-border hover:border-accent/50'
                      }`}
                    >
                      <div className="text-xs font-semibold">{style.name}</div>
                      <div className="text-[10px] text-muted-foreground">{style.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-semibold">Aspect Ratio</label>
                <Select value={imageAspectRatio} onValueChange={setImageAspectRatio}>
                  <SelectTrigger className="bg-background">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {aspectRatios.map(ratio => (
                      <SelectItem key={ratio.id} value={ratio.id}>{ratio.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-semibold flex items-center gap-2">
                  <Upload className="w-4 h-4" /> Reference Images
                </label>
                <input
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={handleReferenceUpload}
                  className="hidden"
                  id="ref-upload"
                />
                <label
                  htmlFor="ref-upload"
                  className="flex items-center justify-center h-20 border-2 border-dashed border-border rounded-lg cursor-pointer hover:border-accent transition-colors"
                >
                  <div className="text-center">
                    <Plus className="w-6 h-6 mx-auto text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">Upload references</span>
                  </div>
                </label>
                {referenceImages.length > 0 && (
                  <div className="flex gap-2 flex-wrap">
                    {referenceImages.map(ref => (
                      <div key={ref.id} className="relative w-12 h-12">
                        <img src={ref.preview} alt={ref.name} className="w-full h-full object-cover rounded" />
                        <button
                          onClick={() => setReferenceImages(prev => prev.filter(r => r.id !== ref.id))}
                          className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <Button
                onClick={generateImage}
                disabled={isGenerating || !imagePrompt.trim()}
                className="w-full h-12 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Generating ({generationProgress}%)
                  </>
                ) : (
                  <>
                    <Wand2 className="w-5 h-5 mr-2" />
                    Generate Image
                  </>
                )}
              </Button>
            </TabsContent>

            {/* ===== VIDEO/SCRIPT TAB ===== */}
            <TabsContent value="video" className="p-4 space-y-4 mt-0">
              <div className="space-y-2">
                <label className="text-sm font-semibold flex items-center gap-2">
                  <FileText className="w-4 h-4 text-accent" /> Script / Topic
                </label>
                <textarea
                  value={scriptText}
                  onChange={(e) => setScriptText(e.target.value)}
                  placeholder="Enter topic or paste your script..."
                  className="w-full h-32 p-3 rounded-lg bg-background border border-border resize-none text-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <Button onClick={generateScript} disabled={isGenerating} className="bg-blue-600 hover:bg-blue-700">
                  <Brain className="w-4 h-4 mr-2" /> Generate Script
                </Button>
                <Button onClick={generateAllSceneImages} disabled={scenes.length === 0 || isGenerating} variant="outline">
                  <ImageIcon className="w-4 h-4 mr-2" /> Gen All Scenes
                </Button>
              </div>

              {/* Scenes List */}
              {scenes.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-semibold">Scenes ({scenes.length})</label>
                    <Button size="sm" onClick={addScenesToTimeline} variant="outline">
                      <Plus className="w-3 h-3 mr-1" /> Add to Timeline
                    </Button>
                  </div>
                  <div className="space-y-2 max-h-60 overflow-y-auto">
                    {scenes.map((scene, index) => (
                      <div 
                        key={scene.id} 
                        className="p-3 rounded-lg border border-border bg-background/50 space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-semibold">Scene {index + 1}</span>
                          <span className={`text-xs px-2 py-0.5 rounded ${
                            scene.status === 'ready' ? 'bg-green-500/20 text-green-400' :
                            scene.status === 'generating' ? 'bg-yellow-500/20 text-yellow-400' :
                            scene.status === 'failed' ? 'bg-red-500/20 text-red-400' :
                            'bg-gray-500/20 text-gray-400'
                          }`}>
                            {scene.status}
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground line-clamp-2">{scene.content}</p>
                        {scene.imageBase64 && (
                          <img 
                            src={`data:image/png;base64,${scene.imageBase64}`} 
                            alt={`Scene ${index + 1}`}
                            className="w-full h-20 object-cover rounded"
                          />
                        )}
                        <div className="flex items-center gap-2">
                          <Input
                            type="number"
                            value={scene.duration}
                            onChange={(e) => setScenes(prev => prev.map(s => 
                              s.id === scene.id ? { ...s, duration: parseInt(e.target.value) || 5 } : s
                            ))}
                            className="w-16 h-7 text-xs"
                            min={1}
                            max={30}
                          />
                          <span className="text-xs">sec</span>
                          <Button 
                            size="sm" 
                            variant="ghost" 
                            onClick={() => generateSceneImage(scene.id)}
                            disabled={scene.status === 'generating'}
                            className="ml-auto h-7"
                          >
                            {scene.status === 'generating' ? (
                              <Loader2 className="w-3 h-3 animate-spin" />
                            ) : (
                              <RefreshCw className="w-3 h-3" />
                            )}
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Assemble Video Button */}
              {scenes.filter(s => s.status === 'ready').length > 0 && (
                <div className="space-y-2 pt-2 border-t border-border">
                  <Button
                    onClick={assembleVideo}
                    disabled={isGenerating}
                    className="w-full bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700"
                  >
                    {isGenerating ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Assembling...
                      </>
                    ) : (
                      <>
                        <Film className="w-4 h-4 mr-2" />
                        Assemble Video from Scenes
                      </>
                    )}
                  </Button>
                  <p className="text-xs text-muted-foreground text-center">
                    Combines all ready scenes into a playable video
                  </p>
                </div>
              )}

              {/* Assembled Video Preview */}
              {assembledVideo && (
                <div className="space-y-3 p-3 rounded-lg bg-green-500/10 border border-green-500/30">
                  <div className="flex items-center gap-2 text-green-400">
                    <Check className="w-4 h-4" />
                    <span className="text-sm font-semibold">Video Ready!</span>
                  </div>
                  {/* Video Player */}
                  <div className="rounded-lg overflow-hidden bg-black">
                    <video
                      controls
                      className="w-full max-h-48 object-contain"
                      src={`data:video/mp4;base64,${assembledVideo}`}
                      onError={(e) => {
                        console.error('Video playback error:', e);
                        toast.error('Video playback failed. Try downloading instead.');
                      }}
                    >
                      Your browser does not support video playback.
                    </video>
                  </div>
                  <Button
                    onClick={() => {
                      const link = document.createElement('a');
                      link.download = `video-${Date.now()}.mp4`;
                      link.href = `data:video/mp4;base64,${assembledVideo}`;
                      link.click();
                      toast.success('Video downloaded!');
                    }}
                    className="w-full"
                    variant="outline"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download Video
                  </Button>
                </div>
              )}
            </TabsContent>

            {/* ===== AUDIO TAB ===== */}
            <TabsContent value="audio" className="p-4 space-y-4 mt-0">
              <div className="space-y-2">
                <label className="text-sm font-semibold flex items-center gap-2">
                  <Mic className="w-4 h-4 text-accent" /> Voice Text
                </label>
                <textarea
                  value={voiceText}
                  onChange={(e) => setVoiceText(e.target.value)}
                  placeholder="Enter text for AI voice..."
                  className="w-full h-24 p-3 rounded-lg bg-background border border-border resize-none text-sm"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-semibold">Voice Style</label>
                <div className="grid grid-cols-2 gap-2">
                  {voiceOptions.map(voice => (
                    <button
                      key={voice.id}
                      onClick={() => setVoiceStyle(voice.id)}
                      className={`p-2 rounded-lg border text-left transition-all ${
                        voiceStyle === voice.id
                          ? 'border-accent bg-accent/20'
                          : 'border-border hover:border-accent/50'
                      }`}
                    >
                      <div className="text-xs font-semibold">{voice.name}</div>
                      <div className="text-[10px] text-muted-foreground">{voice.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-semibold">Speed: {voiceSpeed}x</label>
                <Slider
                  value={[voiceSpeed]}
                  onValueChange={([v]) => setVoiceSpeed(v)}
                  min={0.5}
                  max={2}
                  step={0.1}
                />
              </div>

              <Button
                onClick={generateVoice}
                disabled={isGenerating || !voiceText.trim()}
                className="w-full h-12 bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Speaker className="w-5 h-5 mr-2" />
                    Generate Voice
                  </>
                )}
              </Button>

              {/* Audio Layers */}
              {audioLayers.length > 0 && (
                <div className="space-y-2">
                  <label className="text-sm font-semibold">Audio Layers</label>
                  {audioLayers.map((audio, index) => (
                    <div key={audio.id} className="p-2 rounded-lg border border-border bg-background/50 flex items-center gap-2">
                      <Volume2 className="w-4 h-4 text-accent" />
                      <span className="text-xs flex-1 truncate">{audio.name}</span>
                      <Button size="sm" variant="ghost" className="h-6 w-6 p-0">
                        <Play className="w-3 h-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}

              {/* MUSIC UPLOAD */}
              <div className="space-y-2 pt-4 border-t border-border">
                <label className="text-sm font-semibold flex items-center gap-2">
                  <Upload className="w-4 h-4 text-blue-400" /> Upload Your Music
                </label>
                <p className="text-xs text-muted-foreground">
                  Upload your own background music (.mp3, .wav)
                </p>
                <input
                  type="file"
                  accept=".mp3,.wav,audio/mpeg,audio/wav"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onload = () => {
                        const base64 = reader.result.split(',')[1];
                        // Add to timeline music track
                        setTimelineTracks(prev => prev.map(track => {
                          if (track.id === 'music') {
                            return {
                              ...track,
                              clips: [...track.clips, {
                                id: `music-${Date.now()}`,
                                name: file.name.substring(0, 20),
                                start: 0,
                                duration: 30, // Default duration
                                data: { base64, fileName: file.name, type: 'uploaded' }
                              }]
                            };
                          }
                          return track;
                        }));
                        toast.success(`🎵 "${file.name}" added to timeline!`);
                      };
                      reader.readAsDataURL(file);
                    }
                    e.target.value = ''; // Reset input
                  }}
                  className="hidden"
                  id="music-upload"
                />
                <label
                  htmlFor="music-upload"
                  className="flex items-center justify-center h-16 border-2 border-dashed border-blue-400/50 rounded-lg cursor-pointer hover:border-blue-400 hover:bg-blue-400/5 transition-all"
                >
                  <div className="text-center">
                    <Music className="w-6 h-6 mx-auto text-blue-400 mb-1" />
                    <span className="text-xs text-blue-400">Click to upload music</span>
                  </div>
                </label>
              </div>

              {/* AI MUSIC GENERATION (Unavailable) */}
              <div className="space-y-2 pt-4 border-t border-border opacity-60">
                <label className="text-sm font-semibold flex items-center gap-2">
                  <Music className="w-4 h-4 text-pink-400" /> AI Music Generation
                  <span className="text-[10px] px-1.5 py-0.5 bg-yellow-500/20 text-yellow-400 rounded">Coming Soon</span>
                </label>
                <textarea
                  value={musicPrompt}
                  onChange={(e) => setMusicPrompt(e.target.value)}
                  placeholder="Describe the music: upbeat corporate, calm meditation, epic trailer..."
                  className="w-full h-16 p-3 rounded-lg bg-background border border-border resize-none text-sm"
                  disabled
                />
                <div className="grid grid-cols-2 gap-2">
                  {musicStyles.map(style => (
                    <button
                      key={style.id}
                      onClick={() => setMusicStyle(style.id)}
                      className={`p-1.5 rounded-lg border text-xs transition-all ${
                        musicStyle === style.id
                          ? 'border-pink-400 bg-pink-400/20'
                          : 'border-border hover:border-pink-400/50'
                      }`}
                    >
                      {style.name}
                    </button>
                  ))}
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span>Duration</span>
                    <span>{musicDuration}s</span>
                  </div>
                  <Slider
                    value={[musicDuration]}
                    onValueChange={([v]) => setMusicDuration(v)}
                    min={15}
                    max={120}
                    step={15}
                  />
                </div>
                <Button
                  onClick={generateMusic}
                  disabled={true}
                  className="w-full bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700 opacity-50 cursor-not-allowed"
                >
                  <Music className="w-4 h-4 mr-2" />
                  Generate Music (Unavailable)
                </Button>
                <p className="text-[10px] text-muted-foreground text-center">
                  AI music generation requires Suno API. Use the upload feature above instead.
                </p>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* ===== MAIN CANVAS AREA ===== */}
        <div className="flex-1 flex flex-col bg-[#0a0a0f]">
          {/* Toolbar */}
          <div className="h-10 border-b border-border flex items-center gap-2 px-4 bg-card/30">
            <div className="flex items-center gap-1 border-r border-border pr-2">
              <Button size="sm" variant={editMode === 'select' ? 'secondary' : 'ghost'} onClick={() => setEditMode('select')} className="h-7 w-7 p-0">
                <Move className="w-4 h-4" />
              </Button>
              <Button size="sm" variant={editMode === 'crop' ? 'secondary' : 'ghost'} onClick={() => setEditMode('crop')} className="h-7 w-7 p-0">
                <Scissors className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex items-center gap-1">
              <Button size="sm" variant="ghost" onClick={() => setZoom(z => Math.max(0.1, z - 0.1))} className="h-7 w-7 p-0">
                <ZoomOut className="w-4 h-4" />
              </Button>
              <span className="text-xs w-12 text-center">{Math.round(zoom * 100)}%</span>
              <Button size="sm" variant="ghost" onClick={() => setZoom(z => Math.min(3, z + 0.1))} className="h-7 w-7 p-0">
                <ZoomIn className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Canvas */}
          <div className="flex-1 overflow-auto flex items-center justify-center p-8">
            <div 
              className="relative bg-[#1a1a2e] rounded-lg overflow-hidden shadow-2xl"
              style={{ 
                transform: `scale(${zoom})`,
                transformOrigin: 'center center'
              }}
            >
              <canvas
                ref={canvasRef}
                width={canvasSize.width}
                height={canvasSize.height}
                className="block"
              />
              {layers.length === 0 && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center text-muted-foreground">
                    <Wand2 className="w-16 h-16 mx-auto mb-4 opacity-30" />
                    <p className="text-lg">Generate or upload content</p>
                    <p className="text-sm">Use the panels on the left to create</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* ===== TIMELINE ===== */}
          <div className="h-48 border-t border-border bg-card/50">
            {/* Timeline Header */}
            <div className="h-8 border-b border-border flex items-center justify-between px-4">
              <div className="flex items-center gap-2">
                <Button size="sm" variant="ghost" onClick={() => setIsPlaying(!isPlaying)} className="h-6 w-6 p-0">
                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                </Button>
                <Button size="sm" variant="ghost" className="h-6 w-6 p-0">
                  <Square className="w-4 h-4" />
                </Button>
                <span className="text-xs font-mono">
                  {Math.floor(timelinePosition / 60)}:{(timelinePosition % 60).toString().padStart(2, '0')} / 
                  {Math.floor(timelineDuration / 60)}:{(timelineDuration % 60).toString().padStart(2, '0')}
                </span>
              </div>
            </div>
            
            {/* Timeline Tracks */}
            <div className="flex-1 overflow-auto">
              {timelineTracks.map(track => (
                <div key={track.id} className="h-10 flex border-b border-border/50">
                  <div className="w-24 flex items-center px-2 border-r border-border/50 bg-card/30">
                    <span className="text-xs font-medium truncate">{track.name}</span>
                  </div>
                  <div className="flex-1 relative bg-background/20">
                    {/* Time ruler marks */}
                    <div className="absolute inset-0 flex">
                      {Array.from({ length: Math.ceil(timelineDuration / 5) }).map((_, i) => (
                        <div 
                          key={i} 
                          className="border-l border-border/30 h-full"
                          style={{ width: `${(5 / timelineDuration) * 100}%` }}
                        />
                      ))}
                    </div>
                    {/* Clips */}
                    {track.clips.map(clip => (
                      <div
                        key={clip.id}
                        className="absolute top-1 bottom-1 bg-accent/40 rounded border border-accent/60 flex items-center px-2 cursor-move"
                        style={{
                          left: `${(clip.start / timelineDuration) * 100}%`,
                          width: `${(clip.duration / timelineDuration) * 100}%`
                        }}
                      >
                        <span className="text-[10px] truncate">{clip.name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ===== RIGHT PANEL - LAYERS & PROPERTIES ===== */}
        <div className="w-72 border-l border-border flex flex-col bg-card/30">
          {/* Layers Section */}
          <div className="flex-1 overflow-y-auto">
            <div className="p-3 border-b border-border">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-semibold flex items-center gap-2">
                  <Layers className="w-4 h-4" /> Layers
                </span>
                <div className="flex gap-1">
                  <Button 
                    size="sm" 
                    variant="ghost" 
                    onClick={() => addLayer('text', { text: 'New Text', fontSize: 48, color: '#ffffff' })}
                    className="h-6 w-6 p-0"
                  >
                    <Type className="w-3 h-3" />
                  </Button>
                </div>
              </div>
              
              {/* Layer List */}
              <div className="space-y-1">
                {layers.map((layer, index) => (
                  <div
                    key={layer.id}
                    onClick={() => setSelectedLayerId(layer.id)}
                    className={`p-2 rounded-lg cursor-pointer transition-all flex items-center gap-2 ${
                      selectedLayerId === layer.id
                        ? 'bg-accent/20 border border-accent'
                        : 'bg-background/50 border border-transparent hover:border-border'
                    }`}
                  >
                    <GripVertical className="w-3 h-3 text-muted-foreground" />
                    {layer.type === 'image' && <ImageIcon className="w-4 h-4 text-blue-400" />}
                    {layer.type === 'text' && <Type className="w-4 h-4 text-green-400" />}
                    {layer.type === 'video' && <Film className="w-4 h-4 text-purple-400" />}
                    <span className="text-xs flex-1 truncate">{layer.name}</span>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={(e) => { e.stopPropagation(); updateLayer(layer.id, { visible: !layer.visible }); }}
                      className="h-5 w-5 p-0"
                    >
                      {layer.visible ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={(e) => { e.stopPropagation(); updateLayer(layer.id, { locked: !layer.locked }); }}
                      className="h-5 w-5 p-0"
                    >
                      {layer.locked ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
                    </Button>
                  </div>
                ))}
                {layers.length === 0 && (
                  <div className="text-center py-4 text-muted-foreground text-xs">
                    No layers yet
                  </div>
                )}
              </div>
            </div>

            {/* Properties Panel */}
            {selectedLayer && (
              <div className="p-3 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-semibold flex items-center gap-2">
                    <Sliders className="w-4 h-4" /> Properties
                  </span>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => deleteLayer(selectedLayer.id)}
                    className="h-6 w-6 p-0 text-red-400 hover:text-red-300"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>

                {/* Transform */}
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-muted-foreground">TRANSFORM</label>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px]">X</label>
                      <Input
                        type="number"
                        value={selectedLayer.position.x}
                        onChange={(e) => updateLayer(selectedLayer.id, { 
                          position: { ...selectedLayer.position, x: parseInt(e.target.value) || 0 }
                        })}
                        className="h-7 text-xs"
                      />
                    </div>
                    <div>
                      <label className="text-[10px]">Y</label>
                      <Input
                        type="number"
                        value={selectedLayer.position.y}
                        onChange={(e) => updateLayer(selectedLayer.id, { 
                          position: { ...selectedLayer.position, y: parseInt(e.target.value) || 0 }
                        })}
                        className="h-7 text-xs"
                      />
                    </div>
                    <div>
                      <label className="text-[10px]">Width</label>
                      <Input
                        type="number"
                        value={selectedLayer.size.width}
                        onChange={(e) => updateLayer(selectedLayer.id, { 
                          size: { ...selectedLayer.size, width: parseInt(e.target.value) || 100 }
                        })}
                        className="h-7 text-xs"
                      />
                    </div>
                    <div>
                      <label className="text-[10px]">Height</label>
                      <Input
                        type="number"
                        value={selectedLayer.size.height}
                        onChange={(e) => updateLayer(selectedLayer.id, { 
                          size: { ...selectedLayer.size, height: parseInt(e.target.value) || 100 }
                        })}
                        className="h-7 text-xs"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-[10px]">Rotation</label>
                    <Slider
                      value={[selectedLayer.rotation]}
                      onValueChange={([v]) => updateLayer(selectedLayer.id, { rotation: v })}
                      min={0}
                      max={360}
                      step={1}
                    />
                  </div>
                </div>

                {/* Filters */}
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-muted-foreground">ADJUSTMENTS</label>
                  <div className="space-y-2">
                    <div>
                      <div className="flex justify-between text-[10px]">
                        <span>Brightness</span>
                        <span>{selectedLayer.filters.brightness}%</span>
                      </div>
                      <Slider
                        value={[selectedLayer.filters.brightness]}
                        onValueChange={([v]) => updateLayer(selectedLayer.id, { 
                          filters: { ...selectedLayer.filters, brightness: v }
                        })}
                        min={0}
                        max={200}
                      />
                    </div>
                    <div>
                      <div className="flex justify-between text-[10px]">
                        <span>Contrast</span>
                        <span>{selectedLayer.filters.contrast}%</span>
                      </div>
                      <Slider
                        value={[selectedLayer.filters.contrast]}
                        onValueChange={([v]) => updateLayer(selectedLayer.id, { 
                          filters: { ...selectedLayer.filters, contrast: v }
                        })}
                        min={0}
                        max={200}
                      />
                    </div>
                    <div>
                      <div className="flex justify-between text-[10px]">
                        <span>Saturation</span>
                        <span>{selectedLayer.filters.saturation}%</span>
                      </div>
                      <Slider
                        value={[selectedLayer.filters.saturation]}
                        onValueChange={([v]) => updateLayer(selectedLayer.id, { 
                          filters: { ...selectedLayer.filters, saturation: v }
                        })}
                        min={0}
                        max={200}
                      />
                    </div>
                    <div>
                      <div className="flex justify-between text-[10px]">
                        <span>Opacity</span>
                        <span>{selectedLayer.opacity}%</span>
                      </div>
                      <Slider
                        value={[selectedLayer.opacity]}
                        onValueChange={([v]) => updateLayer(selectedLayer.id, { opacity: v })}
                        min={0}
                        max={100}
                      />
                    </div>
                  </div>
                </div>

                {/* Quick Actions */}
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-muted-foreground">QUICK ACTIONS</label>
                  <div className="flex gap-1 flex-wrap">
                    <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => moveLayer(selectedLayer.id, 'up')}>
                      <ChevronUp className="w-3 h-3" />
                    </Button>
                    <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => moveLayer(selectedLayer.id, 'down')}>
                      <ChevronDown className="w-3 h-3" />
                    </Button>
                    <Button size="sm" variant="outline" className="h-7 text-xs">
                      <FlipHorizontal className="w-3 h-3" />
                    </Button>
                    <Button size="sm" variant="outline" className="h-7 text-xs">
                      <FlipVertical className="w-3 h-3" />
                    </Button>
                    <Button size="sm" variant="outline" className="h-7 text-xs">
                      <Copy className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default UnifiedCreativeStudio;
