import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Image as ImageIcon, Sparkles, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import axios from 'axios';

const MockupStudio = () => {
  const { user, refreshUser } = useAuth();
  const [templates, setTemplates] = useState([]);
  const [selectedTemplate, setSelectedTemplate] = useState('');
  const [productType, setProductType] = useState('t-shirt');
  const [modelStyle, setModelStyle] = useState('female');
  const [scene, setScene] = useState('studio');
  const [generating, setGenerating] = useState(false);
  const [result, setResult] = useState(null);

  const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
  const API = `${BACKEND_URL}/api`;

  useEffect(() => {
    fetchTemplates();
  }, []);

  const fetchTemplates = async () => {
    try {
      const response = await axios.get(`${API}/templates?type=image`);
      setTemplates(response.data);
      if (response.data.length > 0) {
        setSelectedTemplate(response.data[0].id);
      }
    } catch (error) {
      console.error('Failed to fetch templates:', error);
    }
  };

  const handleGenerate = async () => {
    setGenerating(true);
    setResult(null);

    try {
      const response = await axios.post(`${API}/image/generate`, {
        user_id: user.id,
        template: selectedTemplate,
        product_type: productType,
        model_style: modelStyle,
        scene
      });

      setResult(response.data);
      toast.success('Mockup generated successfully!');
      refreshUser();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Image generation failed');
    } finally {
      setGenerating(false);
    }
  };

  const handleDownload = () => {
    if (result?.image_base64) {
      const link = document.createElement('a');
      link.href = `data:image/png;base64,${result.image_base64}`;
      link.download = 'mockup.png';
      link.click();
      toast.success('Download started!');
    }
  };

  const selectedTemplateData = templates.find(t => t.id === selectedTemplate);

  return (
    <div className="p-8 max-w-6xl mx-auto fade-in">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
          <ImageIcon className="text-primary" />
          Mockup Studio
        </h1>
        <p className="text-muted-foreground">Create photorealistic product mockups with AI models</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="glass-panel p-6">
          <h2 className="text-xl font-semibold mb-4">Configuration</h2>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Template</label>
              <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                <SelectTrigger data-testid="mockup-template-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {templates.map((template) => (
                    <SelectItem key={template.id} value={template.id}>
                      {template.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {selectedTemplateData && (
                <p className="text-xs text-muted-foreground mt-2">{selectedTemplateData.description}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Product Type</label>
              <Select value={productType} onValueChange={setProductType}>
                <SelectTrigger data-testid="product-type-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="t-shirt">T-Shirt</SelectItem>
                  <SelectItem value="hoodie">Hoodie</SelectItem>
                  <SelectItem value="tank top">Tank Top</SelectItem>
                  <SelectItem value="sweatshirt">Sweatshirt</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Model Style</label>
              <Select value={modelStyle} onValueChange={setModelStyle}>
                <SelectTrigger data-testid="model-style-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="female">Female Model</SelectItem>
                  <SelectItem value="male">Male Model</SelectItem>
                  <SelectItem value="neutral">Neutral/Diverse</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Scene</label>
              <Select value={scene} onValueChange={setScene}>
                <SelectTrigger data-testid="scene-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="studio">Studio</SelectItem>
                  <SelectItem value="street">Urban Street</SelectItem>
                  <SelectItem value="gym">Gym/Fitness</SelectItem>
                  <SelectItem value="home">Home/Lifestyle</SelectItem>
                  <SelectItem value="nature">Nature/Outdoor</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="pt-4">
              <Button
                onClick={handleGenerate}
                disabled={generating}
                data-testid="generate-mockup-button"
                className="w-full btn-primary"
              >
                {generating ? (
                  <span className="flex items-center gap-2">
                    <div className="loading-spinner w-4 h-4 border-2 border-white/20 border-t-white rounded-full" />
                    Generating... (this may take 30-60s)
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    <Sparkles size={18} />
                    Generate Mockup (5 credits)
                  </span>
                )}
              </Button>
            </div>
          </div>
        </div>

        <div className="glass-panel p-6">
          <h2 className="text-xl font-semibold mb-4">Preview</h2>

          {result ? (
            <div className="space-y-4" data-testid="mockup-result">
              <div className="aspect-square bg-black/50 rounded-lg overflow-hidden">
                <img
                  src={`data:image/png;base64,${result.image_base64}`}
                  alt="Generated mockup"
                  className="w-full h-full object-cover"
                  data-testid="mockup-image"
                />
              </div>
              <Button
                onClick={handleDownload}
                data-testid="download-mockup-button"
                className="w-full btn-secondary"
              >
                <Download size={18} className="mr-2" />
                Download Image
              </Button>
            </div>
          ) : (
            <div className="aspect-square bg-gradient-to-br from-blue-500/10 to-cyan-500/10 rounded-lg flex items-center justify-center border-2 border-dashed border-border" data-testid="mockup-placeholder">
              <div className="text-center">
                <ImageIcon size={64} className="mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground">Your mockup will appear here</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MockupStudio;