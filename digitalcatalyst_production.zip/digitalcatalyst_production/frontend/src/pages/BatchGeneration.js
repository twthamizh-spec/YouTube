import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Layers, Plus, Trash2, Play, Video, Image, Mic } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Input } from '../components/ui/input';
import { toast } from 'sonner';
import axios from 'axios';

const BatchGeneration = () => {
  const { user, refreshUser } = useAuth();
  const [batches, setBatches] = useState([
    { id: 1, type: 'video', template: 'viral_short', topic: '', style: 'luxury', duration: 4 }
  ]);
  const [templates, setTemplates] = useState([]);
  const [generating, setGenerating] = useState(false);

  const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
  const API = `${BACKEND_URL}/api`;

  useEffect(() => {
    fetchTemplates();
  }, []);

  const fetchTemplates = async () => {
    try {
      const response = await axios.get(`${API}/templates`);
      setTemplates(response.data);
    } catch (error) {
      console.error('Failed to fetch templates:', error);
    }
  };

  const addBatch = () => {
    setBatches([...batches, {
      id: Date.now(),
      type: 'video',
      template: 'viral_short',
      topic: '',
      style: 'luxury',
      duration: 4
    }]);
  };

  const removeBatch = (id) => {
    setBatches(batches.filter(b => b.id !== id));
  };

  const updateBatch = (id, field, value) => {
    setBatches(batches.map(b => b.id === id ? { ...b, [field]: value } : b));
  };

  const calculateTotalCost = () => {
    return batches.reduce((total, batch) => {
      const template = templates.find(t => t.id === batch.template);
      return total + (template?.cost || 0);
    }, 0);
  };

  const handleGenerate = async () => {
    setGenerating(true);

    try {
      const requests = batches.map(batch => ({
        type: batch.type,
        user_id: user.id,
        template: batch.template,
        topic: batch.topic,
        style: batch.style,
        duration: batch.duration
      }));

      // Generate sequentially to avoid overwhelming the system
      for (const req of requests) {
        if (req.type === 'video') {
          await axios.post(`${API}/video/generate`, req);
        } else if (req.type === 'image') {
          await axios.post(`${API}/image/generate`, req);
        } else if (req.type === 'voiceover') {
          await axios.post(`${API}/voiceover/generate`, req);
        }
      }

      toast.success('Batch generation started! Check Projects for status.');
      refreshUser();
      setBatches([{ id: 1, type: 'video', template: 'viral_short', topic: '', style: 'luxury', duration: 4 }]);
    } catch (error) {
      toast.error('Batch generation failed');
    } finally {
      setGenerating(false);
    }
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'video': return Video;
      case 'image': return Image;
      case 'voiceover': return Mic;
      default: return Video;
    }
  };

  return (
    <div className="p-8 max-w-6xl mx-auto fade-in">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
          <Layers className="text-primary" />
          Batch Generation
        </h1>
        <p className="text-muted-foreground">Generate multiple content pieces at once</p>
      </div>

      <div className="space-y-4 mb-6">
        {batches.map((batch, index) => {
          const TypeIcon = getTypeIcon(batch.type);
          const availableTemplates = templates.filter(t => t.type === batch.type);

          return (
            <div key={batch.id} className="glass-panel p-6" data-testid={`batch-item-${index}`}>
              <div className="flex items-center gap-4 mb-4">
                <div className="flex items-center gap-2">
                  <TypeIcon size={20} className="text-primary" />
                  <span className="font-semibold">Item {index + 1}</span>
                </div>
                <button
                  onClick={() => removeBatch(batch.id)}
                  data-testid={`batch-remove-${index}`}
                  className="ml-auto text-muted-foreground hover:text-red-400 transition-colors"
                >
                  <Trash2 size={18} />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Type</label>
                  <Select value={batch.type} onValueChange={(v) => updateBatch(batch.id, 'type', v)}>
                    <SelectTrigger data-testid={`batch-type-${index}`}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="video">Video</SelectItem>
                      <SelectItem value="image">Image</SelectItem>
                      <SelectItem value="voiceover">Voiceover</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Template</label>
                  <Select value={batch.template} onValueChange={(v) => updateBatch(batch.id, 'template', v)}>
                    <SelectTrigger data-testid={`batch-template-${index}`}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {availableTemplates.map((t) => (
                        <SelectItem key={t.id} value={t.id}>
                          {t.name} ({t.cost} credits)
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium mb-2">Topic / Content</label>
                  <Input
                    value={batch.topic}
                    onChange={(e) => updateBatch(batch.id, 'topic', e.target.value)}
                    placeholder="Enter topic or description..."
                    data-testid={`batch-topic-${index}`}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="flex items-center gap-4 mb-6">
        <Button onClick={addBatch} data-testid="batch-add-button" className="btn-secondary">
          <Plus size={18} className="mr-2" />
          Add Item
        </Button>
      </div>

      <div className="glass-panel p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-semibold">Summary</h3>
          <div className="text-right">
            <div className="text-sm text-muted-foreground">Total Cost</div>
            <div className="text-2xl font-bold text-primary" data-testid="batch-total-cost">
              {calculateTotalCost()} credits
            </div>
          </div>
        </div>
        <div className="space-y-2 text-sm">
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Items to generate</span>
            <span className="font-semibold">{batches.length}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Available credits</span>
            <span className="font-semibold">{user?.credits || 0}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Remaining after</span>
            <span className="font-semibold">{Math.max(0, (user?.credits || 0) - calculateTotalCost())}</span>
          </div>
        </div>
      </div>

      <Button
        onClick={handleGenerate}
        disabled={generating || batches.some(b => !b.topic) || calculateTotalCost() > (user?.credits || 0)}
        data-testid="batch-generate-button"
        className="w-full btn-primary"
      >
        {generating ? (
          <span className="flex items-center gap-2">
            <div className="loading-spinner w-4 h-4 border-2 border-white/20 border-t-white rounded-full" />
            Generating Batch...
          </span>
        ) : (
          <span className="flex items-center gap-2">
            <Play size={18} />
            Generate All ({calculateTotalCost()} credits)
          </span>
        )}
      </Button>
    </div>
  );
};

export default BatchGeneration;