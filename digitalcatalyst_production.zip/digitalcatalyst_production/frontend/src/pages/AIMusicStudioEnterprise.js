import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { toast } from 'sonner';
import {
  Music, Upload, Play, Pause, Square, Volume2, VolumeX, Download,
  Wand2, Loader2, FileAudio, Mic, Radio, Sliders, RefreshCw,
  Waves, Clock, Gauge, Heart, Zap, Sun, Moon, Cloud, Flame,
  Target, BarChart3, Settings, Check, X, Plus, Trash2, Save
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

// ============================================================
// AI MUSIC STUDIO (ENTERPRISE)
// Music generation, reference analysis, and mixing engine
// ============================================================

const AIMusicStudioEnterprise = () => {
  const { user } = useAuth();
  const audioRef = useRef(null);
  const referenceInputRef = useRef(null);
  const uploadInputRef = useRef(null);
  
  // ===== GENERATION MODE =====
  const [activeMode, setActiveMode] = useState('upload'); // upload, reference, text
  
  // ===== TEXT-TO-MUSIC STATE =====
  const [musicPrompt, setMusicPrompt] = useState('');
  const [mood, setMood] = useState('motivational');
  const [genre, setGenre] = useState('cinematic');
  const [tempo, setTempo] = useState('medium');
  const [intensity, setIntensity] = useState(50);
  const [duration, setDuration] = useState(30);
  
  // ===== REFERENCE STATE =====
  const [referenceFile, setReferenceFile] = useState(null);
  const [referencePreview, setReferencePreview] = useState(null);
  const [referenceAnalysis, setReferenceAnalysis] = useState(null);
  const [similarityLevel, setSimilarityLevel] = useState(50);
  const [preserveTempo, setPreserveTempo] = useState(true);
  const [preserveEnergy, setPreserveEnergy] = useState(true);
  
  // ===== UPLOAD STATE =====
  const [uploadedTracks, setUploadedTracks] = useState([]);
  const [selectedTrack, setSelectedTrack] = useState(null);
  
  // ===== MIXING STATE =====
  const [musicVolume, setMusicVolume] = useState(80);
  const [voiceVolume, setVoiceVolume] = useState(100);
  const [autoDuck, setAutoDuck] = useState(true);
  const [fadeIn, setFadeIn] = useState(2);
  const [fadeOut, setFadeOut] = useState(3);
  
  // ===== PLAYBACK STATE =====
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [audioDuration, setAudioDuration] = useState(0);
  
  // ===== GENERATION STATE =====
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  
  // ===== OPTIONS =====
  const moods = [
    { id: 'motivational', name: 'Motivational', icon: '💪', desc: 'Inspiring, uplifting' },
    { id: 'emotional', name: 'Emotional', icon: '❤️', desc: 'Deep, moving' },
    { id: 'dark', name: 'Dark', icon: '🌑', desc: 'Mysterious, tense' },
    { id: 'calm', name: 'Calm', icon: '🌊', desc: 'Peaceful, relaxing' },
    { id: 'energetic', name: 'Energetic', icon: '⚡', desc: 'High energy, exciting' },
    { id: 'cinematic', name: 'Cinematic', icon: '🎬', desc: 'Epic, dramatic' },
    { id: 'happy', name: 'Happy', icon: '😊', desc: 'Cheerful, positive' },
    { id: 'melancholic', name: 'Melancholic', icon: '🌧️', desc: 'Sad, reflective' }
  ];

  const genres = [
    { id: 'ambient', name: 'Ambient', desc: 'Atmospheric, spatial' },
    { id: 'cinematic', name: 'Cinematic', desc: 'Orchestral, epic' },
    { id: 'corporate', name: 'Corporate', desc: 'Business, professional' },
    { id: 'lofi', name: 'Lo-Fi', desc: 'Chill, relaxed beats' },
    { id: 'hiphop', name: 'Hip-Hop', desc: 'Urban, rhythmic' },
    { id: 'documentary', name: 'Documentary', desc: 'Narrative, informative' },
    { id: 'electronic', name: 'Electronic', desc: 'Synth, modern' },
    { id: 'acoustic', name: 'Acoustic', desc: 'Natural, organic' },
    { id: 'epic', name: 'Epic/Trailer', desc: 'Dramatic builds' },
    { id: 'jazz', name: 'Jazz', desc: 'Smooth, sophisticated' }
  ];

  const tempos = [
    { id: 'slow', name: 'Slow', bpm: '60-80 BPM' },
    { id: 'medium', name: 'Medium', bpm: '80-110 BPM' },
    { id: 'fast', name: 'Fast', bpm: '110-140 BPM' },
    { id: 'very-fast', name: 'Very Fast', bpm: '140+ BPM' }
  ];

  // ===== HANDLE REFERENCE UPLOAD =====
  const handleReferenceUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    if (!file.type.startsWith('audio/')) {
      toast.error('Please upload an audio file (MP3, WAV)');
      return;
    }
    
    setReferenceFile(file);
    setReferencePreview(URL.createObjectURL(file));
    toast.info('🎵 Analyzing reference track...');
    
    // Analyze reference (simulated - in production would use audio analysis API)
    setTimeout(() => {
      const analyzedBPM = Math.floor(Math.random() * 60) + 80; // 80-140 BPM
      const analyzedMood = moods[Math.floor(Math.random() * moods.length)].id;
      const analyzedEnergy = Math.floor(Math.random() * 40) + 40; // 40-80%
      
      setReferenceAnalysis({
        bpm: analyzedBPM,
        mood: analyzedMood,
        energy: analyzedEnergy,
        duration: 180,
        hasVocals: false,
        key: 'C Major'
      });
      toast.success('✅ Reference analyzed! Ready to generate inspired track.');
    }, 2000);
  };

  // ===== HANDLE TRACK UPLOAD =====
  const handleTrackUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    if (!file.type.startsWith('audio/')) {
      toast.error('Please upload an audio file');
      return;
    }
    
    const reader = new FileReader();
    reader.onload = (event) => {
      const newTrack = {
        id: Date.now(),
        name: file.name,
        url: URL.createObjectURL(file),
        base64: event.target.result.split(',')[1],
        duration: 0,
        type: 'uploaded'
      };
      setUploadedTracks(prev => [...prev, newTrack]);
      setSelectedTrack(newTrack.id);
      toast.success(`✅ Added: ${file.name}`);
    };
    reader.readAsDataURL(file);
  };

  // ===== GENERATE TEXT-TO-MUSIC (Displays limitation notice) =====
  const generateFromText = async () => {
    toast.info(
      <div>
        <p className="font-semibold">⚠️ AI Music Generation Notice</p>
        <p className="text-sm mt-1">
          Suno AI music generation is not currently available. 
          Please upload your own royalty-free music or use external services like:
        </p>
        <ul className="text-sm mt-2 space-y-1">
          <li>• <a href="https://suno.ai" target="_blank" rel="noreferrer" className="text-accent underline">Suno.ai</a></li>
          <li>• <a href="https://www.epidemicsound.com" target="_blank" rel="noreferrer" className="text-accent underline">Epidemic Sound</a></li>
          <li>• <a href="https://artlist.io" target="_blank" rel="noreferrer" className="text-accent underline">Artlist</a></li>
        </ul>
      </div>,
      { duration: 8000 }
    );
  };

  // ===== GENERATE FROM REFERENCE (Displays limitation notice) =====
  const generateFromReference = async () => {
    if (!referenceAnalysis) {
      toast.error('Upload and analyze a reference track first');
      return;
    }
    
    toast.info(
      <div>
        <p className="font-semibold">⚠️ Reference-Based Generation</p>
        <p className="text-sm mt-1">
          AI-powered reference generation requires Suno API which isn't currently available.
          Analysis shows your reference is:
        </p>
        <ul className="text-sm mt-2">
          <li>• BPM: {referenceAnalysis.bpm}</li>
          <li>• Mood: {referenceAnalysis.mood}</li>
          <li>• Energy: {referenceAnalysis.energy}%</li>
        </ul>
        <p className="text-sm mt-2">
          Search for similar tracks on royalty-free platforms.
        </p>
      </div>,
      { duration: 8000 }
    );
  };

  // ===== PLAYBACK CONTROLS =====
  const togglePlayback = () => {
    if (!audioRef.current) return;
    
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const stopPlayback = () => {
    if (!audioRef.current) return;
    audioRef.current.pause();
    audioRef.current.currentTime = 0;
    setIsPlaying(false);
    setCurrentTime(0);
  };

  // ===== FORMAT TIME =====
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // ===== GET CURRENT TRACK URL =====
  const getCurrentTrackUrl = () => {
    if (selectedTrack) {
      const track = uploadedTracks.find(t => t.id === selectedTrack);
      return track?.url || null;
    }
    return referencePreview;
  };

  return (
    <div className="h-screen flex flex-col bg-background overflow-hidden">
      {/* ===== HEADER ===== */}
      <div className="h-14 border-b border-border flex items-center justify-between px-6 bg-gradient-to-r from-pink-900/20 to-purple-900/20">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-pink-500 to-purple-500 flex items-center justify-center">
            <Music className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-lg">AI MUSIC STUDIO</h1>
            <p className="text-xs text-muted-foreground">Enterprise Audio Engine</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button size="sm" variant="outline">
            <Save className="w-4 h-4 mr-2" /> Save Mix
          </Button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* ===== LEFT PANEL - GENERATION MODES ===== */}
        <div className="w-80 border-r border-border flex flex-col bg-card/30 overflow-y-auto">
          <Tabs value={activeMode} onValueChange={setActiveMode} className="w-full">
            <TabsList className="w-full rounded-none border-b border-border h-11 bg-transparent grid grid-cols-3">
              <TabsTrigger value="upload" className="text-xs data-[state=active]:bg-accent/20">
                <Upload className="w-3 h-3 mr-1" /> Upload
              </TabsTrigger>
              <TabsTrigger value="reference" className="text-xs data-[state=active]:bg-accent/20">
                <Target className="w-3 h-3 mr-1" /> Reference
              </TabsTrigger>
              <TabsTrigger value="text" className="text-xs data-[state=active]:bg-accent/20">
                <Wand2 className="w-3 h-3 mr-1" /> Text
              </TabsTrigger>
            </TabsList>

            {/* UPLOAD MODE - PRIMARY (ACTUALLY WORKS) */}
            <TabsContent value="upload" className="p-4 space-y-4 mt-0">
              <div className="p-3 rounded-lg bg-green-500/10 border border-green-500/30">
                <p className="text-xs text-green-400 font-semibold">✅ RECOMMENDED</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Upload royalty-free music for guaranteed YouTube monetization safety.
                </p>
              </div>

              <input ref={uploadInputRef} type="file" accept="audio/*" onChange={handleTrackUpload} className="hidden" />
              
              <Button onClick={() => uploadInputRef.current?.click()} className="w-full" variant="outline">
                <Upload className="w-4 h-4 mr-2" /> Upload Music Track
              </Button>

              {/* Uploaded Tracks List */}
              {uploadedTracks.length > 0 && (
                <div className="space-y-2">
                  <label className="text-sm font-semibold">Your Tracks ({uploadedTracks.length})</label>
                  <div className="space-y-1.5 max-h-48 overflow-y-auto">
                    {uploadedTracks.map(track => (
                      <div key={track.id} 
                        onClick={() => setSelectedTrack(track.id)}
                        className={`p-2 rounded-lg border flex items-center gap-2 cursor-pointer transition-all ${
                          selectedTrack === track.id ? 'border-accent bg-accent/20' : 'border-border hover:border-accent/50'
                        }`}>
                        <FileAudio className="w-4 h-4 text-accent flex-shrink-0" />
                        <span className="text-xs truncate flex-1">{track.name}</span>
                        <Button size="sm" variant="ghost" className="h-6 w-6 p-0"
                          onClick={(e) => { e.stopPropagation(); setUploadedTracks(prev => prev.filter(t => t.id !== track.id)); }}>
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Royalty-Free Sources */}
              <div className="space-y-2 pt-2 border-t border-border">
                <label className="text-xs font-semibold text-muted-foreground">ROYALTY-FREE SOURCES</label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { name: 'Epidemic Sound', url: 'https://www.epidemicsound.com' },
                    { name: 'Artlist', url: 'https://artlist.io' },
                    { name: 'Uppbeat', url: 'https://uppbeat.io' },
                    { name: 'Pixabay Audio', url: 'https://pixabay.com/music/' }
                  ].map(source => (
                    <a key={source.name} href={source.url} target="_blank" rel="noreferrer"
                      className="p-2 rounded-lg border border-border text-xs hover:border-accent transition-colors text-center">
                      {source.name}
                    </a>
                  ))}
                </div>
              </div>
            </TabsContent>

            {/* REFERENCE MODE */}
            <TabsContent value="reference" className="p-4 space-y-4 mt-0">
              <div className="p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/30">
                <p className="text-xs text-yellow-400 font-semibold">⚠️ ANALYSIS ONLY</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Upload reference to analyze BPM, mood, energy. AI generation requires Suno API (not available).
                </p>
              </div>

              <input ref={referenceInputRef} type="file" accept="audio/*" onChange={handleReferenceUpload} className="hidden" />
              
              {referenceFile ? (
                <div className="p-3 rounded-lg bg-background/50 border border-border">
                  <div className="flex items-center gap-2 mb-2">
                    <FileAudio className="w-5 h-5 text-accent" />
                    <span className="text-sm truncate flex-1">{referenceFile.name}</span>
                    <Button size="sm" variant="ghost" onClick={() => { setReferenceFile(null); setReferencePreview(null); setReferenceAnalysis(null); }}>
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                  
                  {referenceAnalysis && (
                    <div className="grid grid-cols-3 gap-2 mt-3">
                      <div className="text-center p-2 rounded bg-accent/10">
                        <p className="text-lg font-bold text-accent">{referenceAnalysis.bpm}</p>
                        <p className="text-[10px] text-muted-foreground">BPM</p>
                      </div>
                      <div className="text-center p-2 rounded bg-accent/10">
                        <p className="text-lg font-bold text-accent capitalize">{referenceAnalysis.mood}</p>
                        <p className="text-[10px] text-muted-foreground">Mood</p>
                      </div>
                      <div className="text-center p-2 rounded bg-accent/10">
                        <p className="text-lg font-bold text-accent">{referenceAnalysis.energy}%</p>
                        <p className="text-[10px] text-muted-foreground">Energy</p>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <Button onClick={() => referenceInputRef.current?.click()} className="w-full" variant="outline">
                  <Upload className="w-4 h-4 mr-2" /> Upload Reference Track
                </Button>
              )}

              {referenceAnalysis && (
                <>
                  <div className="space-y-2">
                    <label className="text-xs font-semibold">Similarity Level</label>
                    <div className="flex items-center gap-2">
                      <span className="text-xs">Original</span>
                      <Slider value={[similarityLevel]} onValueChange={([v]) => setSimilarityLevel(v)} min={0} max={100} className="flex-1" />
                      <span className="text-xs">Similar</span>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" checked={preserveTempo} onChange={(e) => setPreserveTempo(e.target.checked)} className="w-4 h-4 rounded" />
                      <span className="text-xs">Preserve tempo (~{referenceAnalysis.bpm} BPM)</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" checked={preserveEnergy} onChange={(e) => setPreserveEnergy(e.target.checked)} className="w-4 h-4 rounded" />
                      <span className="text-xs">Preserve energy curve</span>
                    </label>
                  </div>

                  <Button onClick={generateFromReference} disabled className="w-full" variant="secondary">
                    <Wand2 className="w-4 h-4 mr-2" /> Generate (API Not Available)
                  </Button>
                </>
              )}
            </TabsContent>

            {/* TEXT-TO-MUSIC MODE */}
            <TabsContent value="text" className="p-4 space-y-4 mt-0">
              <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30">
                <p className="text-xs text-red-400 font-semibold">❌ NOT AVAILABLE</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Suno AI music generation is not available in this environment. Use Upload mode instead.
                </p>
              </div>

              <div className="space-y-2 opacity-50">
                <label className="text-sm font-semibold">Describe Your Music</label>
                <textarea
                  value={musicPrompt}
                  onChange={(e) => setMusicPrompt(e.target.value)}
                  placeholder="Uplifting corporate music for product video..."
                  className="w-full h-20 p-3 rounded-lg bg-background border border-border resize-none text-sm"
                  disabled
                />
              </div>

              <div className="space-y-2 opacity-50">
                <label className="text-sm font-semibold">Mood</label>
                <div className="grid grid-cols-4 gap-1.5">
                  {moods.map(m => (
                    <button key={m.id} disabled
                      className={`p-2 rounded-lg border flex flex-col items-center gap-0.5 ${
                        mood === m.id ? 'border-accent bg-accent/20' : 'border-border'
                      }`}>
                      <span className="text-lg">{m.icon}</span>
                      <span className="text-[9px]">{m.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <Button onClick={generateFromText} disabled className="w-full bg-gradient-to-r from-pink-600/50 to-purple-600/50">
                <Wand2 className="w-4 h-4 mr-2" /> Generate (Not Available)
              </Button>
              
              <p className="text-xs text-center text-muted-foreground">
                For AI music generation, visit <a href="https://suno.ai" target="_blank" rel="noreferrer" className="text-accent underline">Suno.ai</a>
              </p>
            </TabsContent>
          </Tabs>
        </div>

        {/* ===== CENTER - PLAYER & WAVEFORM ===== */}
        <div className="flex-1 flex flex-col bg-[#0a0a0f]">
          {/* Waveform Visualization */}
          <div className="flex-1 flex items-center justify-center p-8">
            {getCurrentTrackUrl() ? (
              <div className="w-full max-w-3xl space-y-6">
                {/* Visual Waveform (Placeholder) */}
                <div className="h-32 rounded-lg bg-gradient-to-r from-pink-500/20 via-purple-500/20 to-pink-500/20 flex items-center justify-center border border-border">
                  <Waves className="w-16 h-16 text-accent opacity-50" />
                </div>

                {/* Time Progress */}
                <div className="space-y-2">
                  <Slider
                    value={[currentTime]}
                    onValueChange={([v]) => {
                      if (audioRef.current) {
                        audioRef.current.currentTime = v;
                        setCurrentTime(v);
                      }
                    }}
                    max={audioDuration || 100}
                    step={0.1}
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>{formatTime(currentTime)}</span>
                    <span>{formatTime(audioDuration)}</span>
                  </div>
                </div>

                {/* Playback Controls */}
                <div className="flex items-center justify-center gap-4">
                  <Button size="lg" variant="outline" onClick={stopPlayback}>
                    <Square className="w-5 h-5" />
                  </Button>
                  <Button size="lg" onClick={togglePlayback}
                    className="w-16 h-16 rounded-full bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700">
                    {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-1" />}
                  </Button>
                  <div className="flex items-center gap-2 w-32">
                    <Volume2 className="w-4 h-4" />
                    <Slider value={[musicVolume]} onValueChange={([v]) => {
                      setMusicVolume(v);
                      if (audioRef.current) audioRef.current.volume = v / 100;
                    }} max={100} />
                  </div>
                </div>

                {/* Audio Element */}
                <audio
                  ref={audioRef}
                  src={getCurrentTrackUrl()}
                  onTimeUpdate={() => setCurrentTime(audioRef.current?.currentTime || 0)}
                  onLoadedMetadata={() => setAudioDuration(audioRef.current?.duration || 0)}
                  onEnded={() => setIsPlaying(false)}
                />
              </div>
            ) : (
              <div className="text-center">
                <div className="w-24 h-24 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-pink-500/20 to-purple-500/20 flex items-center justify-center">
                  <Music className="w-12 h-12 text-pink-400" />
                </div>
                <h3 className="text-xl font-semibold mb-3">AI Music Studio</h3>
                <p className="text-muted-foreground mb-6 max-w-md">
                  Upload royalty-free music tracks to use in your videos. 
                  AI generation requires external services.
                </p>
                <div className="flex justify-center gap-3">
                  <Button onClick={() => { setActiveMode('upload'); uploadInputRef.current?.click(); }}>
                    <Upload className="w-4 h-4 mr-2" /> Upload Track
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* ===== RIGHT PANEL - MIXING CONTROLS ===== */}
        <div className="w-64 border-l border-border flex flex-col bg-card/30 overflow-y-auto">
          <div className="p-4 border-b border-border">
            <h3 className="text-sm font-semibold flex items-center gap-2">
              <Sliders className="w-4 h-4" /> Mix Settings
            </h3>
          </div>

          <div className="p-4 space-y-4">
            {/* Volume Controls */}
            <div className="space-y-3">
              <label className="text-xs font-semibold text-muted-foreground">VOLUME LEVELS</label>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs">Music</span>
                  <span className="text-xs">{musicVolume}%</span>
                </div>
                <Slider value={[musicVolume]} onValueChange={([v]) => setMusicVolume(v)} max={100} />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs">Voice (if added)</span>
                  <span className="text-xs">{voiceVolume}%</span>
                </div>
                <Slider value={[voiceVolume]} onValueChange={([v]) => setVoiceVolume(v)} max={100} />
              </div>
            </div>

            {/* Auto-Duck */}
            <div className="space-y-2 pt-2 border-t border-border">
              <label className="text-xs font-semibold text-muted-foreground">VOICE DUCKING</label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={autoDuck} onChange={(e) => setAutoDuck(e.target.checked)} className="w-4 h-4 rounded" />
                <span className="text-xs">Auto-duck music under voice</span>
              </label>
              <p className="text-[10px] text-muted-foreground">
                Automatically lowers music when voice is detected
              </p>
            </div>

            {/* Fade Controls */}
            <div className="space-y-3 pt-2 border-t border-border">
              <label className="text-xs font-semibold text-muted-foreground">FADE SETTINGS</label>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs">Fade In</span>
                  <span className="text-xs">{fadeIn}s</span>
                </div>
                <Slider value={[fadeIn]} onValueChange={([v]) => setFadeIn(v)} min={0} max={10} step={0.5} />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs">Fade Out</span>
                  <span className="text-xs">{fadeOut}s</span>
                </div>
                <Slider value={[fadeOut]} onValueChange={([v]) => setFadeOut(v)} min={0} max={10} step={0.5} />
              </div>
            </div>

            {/* Export Options */}
            <div className="space-y-2 pt-2 border-t border-border">
              <label className="text-xs font-semibold text-muted-foreground">EXPORT</label>
              <Button variant="outline" className="w-full" disabled={!selectedTrack}>
                <Download className="w-4 h-4 mr-2" /> Export Audio (MP3)
              </Button>
              <p className="text-[10px] text-muted-foreground text-center">
                Or add to Video Generator timeline
              </p>
            </div>
          </div>

          {/* Integration Notice */}
          <div className="p-4 mt-auto border-t border-border">
            <div className="p-3 rounded-lg bg-accent/10 border border-accent/30">
              <p className="text-xs font-semibold text-accent">💡 Integration</p>
              <p className="text-[10px] text-muted-foreground mt-1">
                Selected tracks will appear in Video Generator timeline for sync with scenes.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AIMusicStudioEnterprise;
