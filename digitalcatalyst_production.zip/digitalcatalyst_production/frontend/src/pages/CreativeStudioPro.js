import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useLocation, useNavigate } from 'react-router-dom';
import { 
  Scissors, Type, Sparkles, Download, Upload, Layers, 
  RotateCw, Crop, Palette, Sliders, Play, Pause, Volume2, Film,
  Undo, Redo, FlipHorizontal, FlipVertical, Trash2, ZoomIn, ZoomOut,
  Grid, Maximize, Share2, Save, Subtitles, Zap, Gauge, Info,
  Wand2, Image as ImageIcon, Loader2
} from 'lucide-react';
import { Button } from '../components/ui/button';
import { Slider } from '../components/ui/slider';
import { Input } from '../components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { SketchPicker } from 'react-color';
import { toast } from 'sonner';

const CreativeStudioPro = () => {
  const { user } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const dashboardContext = location.state || null;
  
  const [mode, setMode] = useState('image');
  const [activeTab, setActiveTab] = useState('edit'); // 'edit' or 'generate'
  const [file, setFile] = useState(null);
  const [fileURL, setFileURL] = useState(null);
  
  // AI Generation States
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiStyle, setAiStyle] = useState('photoreal');
  const [aiAspectRatio, setAiAspectRatio] = useState('1:1');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImageBase64, setGeneratedImageBase64] = useState(null);
  
  // Script Panel States
  const [showScriptPanel, setShowScriptPanel] = useState(!!dashboardContext?.generatedScript);
  const [currentScript, setCurrentScript] = useState(dashboardContext?.generatedScript || '');
  const [scriptHooks, setScriptHooks] = useState(dashboardContext?.generatedHooks || '[]');
  const [selectedHook, setSelectedHook] = useState(0);
  const [scriptCaption, setScriptCaption] = useState(dashboardContext?.generatedCaption || '');
  
  // Image Editor States
  const [brightness, setBrightness] = useState(100);
  const [contrast, setContrast] = useState(100);
  const [saturation, setSaturation] = useState(100);
  const [blur, setBlur] = useState(0);
  const [rotation, setRotation] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [flipH, setFlipH] = useState(false);
  const [flipV, setFlipV] = useState(false);
  const [vignette, setVignette] = useState(0);
  
  // Crop States
  const [isCropping, setIsCropping] = useState(false);
  const [cropAspect, setCropAspect] = useState('free');
  
  // Text Overlay States
  const [textLayers, setTextLayers] = useState([]);
  const [selectedLayer, setSelectedLayer] = useState(null);
  const [newText, setNewText] = useState('');
  const [textFont, setTextFont] = useState('Arial');
  const [textSize, setTextSize] = useState(48);
  const [textColor, setTextColor] = useState('#ffffff');
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [textStroke, setTextStroke] = useState(false);
  const [textShadow, setTextShadow] = useState(false);
  
  // Safe Area & Guides
  const [showSafeArea, setShowSafeArea] = useState(false);
  const [safeAreaType, setSafeAreaType] = useState('shorts'); // 'shorts', 'reels', 'tiktok'
  
  // Smart Resize
  const [targetPlatform, setTargetPlatform] = useState('youtube');
  
  // History (Undo/Redo)
  const [history, setHistory] = useState([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  
  // Export Options
  const [exportFormat, setExportFormat] = useState('png');
  const [exportQuality, setExportQuality] = useState(90);
  
  // Video Editor States
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [videoAspectRatio, setVideoAspectRatio] = useState('16:9');
  
  // Video Trimming
  const [trimStart, setTrimStart] = useState(0);
  const [trimEnd, setTrimEnd] = useState(0);
  
  // Video Text Overlays (Timed)
  const [videoTextLayers, setVideoTextLayers] = useState([]);
  
  // Captions
  const [captions, setCaptions] = useState([]);
  const [captionStyle, setCaptionStyle] = useState(dashboardContext?.captionStyle || 'pop');
  
  const canvasRef = useRef(null);
  const videoRef = useRef(null);
  const fileInputRef = useRef(null);
  const imageRef = useRef(null);

  // Initialize with dashboard context
  useEffect(() => {
    if (dashboardContext) {
      // Set aspect ratio if provided
      if (dashboardContext.aspectRatio) {
        setVideoAspectRatio(dashboardContext.aspectRatio);
        setCropAspect(dashboardContext.aspectRatio);
      }
      
      // Show context banner
      toast.success(`Ready to create: ${dashboardContext.topic || dashboardContext.format}`, {
        duration: 5000
      });
    }
  }, [dashboardContext]);

  // Save project function
  const saveProject = async () => {
    if (!user) return;

    try {
      const API_URL = process.env.REACT_APP_BACKEND_URL;
      const projectData = {
        user_id: user.id,
        type: mode,
        status: 'completed',
        metadata: {
          source_dashboard: dashboardContext?.source || 'Manual',
          topic: dashboardContext?.topic,
          hook: dashboardContext?.hook,
          format: dashboardContext?.format,
          trend_tag: dashboardContext?.trendTag,
          opportunity: dashboardContext?.opportunity,
          expected_views: dashboardContext?.expectedViews,
          created_at: new Date().toISOString()
        }
      };

      const response = await fetch(`${API_URL}/api/projects`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(projectData)
      });

      if (response.ok) {
        toast.success('Project saved! Check Projects page.');
      }
    } catch (error) {
      console.error('Save project error:', error);
      toast.error('Failed to save project');
    }
  };

  const fonts = ['Arial', 'Helvetica', 'Times New Roman', 'Courier New', 'Verdana', 
                 'Georgia', 'Palatino', 'Garamond', 'Bookman', 'Comic Sans MS',
                 'Trebuchet MS', 'Impact'];

  // AI Image Generation Styles
  const aiStyles = [
    { name: 'Cinematic', value: 'cinematic', desc: 'Film-like dramatic lighting' },
    { name: 'Photorealistic', value: 'photoreal', desc: 'Hyper-realistic photography' },
    { name: 'Product', value: 'product', desc: 'Clean studio product shots' },
    { name: 'Illustration', value: 'illustration', desc: 'Digital art style' },
    { name: 'Minimal', value: 'minimal', desc: 'Simple, clean compositions' },
    { name: 'Anime', value: 'anime', desc: 'Japanese anime style' }
  ];

  // AI Aspect Ratios
  const aiAspectRatios = [
    { name: '1:1 (Square)', value: '1:1' },
    { name: '16:9 (Landscape)', value: '16:9' },
    { name: '9:16 (Portrait/Shorts)', value: '9:16' },
    { name: '4:5 (Instagram)', value: '4:5' }
  ];

  const aspectRatios = [
    { name: 'Free', value: 'free', ratio: null },
    { name: '9:16 (Shorts/Reels)', value: '9:16', ratio: 9/16 },
    { name: '16:9 (YouTube)', value: '16:9', ratio: 16/9 },
    { name: '1:1 (Instagram Feed)', value: '1:1', ratio: 1 },
    { name: '4:5 (Instagram Ads)', value: '4:5', ratio: 4/5 },
    { name: '3:4 (Mobile-first)', value: '3:4', ratio: 3/4 }
  ];

  const exportPresets = [
    { name: '1280×720 (YouTube Thumbnail)', value: 'yt-thumb', width: 1280, height: 720 },
    { name: '1920×1080 (Full HD)', value: 'fullhd', width: 1920, height: 1080 },
    { name: '1080×1920 (Vertical HD)', value: 'vertical-hd', width: 1080, height: 1920 },
    { name: '1080×1080 (Instagram Post)', value: 'instagram', width: 1080, height: 1080 },
    { name: '1080×1350 (Instagram Portrait)', value: 'ig-portrait', width: 1080, height: 1350 },
    { name: '1200×628 (Facebook/LinkedIn)', value: 'social', width: 1200, height: 628 }
  ];

  const presetFilters = [
    { name: 'None', value: 'none' },
    { name: 'Vintage', value: 'vintage' },
    { name: 'B&W', value: 'bw' },
    { name: 'Cool', value: 'cool' },
    { name: 'Warm', value: 'warm' },
    { name: 'High Contrast', value: 'highcontrast' },
    { name: 'Dreamy', value: 'dreamy' },
    { name: 'Cinematic', value: 'cinematic' }
  ];

  useEffect(() => {
    if (file && mode === 'image' && activeTab === 'edit') {
      // Small delay to ensure canvas is mounted after tab switch
      const timer = setTimeout(() => {
        renderCanvas();
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [brightness, contrast, saturation, blur, rotation, zoom, flipH, flipV, vignette, textLayers, file, activeTab]);

  useEffect(() => {
    if (videoRef.current && mode === 'video') {
      videoRef.current.playbackRate = playbackSpeed;
    }
  }, [playbackSpeed]);

  const handleFileUpload = (e) => {
    const uploadedFile = e.target.files[0];
    if (!uploadedFile) return;

    const url = URL.createObjectURL(uploadedFile);
    setFile(uploadedFile);
    setFileURL(url);

    if (mode === 'image') {
      const img = new Image();
      img.onload = () => {
        imageRef.current = img;
        renderCanvas();
        saveToHistory();
      };
      img.src = url;
      toast.success('Image loaded successfully!');
    } else {
      if (videoRef.current) {
        videoRef.current.src = url;
      }
      toast.success('Video loaded successfully!');
    }
  };

  const renderCanvas = () => {
    if (!canvasRef.current || !imageRef.current || mode !== 'image') return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const img = imageRef.current;
    
    canvas.width = img.width;
    canvas.height = img.height;
    
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.save();
    
    // Apply transforms
    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.rotate((rotation * Math.PI) / 180);
    ctx.scale((flipH ? -1 : 1) * zoom, (flipV ? -1 : 1) * zoom);
    ctx.translate(-canvas.width / 2, -canvas.height / 2);
    
    // Apply filters
    const filterString = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%) blur(${blur}px)`;
    ctx.filter = filterString;
    
    ctx.drawImage(img, 0, 0);
    ctx.restore();
    
    // Apply vignette
    if (vignette > 0) {
      const gradient = ctx.createRadialGradient(
        canvas.width / 2, canvas.height / 2, 0,
        canvas.width / 2, canvas.height / 2, Math.max(canvas.width, canvas.height) / 2
      );
      gradient.addColorStop(0, `rgba(0, 0, 0, 0)`);
      gradient.addColorStop(1, `rgba(0, 0, 0, ${vignette / 100})`);
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }
    
    // Draw text layers
    textLayers.forEach((layer) => {
      ctx.font = `${layer.size}px ${layer.font}`;
      ctx.fillStyle = layer.color;
      
      if (layer.stroke) {
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 3;
        ctx.strokeText(layer.text, layer.x, layer.y);
      }
      
      if (layer.shadow) {
        ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
        ctx.shadowBlur = 10;
        ctx.shadowOffsetX = 3;
        ctx.shadowOffsetY = 3;
      }
      
      ctx.fillText(layer.text, layer.x, layer.y);
      ctx.shadowColor = 'transparent';
    });

    // Draw safe area guides if enabled
    if (showSafeArea) {
      drawSafeAreaGuides(ctx, canvas.width, canvas.height);
    }
  };

  const drawSafeAreaGuides = (ctx, width, height) => {
    ctx.save();
    ctx.strokeStyle = '#00ff00';
    ctx.lineWidth = 2;
    ctx.setLineDash([5, 5]);
    
    // YouTube Shorts / Reels safe areas (9:16)
    const safeMargin = 0.1; // 10% margin
    const topMargin = height * safeMargin;
    const bottomMargin = height * (1 - safeMargin);
    const leftMargin = width * safeMargin;
    const rightMargin = width * (1 - safeMargin);
    
    ctx.strokeRect(leftMargin, topMargin, rightMargin - leftMargin, bottomMargin - topMargin);
    
    // Center crosshair
    ctx.beginPath();
    ctx.moveTo(width / 2, 0);
    ctx.lineTo(width / 2, height);
    ctx.moveTo(0, height / 2);
    ctx.lineTo(width, height / 2);
    ctx.stroke();
    
    ctx.restore();
  };

  const addTextLayer = () => {
    if (!newText.trim()) {
      toast.error('Please enter text');
      return;
    }
    
    const layer = {
      id: Date.now(),
      text: newText,
      x: 100,
      y: 100 + (textLayers.length * 60),
      size: textSize,
      color: textColor,
      font: textFont,
      stroke: textStroke,
      shadow: textShadow
    };
    
    setTextLayers([...textLayers, layer]);
    setNewText('');
    saveToHistory();
    toast.success('Text layer added!');
  };

  const deleteTextLayer = (id) => {
    setTextLayers(textLayers.filter(l => l.id !== id));
    saveToHistory();
    toast.info('Text layer removed');
  };

  const applyFilter = (filterName) => {
    switch(filterName) {
      case 'vintage':
        setBrightness(110);
        setContrast(120);
        setSaturation(80);
        break;
      case 'bw':
        setSaturation(0);
        setContrast(110);
        break;
      case 'cool':
        setBrightness(105);
        setSaturation(120);
        break;
      case 'warm':
        setBrightness(110);
        setSaturation(130);
        setContrast(105);
        break;
      case 'highcontrast':
        setContrast(150);
        setSaturation(120);
        break;
      case 'dreamy':
        setBrightness(110);
        setContrast(90);
        setBlur(0.5);
        break;
      case 'cinematic':
        setContrast(115);
        setSaturation(85);
        setVignette(30);
        break;
      default:
        resetAdjustments();
    }
    saveToHistory();
  };

  const resetAdjustments = () => {
    setBrightness(100);
    setContrast(100);
    setSaturation(100);
    setBlur(0);
    setRotation(0);
    setZoom(1);
    setFlipH(false);
    setFlipV(false);
    setVignette(0);
    toast.info('All adjustments reset');
  };

  const saveToHistory = () => {
    const state = {
      brightness, contrast, saturation, blur, rotation, zoom,
      flipH, flipV, vignette, textLayers
    };
    const newHistory = history.slice(0, historyIndex + 1);
    setHistory([...newHistory, state]);
    setHistoryIndex(newHistory.length);
  };

  const undo = () => {
    if (historyIndex > 0) {
      const prevState = history[historyIndex - 1];
      restoreState(prevState);
      setHistoryIndex(historyIndex - 1);
      toast.info('Undo');
    }
  };

  const redo = () => {
    if (historyIndex < history.length - 1) {
      const nextState = history[historyIndex + 1];
      restoreState(nextState);
      setHistoryIndex(historyIndex + 1);
      toast.info('Redo');
    }
  };

  const restoreState = (state) => {
    setBrightness(state.brightness);
    setContrast(state.contrast);
    setSaturation(state.saturation);
    setBlur(state.blur);
    setRotation(state.rotation);
    setZoom(state.zoom);
    setFlipH(state.flipH);
    setFlipV(state.flipV);
    setVignette(state.vignette);
    setTextLayers(state.textLayers);
  };

  const smartResize = () => {
    const preset = exportPresets.find(p => p.value === targetPlatform);
    if (!preset || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = preset.width;
    tempCanvas.height = preset.height;
    const ctx = tempCanvas.getContext('2d');

    // Draw scaled image maintaining aspect ratio
    const srcRatio = canvas.width / canvas.height;
    const dstRatio = preset.width / preset.height;
    
    let drawWidth, drawHeight, offsetX = 0, offsetY = 0;
    
    if (srcRatio > dstRatio) {
      // Source is wider
      drawWidth = preset.width;
      drawHeight = preset.width / srcRatio;
      offsetY = (preset.height - drawHeight) / 2;
    } else {
      // Source is taller
      drawHeight = preset.height;
      drawWidth = preset.height * srcRatio;
      offsetX = (preset.width - drawWidth) / 2;
    }

    // Fill background with black
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, preset.width, preset.height);
    
    // Draw scaled image
    ctx.drawImage(canvas, offsetX, offsetY, drawWidth, drawHeight);

    // Replace current canvas
    canvasRef.current.width = preset.width;
    canvasRef.current.height = preset.height;
    canvasRef.current.getContext('2d').drawImage(tempCanvas, 0, 0);

    toast.success(`Resized to ${preset.name}!`);
    saveToHistory();
  };

  const removeBackground = () => {
    toast.info('Background removal coming soon! This will use AI to remove backgrounds in 1-click.');
  };

  const handleDownload = async () => {
    if (mode === 'image' && canvasRef.current) {
      const format = exportFormat === 'jpg' ? 'image/jpeg' : `image/${exportFormat}`;
      const quality = exportQuality / 100;
      
      const link = document.createElement('a');
      link.download = `edited-image-${Date.now()}.${exportFormat}`;
      link.href = canvasRef.current.toDataURL(format, quality);
      link.click();
      toast.success(`Downloaded as ${exportFormat.toUpperCase()}!`);
      
      // Save project after export
      await saveProject();
    } else if (mode === 'video') {
      toast.info('Video export: Use browser recording or wait for render feature!');
      
      // Save project metadata
      await saveProject();
    }
  };

  // Video Functions
  const togglePlayPause = () => {
    if (!videoRef.current) return;
    
    if (isPlaying) {
      videoRef.current.pause();
    } else {
      videoRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const handleVideoTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
    }
  };

  const handleVideoLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
      setTrimEnd(videoRef.current.duration);
    }
  };

  const handleSeek = (value) => {
    if (videoRef.current) {
      videoRef.current.currentTime = value[0];
      setCurrentTime(value[0]);
    }
  };

  const handleVolumeChange = (value) => {
    if (videoRef.current) {
      videoRef.current.volume = value[0];
      setVolume(value[0]);
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const generateCaptions = async () => {
    if (!file || mode !== 'video') {
      toast.error('Please upload a video first');
      return;
    }

    toast.info('Generating captions... This may take a moment.');
    
    try {
      const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
      const formData = new FormData();
      formData.append('video_file', file);

      const response = await fetch(`${BACKEND_URL}/api/creative-studio/generate-captions`, {
        method: 'POST',
        body: formData
      });

      if (!response.ok) {
        throw new Error('Caption generation failed');
      }

      const data = await response.json();
      
      if (data.success && data.captions) {
        setCaptions(data.captions);
        toast.success(`Generated ${data.captions.length} caption segments!`);
      } else {
        toast.error('No captions generated');
      }
    } catch (error) {
      console.error('Caption generation error:', error);
      toast.error(`Failed to generate captions: ${error.message}`);
    }
  };

  const detectSilence = async () => {
    if (!videoRef.current || mode !== 'video') {
      toast.error('Please upload a video first');
      return;
    }

    toast.info('Analyzing audio for silence...');

    try {
      const audioContext = new (window.AudioContext || window.webkitAudioContext)();
      const video = videoRef.current;
      
      // Create audio source from video
      const source = audioContext.createMediaElementSource(video);
      const analyser = audioContext.createAnalyser();
      analyser.fftSize = 2048;
      
      source.connect(analyser);
      analyser.connect(audioContext.destination);
      
      const bufferLength = analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);
      
      const silentSegments = [];
      let isSilent = false;
      let silentStart = 0;
      const SILENCE_THRESHOLD = 20; // Adjust sensitivity
      const MIN_SILENCE_DURATION = 0.5; // 0.5 seconds minimum
      
      const checkSilence = () => {
        analyser.getByteFrequencyData(dataArray);
        
        // Calculate average volume
        const average = dataArray.reduce((a, b) => a + b) / bufferLength;
        
        if (average < SILENCE_THRESHOLD) {
          if (!isSilent) {
            isSilent = true;
            silentStart = video.currentTime;
          }
        } else {
          if (isSilent && (video.currentTime - silentStart) >= MIN_SILENCE_DURATION) {
            silentSegments.push({
              start: silentStart,
              end: video.currentTime,
              duration: video.currentTime - silentStart
            });
          }
          isSilent = false;
        }
        
        if (video.currentTime < video.duration) {
          requestAnimationFrame(checkSilence);
        } else {
          // Analysis complete
          if (silentSegments.length > 0) {
            const totalSilence = silentSegments.reduce((sum, seg) => sum + seg.duration, 0);
            toast.success(
              `Found ${silentSegments.length} silent segments (${totalSilence.toFixed(1)}s total). Check console for details.`
            );
            console.log('Silent segments:', silentSegments);
          } else {
            toast.info('No significant silent segments detected');
          }
          video.pause();
          video.currentTime = 0;
        }
      };
      
      // Start analysis
      video.currentTime = 0;
      video.play();
      checkSilence();
      
    } catch (error) {
      console.error('Silence detection error:', error);
      toast.error(`Failed to detect silence: ${error.message}`);
    }
  };

  const extractThumbnail = () => {
    if (!videoRef.current) return;
    
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    canvas.getContext('2d').drawImage(videoRef.current, 0, 0);
    
    const link = document.createElement('a');
    link.download = `thumbnail-${Date.now()}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
    toast.success('Thumbnail extracted!');
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // AI Image Generation Function
  const generateAiImage = async () => {
    if (!aiPrompt.trim()) {
      toast.error('Please enter a prompt for image generation');
      return;
    }

    setIsGenerating(true);
    toast.info('Generating AI image... This may take a moment.');

    try {
      const API_URL = process.env.REACT_APP_BACKEND_URL;
      const response = await fetch(`${API_URL}/api/generate/image`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: aiPrompt,
          style: aiStyle,
          aspect_ratio: aiAspectRatio
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || 'Image generation failed');
      }

      const data = await response.json();

      if (data.success && data.image_base64) {
        // Store the base64 data
        setGeneratedImageBase64(data.image_base64);
        
        // Create image element and load into canvas
        const img = new Image();
        img.onload = () => {
          imageRef.current = img;
          
          // Create a file-like object for consistency
          setFile({ name: 'ai-generated-image.png', type: 'image/png' });
          setFileURL(`data:image/png;base64,${data.image_base64}`);
          
          // Switch to edit tab to show the image
          setActiveTab('edit');
          
          // Small delay to ensure tab switch completes before rendering
          setTimeout(() => {
            if (canvasRef.current && imageRef.current) {
              const canvas = canvasRef.current;
              const ctx = canvas.getContext('2d');
              canvas.width = img.width;
              canvas.height = img.height;
              ctx.drawImage(img, 0, 0);
              saveToHistory();
            }
          }, 200);
          
          toast.success('AI Image generated! Now editing...');
        };
        img.onerror = () => {
          toast.error('Failed to load generated image');
        };
        img.src = `data:image/png;base64,${data.image_base64}`;
      } else {
        throw new Error('No image data received');
      }
    } catch (error) {
      console.error('AI Image generation error:', error);
      toast.error(`Generation failed: ${error.message}`);
    } finally {
      setIsGenerating(false);
    }
  };

  // Load generated image into editor
  const loadGeneratedImageToEditor = () => {
    if (!generatedImageBase64) {
      toast.error('No generated image to load');
      return;
    }

    const img = new Image();
    img.onload = () => {
      imageRef.current = img;
      setFile({ name: 'ai-generated-image.png', type: 'image/png' });
      setFileURL(`data:image/png;base64,${generatedImageBase64}`);
      renderCanvas();
      saveToHistory();
      setActiveTab('edit');
      toast.success('Image loaded into editor!');
    };
    img.src = `data:image/png;base64,${generatedImageBase64}`;
  };

  return (
    <div className="p-8 max-w-[1800px] mx-auto fade-in">
      <div className="mb-6">
        <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
          <Sparkles className="text-primary" />
          Creative Studio PRO
        </h1>
        <p className="text-muted-foreground">Professional image and video editing with AI-powered features</p>
      </div>

      {/* Dashboard Context Banner */}
      {dashboardContext && (
        <div className="glass-panel p-4 mb-6 bg-primary/10 border border-primary/30">
          <div className="flex items-start gap-3">
            <Info className="text-primary mt-1" size={20} />
            <div className="flex-1">
              <div className="font-semibold mb-1">Context from {dashboardContext.source}</div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                {dashboardContext.topic && (
                  <div>
                    <span className="text-muted-foreground">Topic:</span>
                    <span className="ml-2 font-semibold">{dashboardContext.topic}</span>
                  </div>
                )}
                {dashboardContext.hook && (
                  <div>
                    <span className="text-muted-foreground">Hook:</span>
                    <span className="ml-2 font-semibold">{dashboardContext.hook}</span>
                  </div>
                )}
                {dashboardContext.format && (
                  <div>
                    <span className="text-muted-foreground">Format:</span>
                    <span className="ml-2 font-semibold">{dashboardContext.format}</span>
                  </div>
                )}
                {dashboardContext.aspectRatio && (
                  <div>
                    <span className="text-muted-foreground">Ratio:</span>
                    <span className="ml-2 font-semibold text-accent">{dashboardContext.aspectRatio}</span>
                  </div>
                )}
              </div>
              {dashboardContext.expectedViews && (
                <div className="mt-2 text-xs text-green-400">
                  💡 Expected Views: {dashboardContext.expectedViews}
                </div>
              )}
            </div>
            {showScriptPanel && (
              <Button
                onClick={() => setShowScriptPanel(!showScriptPanel)}
                className="btn-secondary text-xs"
                size="sm"
              >
                {showScriptPanel ? 'Hide Script' : 'Show Script'}
              </Button>
            )}
          </div>
        </div>
      )}

      {/* Script Panel */}
      {showScriptPanel && currentScript && (
        <div className="glass-panel p-6 mb-6 border-2 border-accent/30">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold flex items-center gap-2">
              <Type className="text-accent" />
              Generated Script
            </h2>
            <Button
              onClick={() => setShowScriptPanel(false)}
              className="btn-secondary text-xs"
              size="sm"
            >
              Close Panel
            </Button>
          </div>

          {/* Hook Variants */}
          {scriptHooks && scriptHooks !== '[]' && (
            <div className="mb-4">
              <label className="text-sm font-semibold mb-2 block">Hook Variants (Select One)</label>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {(() => {
                  try {
                    const hooks = JSON.parse(scriptHooks);
                    return hooks.map((h, idx) => (
                      <button
                        key={idx}
                        onClick={() => setSelectedHook(idx)}
                        className={`p-3 rounded-lg border text-left transition-all ${
                          selectedHook === idx
                            ? 'border-accent bg-accent/20 font-semibold'
                            : 'border-border bg-background/50 hover:border-accent/50'
                        }`}
                      >
                        <div className="text-xs text-accent mb-1">Variant {h.variant}</div>
                        <div className="text-sm">{h.hook}</div>
                      </button>
                    ));
                  } catch (e) {
                    return null;
                  }
                })()}
              </div>
            </div>
          )}

          {/* Script Content */}
          <div className="mb-4">
            <label className="text-sm font-semibold mb-2 block">Full Script (Editable)</label>
            <textarea
              value={currentScript}
              onChange={(e) => setCurrentScript(e.target.value)}
              className="w-full h-64 p-4 rounded-lg bg-background border border-border focus:border-accent resize-none font-mono text-sm"
              placeholder="Your script will appear here..."
            />
          </div>

          {/* Caption */}
          {scriptCaption && (
            <div>
              <label className="text-sm font-semibold mb-2 block">Suggested Caption</label>
              <textarea
                value={scriptCaption}
                onChange={(e) => setScriptCaption(e.target.value)}
                className="w-full h-20 p-3 rounded-lg bg-background border border-border focus:border-accent resize-none text-sm"
              />
            </div>
          )}
        </div>
      )}

      {/* Mode Selector */}
      <div className="glass-panel p-4 mb-6">
        <div className="flex flex-wrap gap-4">
          <Button
            onClick={() => { setMode('image'); setActiveTab('generate'); }}
            className={mode === 'image' && activeTab === 'generate' ? 'btn-primary' : 'btn-secondary'}
          >
            <Wand2 size={18} className="mr-2" />
            AI Generate
          </Button>
          <Button
            onClick={() => { setMode('image'); setActiveTab('edit'); }}
            className={mode === 'image' && activeTab === 'edit' ? 'btn-primary' : 'btn-secondary'}
          >
            <Palette size={18} className="mr-2" />
            Image Editor
          </Button>
          <Button
            onClick={() => { setMode('video'); setFile(null); setFileURL(null); }}
            className={mode === 'video' ? 'btn-primary' : 'btn-secondary'}
          >
            <Film size={18} className="mr-2" />
            Video Editor PRO
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
        {/* Tools Panel */}
        <div className="xl:col-span-1 space-y-4">
          <div className="glass-panel p-6 space-y-4">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              {activeTab === 'generate' ? (
                <>
                  <Wand2 size={20} className="text-accent" />
                  AI Image Generator
                </>
              ) : (
                <>
                  <Sliders size={20} className="text-primary" />
                  Tools
                </>
              )}
            </h2>

            {/* AI GENERATION PANEL */}
            {mode === 'image' && activeTab === 'generate' && (
              <div className="space-y-4">
                {/* Prompt Input */}
                <div>
                  <label className="text-sm font-semibold mb-2 block">Describe Your Image</label>
                  <textarea
                    value={aiPrompt}
                    onChange={(e) => setAiPrompt(e.target.value)}
                    placeholder="A stunning sunset over mountains with golden light reflecting on a crystal clear lake..."
                    className="w-full h-32 p-3 rounded-lg bg-background border border-border focus:border-accent resize-none text-sm"
                  />
                </div>

                {/* Style Selector */}
                <div>
                  <label className="text-sm font-semibold mb-2 block">Style</label>
                  <div className="grid grid-cols-2 gap-2">
                    {aiStyles.map((style) => (
                      <button
                        key={style.value}
                        onClick={() => setAiStyle(style.value)}
                        className={`p-2 rounded-lg border text-left transition-all ${
                          aiStyle === style.value
                            ? 'border-accent bg-accent/20'
                            : 'border-border bg-background/50 hover:border-accent/50'
                        }`}
                      >
                        <div className="text-xs font-semibold">{style.name}</div>
                        <div className="text-[10px] text-muted-foreground">{style.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Aspect Ratio Selector */}
                <div>
                  <label className="text-sm font-semibold mb-2 block">Aspect Ratio</label>
                  <Select value={aiAspectRatio} onValueChange={setAiAspectRatio}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select aspect ratio" />
                    </SelectTrigger>
                    <SelectContent>
                      {aiAspectRatios.map((ratio) => (
                        <SelectItem key={ratio.value} value={ratio.value}>
                          {ratio.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Generate Button */}
                <Button
                  onClick={generateAiImage}
                  disabled={isGenerating || !aiPrompt.trim()}
                  className="btn-primary w-full h-12 text-lg"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 size={20} className="mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Sparkles size={20} className="mr-2" />
                      Generate Image
                    </>
                  )}
                </Button>

                {/* Quick Actions After Generation */}
                {generatedImageBase64 && !isGenerating && (
                  <div className="space-y-2 pt-2 border-t border-border">
                    <p className="text-xs text-green-400 font-semibold">✓ Image Generated Successfully!</p>
                    <Button
                      onClick={loadGeneratedImageToEditor}
                      className="btn-secondary w-full"
                      size="sm"
                    >
                      <Palette size={16} className="mr-2" />
                      Edit This Image
                    </Button>
                  </div>
                )}

                {/* Tips */}
                <div className="text-xs text-muted-foreground space-y-1 pt-2 border-t border-border">
                  <p className="font-semibold text-foreground">💡 Tips for better results:</p>
                  <p>• Be specific about composition</p>
                  <p>• Mention lighting conditions</p>
                  <p>• Describe colors and mood</p>
                  <p>• Include quality keywords</p>
                </div>
              </div>
            )}

            {/* EDIT MODE TOOLS */}
            {(mode === 'video' || (mode === 'image' && activeTab === 'edit')) && (
              <>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept={mode === 'image' ? 'image/*' : 'video/*'}
                  onChange={handleFileUpload}
                  className="hidden"
                />
                
                <Button
                  onClick={() => fileInputRef.current?.click()}
                  className="btn-primary w-full"
                >
                  <Upload size={18} className="mr-2" />
                  Upload {mode === 'image' ? 'Image' : 'Video'}
                </Button>
              </>
            )}

            {file && mode === 'image' && activeTab === 'edit' && (
              <>
                {/* Undo/Redo */}
                <div className="flex gap-2">
                  <Button 
                    onClick={undo} 
                    disabled={historyIndex <= 0}
                    className="btn-secondary flex-1"
                    size="sm"
                  >
                    <Undo size={16} />
                  </Button>
                  <Button 
                    onClick={redo}
                    disabled={historyIndex >= history.length - 1}
                    className="btn-secondary flex-1"
                    size="sm"
                  >
                    <Redo size={16} />
                  </Button>
                </div>

                {/* Adjustments */}
                <div className="space-y-3 pt-2 border-t border-border">
                  <h3 className="text-sm font-semibold">Adjustments</h3>
                  
                  <div>
                    <label className="text-xs mb-1 block">Brightness</label>
                    <Slider
                      value={[brightness]}
                      onValueChange={(val) => setBrightness(val[0])}
                      min={0} max={200} step={1}
                    />
                    <span className="text-xs text-muted-foreground">{brightness}%</span>
                  </div>

                  <div>
                    <label className="text-xs mb-1 block">Contrast</label>
                    <Slider
                      value={[contrast]}
                      onValueChange={(val) => setContrast(val[0])}
                      min={0} max={200} step={1}
                    />
                    <span className="text-xs text-muted-foreground">{contrast}%</span>
                  </div>

                  <div>
                    <label className="text-xs mb-1 block">Saturation</label>
                    <Slider
                      value={[saturation]}
                      onValueChange={(val) => setSaturation(val[0])}
                      min={0} max={200} step={1}
                    />
                    <span className="text-xs text-muted-foreground">{saturation}%</span>
                  </div>

                  <div>
                    <label className="text-xs mb-1 block">Blur</label>
                    <Slider
                      value={[blur]}
                      onValueChange={(val) => setBlur(val[0])}
                      min={0} max={10} step={0.1}
                    />
                    <span className="text-xs text-muted-foreground">{blur.toFixed(1)}px</span>
                  </div>

                  <div>
                    <label className="text-xs mb-1 block">Vignette</label>
                    <Slider
                      value={[vignette]}
                      onValueChange={(val) => setVignette(val[0])}
                      min={0} max={100} step={1}
                    />
                    <span className="text-xs text-muted-foreground">{vignette}%</span>
                  </div>

                  <div>
                    <label className="text-xs mb-1 block">Rotation</label>
                    <Slider
                      value={[rotation]}
                      onValueChange={(val) => setRotation(val[0])}
                      min={0} max={360} step={1}
                    />
                    <span className="text-xs text-muted-foreground">{rotation}°</span>
                  </div>

                  <div>
                    <label className="text-xs mb-1 block">Zoom</label>
                    <Slider
                      value={[zoom]}
                      onValueChange={(val) => setZoom(val[0])}
                      min={0.5} max={3} step={0.1}
                    />
                    <span className="text-xs text-muted-foreground">{zoom.toFixed(1)}x</span>
                  </div>
                </div>

                {/* Transform */}
                <div className="space-y-2 pt-2 border-t border-border">
                  <h3 className="text-sm font-semibold">Transform</h3>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      onClick={() => { setFlipH(!flipH); saveToHistory(); }}
                      className={`btn-secondary text-xs ${flipH ? 'ring-2 ring-primary' : ''}`}
                      size="sm"
                    >
                      <FlipHorizontal size={14} className="mr-1" />
                      Flip H
                    </Button>
                    <Button
                      onClick={() => { setFlipV(!flipV); saveToHistory(); }}
                      className={`btn-secondary text-xs ${flipV ? 'ring-2 ring-primary' : ''}`}
                      size="sm"
                    >
                      <FlipVertical size={14} className="mr-1" />
                      Flip V
                    </Button>
                  </div>
                </div>

                {/* Filters */}
                <div className="space-y-2 pt-2 border-t border-border">
                  <h3 className="text-sm font-semibold">Filters</h3>
                  <div className="grid grid-cols-2 gap-2">
                    {presetFilters.map((filter) => (
                      <Button
                        key={filter.value}
                        onClick={() => applyFilter(filter.value)}
                        className="btn-secondary text-xs"
                        size="sm"
                      >
                        {filter.name}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* PRO Features */}
                <div className="space-y-2 pt-2 border-t border-border">
                  <h3 className="text-sm font-semibold flex items-center gap-2">
                    <Zap size={14} className="text-accent" />
                    PRO Features
                  </h3>
                  
                  <Button
                    onClick={() => setShowSafeArea(!showSafeArea)}
                    className={`btn-secondary w-full text-xs ${showSafeArea ? 'ring-2 ring-accent' : ''}`}
                    size="sm"
                  >
                    <Grid size={14} className="mr-1" />
                    Safe Area Guides
                  </Button>

                  <Button
                    onClick={removeBackground}
                    className="btn-secondary w-full text-xs"
                    size="sm"
                  >
                    <Scissors size={14} className="mr-1" />
                    Remove Background
                  </Button>

                  <div>
                    <label className="text-xs mb-1 block">Export Presets</label>
                    <Select value={targetPlatform} onValueChange={setTargetPlatform}>
                      <SelectTrigger className="text-xs h-8">
                        <SelectValue placeholder="Select preset..." />
                      </SelectTrigger>
                      <SelectContent>
                        {exportPresets.map((p) => (
                          <SelectItem key={p.value} value={p.value} className="text-xs">
                            {p.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Button
                      onClick={smartResize}
                      className="btn-secondary w-full text-xs mt-2"
                      size="sm"
                    >
                      <Maximize size={14} className="mr-1" />
                      Resize to Preset
                    </Button>
                  </div>
                </div>

                {/* Text Layers */}
                <div className="space-y-2 pt-2 border-t border-border">
                  <h3 className="text-sm font-semibold flex items-center gap-2">
                    <Type size={14} />
                    Text Layers ({textLayers.length})
                  </h3>
                  
                  <Input
                    value={newText}
                    onChange={(e) => setNewText(e.target.value)}
                    placeholder="Enter text..."
                    className="text-xs h-8"
                  />

                  <div className="grid grid-cols-2 gap-2">
                    <Select value={textFont} onValueChange={setTextFont}>
                      <SelectTrigger className="text-xs h-8">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {fonts.map((f) => (
                          <SelectItem key={f} value={f} className="text-xs">{f}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    <Input
                      type="number"
                      value={textSize}
                      onChange={(e) => setTextSize(parseInt(e.target.value))}
                      placeholder="Size"
                      className="text-xs h-8"
                    />
                  </div>

                  <div className="relative">
                    <Button
                      onClick={() => setShowColorPicker(!showColorPicker)}
                      className="btn-secondary w-full text-xs"
                      size="sm"
                    >
                      <div 
                        className="w-4 h-4 rounded mr-2" 
                        style={{ backgroundColor: textColor }}
                      />
                      Color
                    </Button>
                    {showColorPicker && (
                      <div className="absolute z-50 mt-2">
                        <div 
                          className="fixed inset-0" 
                          onClick={() => setShowColorPicker(false)}
                        />
                        <SketchPicker
                          color={textColor}
                          onChangeComplete={(color) => setTextColor(color.hex)}
                        />
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      onClick={() => setTextStroke(!textStroke)}
                      className={`btn-secondary text-xs ${textStroke ? 'ring-2 ring-primary' : ''}`}
                      size="sm"
                    >
                      Stroke
                    </Button>
                    <Button
                      onClick={() => setTextShadow(!textShadow)}
                      className={`btn-secondary text-xs ${textShadow ? 'ring-2 ring-primary' : ''}`}
                      size="sm"
                    >
                      Shadow
                    </Button>
                  </div>

                  <Button
                    onClick={addTextLayer}
                    className="btn-primary w-full text-xs"
                    size="sm"
                  >
                    <Type size={14} className="mr-1" />
                    Add Text
                  </Button>

                  {/* Text Layer List */}
                  <div className="space-y-1 max-h-40 overflow-y-auto">
                    {textLayers.map((layer) => (
                      <div 
                        key={layer.id}
                        className="flex items-center justify-between p-2 bg-background/50 rounded text-xs"
                      >
                        <span className="truncate flex-1">{layer.text}</span>
                        <Button
                          onClick={() => deleteTextLayer(layer.id)}
                          className="btn-secondary"
                          size="sm"
                        >
                          <Trash2 size={12} />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Export */}
                <div className="space-y-2 pt-2 border-t border-border">
                  <h3 className="text-sm font-semibold">Export</h3>
                  
                  <Select value={exportFormat} onValueChange={setExportFormat}>
                    <SelectTrigger className="text-xs h-8">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="png" className="text-xs">PNG</SelectItem>
                      <SelectItem value="jpg" className="text-xs">JPG</SelectItem>
                      <SelectItem value="webp" className="text-xs">WebP</SelectItem>
                    </SelectContent>
                  </Select>

                  <div>
                    <label className="text-xs mb-1 block">Quality: {exportQuality}%</label>
                    <Slider
                      value={[exportQuality]}
                      onValueChange={(val) => setExportQuality(val[0])}
                      min={1} max={100} step={1}
                    />
                  </div>

                  <Button
                    onClick={handleDownload}
                    className="btn-primary w-full"
                  >
                    <Download size={16} className="mr-2" />
                    Download
                  </Button>

                  <Button
                    onClick={resetAdjustments}
                    className="btn-secondary w-full"
                  >
                    <RotateCw size={16} className="mr-2" />
                    Reset All
                  </Button>
                </div>
              </>
            )}

            {file && mode === 'video' && (
              <>
                {/* Video Controls */}
                <div className="space-y-3 pt-2 border-t border-border">
                  <h3 className="text-sm font-semibold">Playback</h3>
                  
                  <div>
                    <label className="text-xs mb-1 block">Speed: {playbackSpeed}x</label>
                    <Select value={playbackSpeed.toString()} onValueChange={(v) => setPlaybackSpeed(parseFloat(v))}>
                      <SelectTrigger className="text-xs h-8">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="0.5" className="text-xs">0.5x</SelectItem>
                        <SelectItem value="1" className="text-xs">1x</SelectItem>
                        <SelectItem value="1.5" className="text-xs">1.5x</SelectItem>
                        <SelectItem value="2" className="text-xs">2x</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-xs mb-1 block">Volume</label>
                    <Slider
                      value={[volume]}
                      onValueChange={handleVolumeChange}
                      min={0} max={1} step={0.01}
                    />
                    <span className="text-xs text-muted-foreground">{Math.round(volume * 100)}%</span>
                  </div>

                  <Button
                    onClick={toggleMute}
                    className={`btn-secondary w-full text-xs ${isMuted ? 'ring-2 ring-primary' : ''}`}
                    size="sm"
                  >
                    <Volume2 size={14} className="mr-1" />
                    {isMuted ? 'Unmute' : 'Mute'}
                  </Button>
                </div>

                {/* Video PRO Features */}
                <div className="space-y-2 pt-2 border-t border-border">
                  <h3 className="text-sm font-semibold flex items-center gap-2">
                    <Zap size={14} className="text-accent" />
                    PRO Features
                  </h3>

                  <Button
                    onClick={generateCaptions}
                    className="btn-secondary w-full text-xs"
                    size="sm"
                  >
                    <Subtitles size={14} className="mr-1" />
                    Auto-Generate Captions
                  </Button>

                  <Button
                    onClick={detectSilence}
                    className="btn-secondary w-full text-xs"
                    size="sm"
                  >
                    <Gauge size={14} className="mr-1" />
                    Detect Silence
                  </Button>

                  <Button
                    onClick={extractThumbnail}
                    className="btn-secondary w-full text-xs"
                    size="sm"
                  >
                    <Save size={14} className="mr-1" />
                    Extract Thumbnail
                  </Button>

                  <div>
                    <label className="text-xs mb-1 block">Aspect Ratio</label>
                    <Select value={videoAspectRatio} onValueChange={setVideoAspectRatio}>
                      <SelectTrigger className="text-xs h-8">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="9:16" className="text-xs">9:16 (Shorts/Reels)</SelectItem>
                        <SelectItem value="16:9" className="text-xs">16:9 (YouTube)</SelectItem>
                        <SelectItem value="1:1" className="text-xs">1:1 (Instagram Feed)</SelectItem>
                        <SelectItem value="4:5" className="text-xs">4:5 (Instagram Ads)</SelectItem>
                        <SelectItem value="3:4" className="text-xs">3:4 (Mobile-first)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Video Export */}
                <div className="space-y-2 pt-2 border-t border-border">
                  <h3 className="text-sm font-semibold">Export</h3>
                  
                  <Select>
                    <SelectTrigger className="text-xs h-8">
                      <SelectValue placeholder="Resolution" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="720p" className="text-xs">720p</SelectItem>
                      <SelectItem value="1080p" className="text-xs">1080p (HD)</SelectItem>
                      <SelectItem value="4k" className="text-xs">4K (UHD)</SelectItem>
                    </SelectContent>
                  </Select>

                  <Button
                    onClick={handleDownload}
                    className="btn-primary w-full"
                  >
                    <Download size={16} className="mr-2" />
                    Export Video
                  </Button>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Preview Area */}
        <div className="xl:col-span-3">
          <div className="glass-panel p-6">
            <h2 className="text-xl font-semibold mb-4">
              {mode === 'image' && activeTab === 'generate' ? 'AI Generation Preview' : 'Preview'}
            </h2>
            
            {/* AI Generation Preview */}
            {mode === 'image' && activeTab === 'generate' && (
              <div className="space-y-4">
                {!generatedImageBase64 && !isGenerating && (
                  <div className="aspect-video bg-background/50 rounded-lg flex items-center justify-center border-2 border-dashed border-accent/30">
                    <div className="text-center">
                      <Wand2 size={64} className="mx-auto mb-4 text-accent opacity-50" />
                      <p className="text-muted-foreground text-lg">Enter a prompt and generate</p>
                      <p className="text-xs text-muted-foreground mt-2">
                        Your AI-generated image will appear here
                      </p>
                    </div>
                  </div>
                )}

                {isGenerating && (
                  <div className="aspect-video bg-background/50 rounded-lg flex items-center justify-center border-2 border-accent/30">
                    <div className="text-center">
                      <Loader2 size={64} className="mx-auto mb-4 text-accent animate-spin" />
                      <p className="text-accent text-lg font-semibold">Generating your image...</p>
                      <p className="text-xs text-muted-foreground mt-2">
                        This may take 10-30 seconds
                      </p>
                    </div>
                  </div>
                )}

                {generatedImageBase64 && !isGenerating && (
                  <div className="space-y-4">
                    <div className="relative bg-background/50 rounded-lg overflow-hidden flex items-center justify-center p-4">
                      <img
                        src={`data:image/png;base64,${generatedImageBase64}`}
                        alt="AI Generated"
                        className="max-w-full max-h-[700px] object-contain rounded-lg shadow-lg"
                      />
                    </div>
                    <div className="flex gap-3 justify-center">
                      <Button
                        onClick={loadGeneratedImageToEditor}
                        className="btn-primary"
                      >
                        <Palette size={18} className="mr-2" />
                        Edit in Editor
                      </Button>
                      <Button
                        onClick={() => {
                          const link = document.createElement('a');
                          link.download = `ai-generated-${Date.now()}.png`;
                          link.href = `data:image/png;base64,${generatedImageBase64}`;
                          link.click();
                          toast.success('Image downloaded!');
                        }}
                        className="btn-secondary"
                      >
                        <Download size={18} className="mr-2" />
                        Download
                      </Button>
                      <Button
                        onClick={() => {
                          setGeneratedImageBase64(null);
                          setAiPrompt('');
                        }}
                        className="btn-secondary"
                      >
                        <RotateCw size={18} className="mr-2" />
                        New Image
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Image Editor Preview */}
            {mode === 'image' && activeTab === 'edit' && !file && (
              <div className="aspect-video bg-background/50 rounded-lg flex items-center justify-center border-2 border-dashed border-border">
                <div className="text-center">
                  <ImageIcon size={64} className="mx-auto mb-4 text-muted-foreground opacity-50" />
                  <p className="text-muted-foreground">Upload an image or generate one with AI</p>
                  <p className="text-xs text-muted-foreground mt-2">
                    Professional editing with filters, text overlays & more
                  </p>
                </div>
              </div>
            )}

            {mode === 'image' && activeTab === 'edit' && file && (
              <div className="relative bg-background/50 rounded-lg overflow-hidden">
                <canvas
                  ref={canvasRef}
                  className="w-full h-auto max-h-[800px] object-contain mx-auto"
                />
              </div>
            )}

            {/* Video Mode Empty State */}
            {mode === 'video' && !file && (
              <div className="aspect-video bg-background/50 rounded-lg flex items-center justify-center border-2 border-dashed border-border">
                <div className="text-center">
                  <Film size={64} className="mx-auto mb-4 text-muted-foreground opacity-50" />
                  <p className="text-muted-foreground">Upload a video to get started</p>
                  <p className="text-xs text-muted-foreground mt-2">
                    Pro video editing with captions & effects
                  </p>
                </div>
              </div>
            )}

            {mode === 'video' && file && (
              <div className="space-y-4">
                <div className="relative bg-black rounded-lg overflow-hidden">
                  <video
                    ref={videoRef}
                    className="w-full h-auto max-h-[700px]"
                    onTimeUpdate={handleVideoTimeUpdate}
                    onLoadedMetadata={handleVideoLoadedMetadata}
                    onEnded={() => setIsPlaying(false)}
                  />
                  
                  {/* Caption Overlay */}
                  {captions.length > 0 && (
                    <div className="absolute bottom-20 left-0 right-0 text-center px-4">
                      {captions.map((caption, idx) => {
                        if (currentTime >= caption.start && currentTime <= caption.end) {
                          return (
                            <div 
                              key={idx}
                              className={`inline-block px-4 py-2 rounded-lg text-white font-bold text-lg shadow-lg ${
                                captionStyle === 'pop' ? 'bg-black/80 animate-bounce' :
                                captionStyle === 'slide' ? 'bg-gradient-to-r from-purple-600 to-pink-600' :
                                'bg-black/70'
                              }`}
                            >
                              {caption.text}
                            </div>
                          );
                        }
                        return null;
                      })}
                    </div>
                  )}
                </div>

                {/* Captions Info */}
                {captions.length > 0 && (
                  <div className="glass-panel p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-sm font-semibold">
                        <Subtitles size={16} className="inline mr-2" />
                        Captions Loaded ({captions.length} segments)
                      </h3>
                      <Select value={captionStyle} onValueChange={setCaptionStyle}>
                        <SelectTrigger className="w-32 h-8 text-xs">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pop" className="text-xs">Pop</SelectItem>
                          <SelectItem value="slide" className="text-xs">Slide</SelectItem>
                          <SelectItem value="highlight" className="text-xs">Highlight</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="max-h-32 overflow-y-auto space-y-1 text-xs">
                      {captions.slice(0, 5).map((cap, idx) => (
                        <div key={idx} className="text-muted-foreground">
                          [{cap.start.toFixed(1)}s - {cap.end.toFixed(1)}s] {cap.text}
                        </div>
                      ))}
                      {captions.length > 5 && (
                        <div className="text-muted-foreground italic">
                          ...and {captions.length - 5} more segments
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Video Timeline */}
                <div className="glass-panel p-4 space-y-4">
                  <div className="flex items-center gap-4">
                    <Button 
                      onClick={togglePlayPause} 
                      className="btn-primary" 
                      size="sm"
                    >
                      {isPlaying ? <Pause size={18} /> : <Play size={18} />}
                    </Button>
                    
                    <div className="flex-1 flex items-center gap-3">
                      <span className="text-xs text-muted-foreground min-w-[45px]">
                        {formatTime(currentTime)}
                      </span>
                      <Slider
                        value={[currentTime]}
                        onValueChange={handleSeek}
                        min={0}
                        max={duration || 0}
                        step={0.1}
                        className="flex-1"
                      />
                      <span className="text-xs text-muted-foreground min-w-[45px]">
                        {formatTime(duration)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreativeStudioPro;
