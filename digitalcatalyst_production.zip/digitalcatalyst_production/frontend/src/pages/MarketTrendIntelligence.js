import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { TrendingUp, TrendingDown, Zap, Target, Globe, AlertCircle, CheckCircle } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';

const MarketTrendIntelligence = () => {
  const navigate = useNavigate();
  const [timeframe, setTimeframe] = useState('7d');
  const [explorerTopic, setExplorerTopic] = useState('');
  const [explorerResults, setExplorerResults] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);

  // Viral Topic Explorer Analysis (Mock + Heuristic)
  const analyzeTopic = () => {
    if (!explorerTopic.trim()) {
      return;
    }

    setAnalyzing(true);

    // Simulate analysis delay
    setTimeout(() => {
      // Mock heuristic scoring based on keywords
      const topic = explorerTopic.toLowerCase();
      
      let trendStatus = 'Stable';
      let viralityScore = 50;
      let saturationScore = 50;
      let platformSuitability = 'Both';
      let recommendedHooks = [];
      let suggestedFormat = 'Shorts (45s)';
      let verdict = 'Monitor';
      let verdictColor = 'yellow';
      
      // High-virality keywords
      if (topic.includes('ai') || topic.includes('automation') || topic.includes('chatgpt')) {
        trendStatus = 'Rising';
        viralityScore = 92;
        saturationScore = 35;
        verdict = 'Produce NOW';
        verdictColor = 'green';
        recommendedHooks = ['Shocking Statement', 'Problem → Solution', 'Before/After'];
        platformSuitability = 'Shorts';
      } else if (topic.includes('crypto') || topic.includes('bitcoin') || topic.includes('nft')) {
        trendStatus = 'Falling';
        viralityScore = 25;
        saturationScore = 95;
        verdict = 'AVOID';
        verdictColor = 'red';
        recommendedHooks = ['Myth Debunking'];
        platformSuitability = 'Long-form';
      } else if (topic.includes('productivity') || topic.includes('habits') || topic.includes('morning routine')) {
        trendStatus = 'Stable';
        viralityScore = 62;
        saturationScore = 75;
        verdict = 'Monitor';
        verdictColor = 'yellow';
        recommendedHooks = ['Question Hook', 'STOP doing X'];
        platformSuitability = 'Shorts';
        suggestedFormat = 'Shorts (60s)';
      } else if (topic.includes('travel') || topic.includes('budget') || topic.includes('tips')) {
        trendStatus = 'Rising';
        viralityScore = 78;
        saturationScore = 45;
        verdict = 'Produce Soon';
        verdictColor = 'blue';
        recommendedHooks = ['Before/After', 'Number Hook'];
        platformSuitability = 'Both';
      } else if (topic.includes('tech') || topic.includes('iphone') || topic.includes('review')) {
        trendStatus = 'Stable';
        viralityScore = 70;
        saturationScore = 85;
        verdict = 'Monitor';
        verdictColor = 'yellow';
        recommendedHooks = ['Shocking Statement', 'Myth Debunking'];
        platformSuitability = 'Both';
        suggestedFormat = 'Long-form (8m)';
      } else {
        // Default moderate analysis
        viralityScore = Math.floor(Math.random() * 40) + 40; // 40-80
        saturationScore = Math.floor(Math.random() * 50) + 30; // 30-80
        
        if (viralityScore > 70 && saturationScore < 50) {
          verdict = 'Produce Soon';
          verdictColor = 'blue';
          trendStatus = 'Rising';
        }
        
        recommendedHooks = ['Problem → Solution', 'Question Hook'];
      }

      setExplorerResults({
        topic: explorerTopic,
        trendStatus,
        viralityScore,
        saturationScore,
        platformSuitability,
        recommendedHooks,
        suggestedFormat,
        verdict,
        verdictColor,
        velocity: viralityScore > 75 ? 'High' : viralityScore > 50 ? 'Medium' : 'Low',
        competition: saturationScore > 70 ? 'High' : saturationScore > 40 ? 'Medium' : 'Low',
        estimatedViews: viralityScore > 80 ? '1.5M - 3M' : viralityScore > 60 ? '500K - 1.5M' : '100K - 500K'
      });
      
      setAnalyzing(false);
    }, 1500);
  };

  const createFromExplorer = () => {
    if (!explorerResults) return;

    navigate('/creative-studio', {
      state: {
        source: 'Viral Topic Explorer',
        topic: explorerResults.topic,
        format: explorerResults.suggestedFormat,
        aspectRatio: explorerResults.platformSuitability === 'Shorts' ? '9:16' : '16:9',
        hook: explorerResults.recommendedHooks[0] || 'Problem → Solution',
        captionStyle: 'pop',
        viralityScore: explorerResults.viralityScore,
        verdict: explorerResults.verdict,
        expectedViews: explorerResults.estimatedViews
      }
    });
  };

  const createContent = (topic, recommendation) => {
    // Navigate to Creative Studio with context
    navigate('/creative-studio', {
      state: {
        source: 'Market Trends',
        topic: topic.topic,
        format: recommendation === 'Post NOW' ? 'Shorts (45s)' : 'Shorts (60s)',
        aspectRatio: '9:16',
        hook: 'Problem → Solution',
        captionStyle: 'pop',
        trendTag: topic.trend,
        opportunity: topic.opportunity
      }
    });
  };

  const generateScript = async (topic, recommendation) => {
    try {
      const API_URL = process.env.REACT_APP_BACKEND_URL;
      const response = await fetch(`${API_URL}/api/script/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: topic.topic,
          hook_style: 'Problem → Solution',
          format: recommendation === 'Post NOW' ? 'Shorts (45s)' : 'Shorts (60s)',
          platform: 'YouTube Shorts'
        })
      });

      if (!response.ok) throw new Error('Failed');

      const data = await response.json();
      
      if (data.success) {
        navigate('/creative-studio', {
          state: {
            source: 'Market Trends',
            topic: topic.topic,
            format: recommendation === 'Post NOW' ? 'Shorts (45s)' : 'Shorts (60s)',
            aspectRatio: '9:16',
            hook: 'Problem → Solution',
            trendTag: topic.trend,
            opportunity: topic.opportunity,
            generatedScript: data.script,
            generatedHooks: data.hooks,
            generatedCaption: data.caption
          }
        });
      }
    } catch (error) {
      console.error('Script generation failed:', error);
    }
  };

  // Mock trending topics data
  const trendingTopics = [
    { 
      topic: 'AI Image Generation', 
      platform: 'All', 
      trend: 'rising', 
      volume: '2.4M',
      change: '+342%',
      saturation: 'low',
      opportunity: 'high',
      recommendation: 'Post NOW'
    },
    { 
      topic: 'iPhone 15 Pro Max', 
      platform: 'YouTube', 
      trend: 'rising', 
      volume: '8.9M',
      change: '+156%',
      saturation: 'high',
      opportunity: 'medium',
      recommendation: 'Differentiate'
    },
    { 
      topic: 'Productivity Hacks 2025', 
      platform: 'TikTok', 
      trend: 'stable', 
      volume: '1.2M',
      change: '+12%',
      saturation: 'medium',
      opportunity: 'medium',
      recommendation: 'Monitor'
    },
    { 
      topic: 'Crypto Winter Recovery', 
      platform: 'Instagram', 
      trend: 'falling', 
      volume: '890K',
      change: '-45%',
      saturation: 'very high',
      opportunity: 'low',
      recommendation: 'AVOID'
    },
    { 
      topic: 'Remote Work Setup', 
      platform: 'YouTube', 
      trend: 'rising', 
      volume: '3.1M',
      change: '+67%',
      saturation: 'low',
      opportunity: 'very high',
      recommendation: 'Post NOW'
    },
    { 
      topic: 'Budget Travel Tips', 
      platform: 'Instagram', 
      trend: 'rising', 
      volume: '1.8M',
      change: '+89%',
      saturation: 'medium',
      opportunity: 'high',
      recommendation: 'Post Soon'
    }
  ];

  // Emerging niches
  const emergingNiches = [
    { 
      niche: 'AI Automation Tools',
      growth: '+425%',
      competition: 'Low',
      avgViews: '125K',
      signal: 'Strong Buy'
    },
    { 
      niche: 'Sustainable Living',
      growth: '+234%',
      competition: 'Medium',
      avgViews: '89K',
      signal: 'Buy'
    },
    { 
      niche: 'Side Hustles 2025',
      growth: '+312%',
      competition: 'High',
      avgViews: '156K',
      signal: 'Monitor'
    },
    { 
      niche: 'Mental Health Tech',
      growth: '+178%',
      competition: 'Low',
      avgViews: '67K',
      signal: 'Strong Buy'
    }
  ];

  // Platform insights
  const platformInsights = [
    {
      platform: 'YouTube Shorts',
      status: 'Hot',
      bestTime: '6-9 PM',
      topFormats: ['Tutorial', 'Before/After', 'Quick Tips'],
      avgRetention: '68%'
    },
    {
      platform: 'TikTok',
      status: 'Saturated',
      bestTime: '7-10 PM',
      topFormats: ['Trends', 'Dance', 'Comedy'],
      avgRetention: '45%'
    },
    {
      platform: 'Instagram Reels',
      status: 'Growing',
      bestTime: '12-3 PM',
      topFormats: ['Aesthetic', 'Tutorial', 'Lifestyle'],
      avgRetention: '52%'
    }
  ];

  const getTrendIcon = (trend) => {
    if (trend === 'rising') return <TrendingUp className="text-green-400" size={20} />;
    if (trend === 'falling') return <TrendingDown className="text-red-400" size={20} />;
    return <Zap className="text-yellow-400" size={20} />;
  };

  const getOpportunityColor = (opportunity) => {
    if (opportunity === 'very high' || opportunity === 'high') return 'text-green-400';
    if (opportunity === 'medium') return 'text-yellow-400';
    return 'text-red-400';
  };

  const getRecommendationBadge = (recommendation) => {
    if (recommendation === 'Post NOW') {
      return <span className="px-3 py-1 rounded-full text-xs font-bold bg-green-500/20 text-green-400 border border-green-500/50">🚀 {recommendation}</span>;
    }
    if (recommendation === 'Post Soon') {
      return <span className="px-3 py-1 rounded-full text-xs font-bold bg-blue-500/20 text-blue-400 border border-blue-500/50">⭐ {recommendation}</span>;
    }
    if (recommendation === 'AVOID') {
      return <span className="px-3 py-1 rounded-full text-xs font-bold bg-red-500/20 text-red-400 border border-red-500/50">⛔ {recommendation}</span>;
    }
    return <span className="px-3 py-1 rounded-full text-xs font-bold bg-yellow-500/20 text-yellow-400 border border-yellow-500/50">👀 {recommendation}</span>;
  };

  return (
    <div className="p-8 max-w-[1800px] mx-auto fade-in">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
          <TrendingUp className="text-primary" />
          Market Trend Intelligence
        </h1>
        <p className="text-muted-foreground">Real-time insights into trending topics and opportunities</p>
      </div>

      {/* Viral Topic Explorer */}
      <div className="glass-panel p-6 mb-8 border-2 border-accent/30">
        <div className="flex items-center gap-3 mb-4">
          <Zap className="text-accent" size={24} />
          <h2 className="text-2xl font-bold">Viral Topic Explorer</h2>
        </div>
        <p className="text-sm text-muted-foreground mb-4">
          Enter any topic or keyword to evaluate its virality potential
        </p>
        
        <div className="flex gap-3 mb-6">
          <Input
            value={explorerTopic}
            onChange={(e) => setExplorerTopic(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && analyzeTopic()}
            placeholder="e.g., AI automation, crypto trading, productivity hacks..."
            className="flex-1"
          />
          <Button
            onClick={analyzeTopic}
            disabled={analyzing || !explorerTopic.trim()}
            className="btn-primary px-6"
          >
            {analyzing ? 'Analyzing...' : 'Analyze Topic'}
          </Button>
        </div>

        {explorerResults && (
          <div className="space-y-6">
            {/* Verdict Banner */}
            <div className={`p-6 rounded-lg border-2 ${
              explorerResults.verdictColor === 'green' ? 'bg-green-500/10 border-green-500/50' :
              explorerResults.verdictColor === 'blue' ? 'bg-blue-500/10 border-blue-500/50' :
              explorerResults.verdictColor === 'red' ? 'bg-red-500/10 border-red-500/50' :
              'bg-yellow-500/10 border-yellow-500/50'
            }`}>
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-2xl font-bold mb-1">
                    Verdict: {explorerResults.verdict}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Topic: "{explorerResults.topic}"
                  </p>
                </div>
                {(explorerResults.verdict === 'Produce NOW' || explorerResults.verdict === 'Produce Soon') && (
                  <Button
                    onClick={createFromExplorer}
                    className="btn-primary px-6"
                  >
                    Create Content →
                  </Button>
                )}
              </div>
            </div>

            {/* Analysis Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Scores */}
              <div className="glass-panel p-5">
                <h4 className="font-semibold mb-4">Virality Metrics</h4>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-muted-foreground">Virality Score</span>
                      <span className={`font-bold ${
                        explorerResults.viralityScore > 75 ? 'text-green-400' :
                        explorerResults.viralityScore > 50 ? 'text-yellow-400' :
                        'text-red-400'
                      }`}>
                        {explorerResults.viralityScore}/100
                      </span>
                    </div>
                    <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                      <div 
                        className={`h-full ${
                          explorerResults.viralityScore > 75 ? 'bg-green-400' :
                          explorerResults.viralityScore > 50 ? 'bg-yellow-400' :
                          'bg-red-400'
                        }`}
                        style={{ width: `${explorerResults.viralityScore}%` }}
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-muted-foreground">Saturation</span>
                      <span className={`font-bold ${
                        explorerResults.saturationScore > 70 ? 'text-red-400' :
                        explorerResults.saturationScore > 40 ? 'text-yellow-400' :
                        'text-green-400'
                      }`}>
                        {explorerResults.saturationScore}/100
                      </span>
                    </div>
                    <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                      <div 
                        className={`h-full ${
                          explorerResults.saturationScore > 70 ? 'bg-red-400' :
                          explorerResults.saturationScore > 40 ? 'bg-yellow-400' :
                          'bg-green-400'
                        }`}
                        style={{ width: `${explorerResults.saturationScore}%` }}
                      />
                    </div>
                  </div>

                  <div className="pt-2 border-t border-border">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Trend</span>
                      <span className={`font-semibold ${
                        explorerResults.trendStatus === 'Rising' ? 'text-green-400' :
                        explorerResults.trendStatus === 'Falling' ? 'text-red-400' :
                        'text-yellow-400'
                      }`}>
                        {explorerResults.trendStatus}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm mt-2">
                      <span className="text-muted-foreground">Velocity</span>
                      <span className="font-semibold">{explorerResults.velocity}</span>
                    </div>
                    <div className="flex justify-between text-sm mt-2">
                      <span className="text-muted-foreground">Competition</span>
                      <span className="font-semibold">{explorerResults.competition}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Recommendations */}
              <div className="glass-panel p-5">
                <h4 className="font-semibold mb-4">Recommendations</h4>
                <div className="space-y-4">
                  <div>
                    <div className="text-sm text-muted-foreground mb-2">Platform</div>
                    <div className="px-3 py-2 rounded bg-primary/20 text-primary font-semibold text-center">
                      {explorerResults.platformSuitability}
                    </div>
                  </div>

                  <div>
                    <div className="text-sm text-muted-foreground mb-2">Suggested Format</div>
                    <div className="px-3 py-2 rounded bg-accent/20 text-accent font-semibold text-center">
                      {explorerResults.suggestedFormat}
                    </div>
                  </div>

                  <div>
                    <div className="text-sm text-muted-foreground mb-2">Est. Views</div>
                    <div className="px-3 py-2 rounded bg-green-500/20 text-green-400 font-bold text-center">
                      {explorerResults.estimatedViews}
                    </div>
                  </div>
                </div>
              </div>

              {/* Hook Angles */}
              <div className="glass-panel p-5">
                <h4 className="font-semibold mb-4">Recommended Hooks</h4>
                <div className="space-y-2">
                  {explorerResults.recommendedHooks.map((hook, idx) => (
                    <div 
                      key={idx}
                      className="p-3 bg-background/50 rounded border border-border"
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-accent font-bold">#{idx + 1}</span>
                        <span className="font-semibold">{hook}</span>
                      </div>
                    </div>
                  ))}
                </div>

                {explorerResults.recommendedHooks.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No specific hook recommendations
                  </p>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Timeframe Selector */}
      <div className="glass-panel p-4 mb-6">
        <div className="flex items-center gap-4">
          <span className="text-sm font-medium">Timeframe:</span>
          {['24h', '7d', '30d', '90d'].map((tf) => (
            <Button
              key={tf}
              onClick={() => setTimeframe(tf)}
              className={timeframe === tf ? 'btn-primary' : 'btn-secondary'}
              size="sm"
            >
              {tf}
            </Button>
          ))}
          <div className="ml-auto text-xs text-muted-foreground">
            Last updated: Just now
          </div>
        </div>
      </div>

      {/* Quick Signals */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="glass-panel p-6 border-l-4 border-green-500">
          <div className="flex items-center gap-3 mb-2">
            <CheckCircle className="text-green-400" size={24} />
            <h3 className="font-semibold">What to Post NOW</h3>
          </div>
          <div className="space-y-2 mt-4">
            <div className="text-sm">• AI Automation Tools</div>
            <div className="text-sm">• Remote Work Setup</div>
            <div className="text-sm">• Mental Health Tech</div>
          </div>
        </div>

        <div className="glass-panel p-6 border-l-4 border-yellow-500">
          <div className="flex items-center gap-3 mb-2">
            <Target className="text-yellow-400" size={24} />
            <h3 className="font-semibold">Rising Opportunities</h3>
          </div>
          <div className="space-y-2 mt-4">
            <div className="text-sm">• Budget Travel Tips</div>
            <div className="text-sm">• Sustainable Living</div>
            <div className="text-sm">• Side Hustles 2025</div>
          </div>
        </div>

        <div className="glass-panel p-6 border-l-4 border-red-500">
          <div className="flex items-center gap-3 mb-2">
            <AlertCircle className="text-red-400" size={24} />
            <h3 className="font-semibold">What to Avoid</h3>
          </div>
          <div className="space-y-2 mt-4">
            <div className="text-sm">• Crypto Winter Recovery</div>
            <div className="text-sm">• Over-saturated iPhone content</div>
            <div className="text-sm">• Generic productivity hacks</div>
          </div>
        </div>
      </div>

      {/* Trending Topics Table */}
      <div className="glass-panel p-6 mb-8">
        <h2 className="text-2xl font-bold mb-4">Trending Topics Analysis</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4">Topic</th>
                <th className="text-left py-3 px-4">Platform</th>
                <th className="text-left py-3 px-4">Trend</th>
                <th className="text-left py-3 px-4">Volume</th>
                <th className="text-left py-3 px-4">Change</th>
                <th className="text-left py-3 px-4">Saturation</th>
                <th className="text-left py-3 px-4">Opportunity</th>
                <th className="text-left py-3 px-4">Action</th>
              </tr>
            </thead>
            <tbody>
              {trendingTopics.map((item, idx) => (
                <tr key={idx} className="border-b border-border/50 hover:bg-white/5 transition-colors">
                  <td className="py-4 px-4 font-semibold">{item.topic}</td>
                  <td className="py-4 px-4">
                    <span className="px-2 py-1 rounded text-xs bg-primary/20 text-primary">
                      {item.platform}
                    </span>
                  </td>
                  <td className="py-4 px-4">{getTrendIcon(item.trend)}</td>
                  <td className="py-4 px-4 font-mono">{item.volume}</td>
                  <td className="py-4 px-4">
                    <span className={item.change.startsWith('+') ? 'text-green-400' : 'text-red-400'}>
                      {item.change}
                    </span>
                  </td>
                  <td className="py-4 px-4 text-sm capitalize">{item.saturation}</td>
                  <td className="py-4 px-4">
                    <span className={`font-semibold capitalize ${getOpportunityColor(item.opportunity)}`}>
                      {item.opportunity}
                    </span>
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex items-center gap-2">
                      {getRecommendationBadge(item.recommendation)}
                      {(item.recommendation === 'Post NOW' || item.recommendation === 'Post Soon') && (
                        <>
                          <Button
                            onClick={() => generateScript(item, item.recommendation)}
                            className="btn-accent text-xs px-3 py-1 h-auto"
                            size="sm"
                          >
                            Script →
                          </Button>
                          <Button
                            onClick={() => createContent(item, item.recommendation)}
                            className="btn-secondary text-xs px-3 py-1 h-auto"
                            size="sm"
                          >
                            Studio →
                          </Button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Emerging Niches */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="glass-panel p-6">
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
            <Zap className="text-accent" />
            Emerging Niches
          </h2>
          <div className="space-y-4">
            {emergingNiches.map((niche, idx) => (
              <div key={idx} className="p-4 bg-background/50 rounded-lg border border-border">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold">{niche.niche}</h3>
                  <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                    niche.signal === 'Strong Buy' ? 'bg-green-500/20 text-green-400' :
                    niche.signal === 'Buy' ? 'bg-blue-500/20 text-blue-400' :
                    'bg-yellow-500/20 text-yellow-400'
                  }`}>
                    {niche.signal}
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div>
                    <div className="text-muted-foreground text-xs">Growth</div>
                    <div className="font-bold text-green-400">{niche.growth}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground text-xs">Competition</div>
                    <div className="font-bold">{niche.competition}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground text-xs">Avg Views</div>
                    <div className="font-bold">{niche.avgViews}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Platform Insights */}
        <div className="glass-panel p-6">
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
            <Globe className="text-primary" />
            Platform Insights
          </h2>
          <div className="space-y-4">
            {platformInsights.map((platform, idx) => (
              <div key={idx} className="p-4 bg-background/50 rounded-lg border border-border">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold">{platform.platform}</h3>
                  <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                    platform.status === 'Hot' ? 'bg-red-500/20 text-red-400' :
                    platform.status === 'Growing' ? 'bg-green-500/20 text-green-400' :
                    'bg-yellow-500/20 text-yellow-400'
                  }`}>
                    {platform.status}
                  </span>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Best Time:</span>
                    <span className="font-semibold">{platform.bestTime}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Avg Retention:</span>
                    <span className="font-semibold text-green-400">{platform.avgRetention}</span>
                  </div>
                  <div>
                    <div className="text-muted-foreground mb-1">Top Formats:</div>
                    <div className="flex gap-2 flex-wrap">
                      {platform.topFormats.map((format, i) => (
                        <span key={i} className="px-2 py-1 rounded text-xs bg-primary/20 text-primary">
                          {format}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Info Banner */}
      <div className="glass-panel p-6 bg-primary/10 border border-primary/30">
        <div className="flex items-start gap-4">
          <AlertCircle className="text-primary mt-1" size={24} />
          <div>
            <h3 className="font-semibold mb-2">Dashboard Status: Mock Data</h3>
            <p className="text-sm text-muted-foreground">
              Currently displaying simulated trend data. Live API integration (YouTube Data API, Google Trends) will be added in future updates for real-time market intelligence.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MarketTrendIntelligence;
