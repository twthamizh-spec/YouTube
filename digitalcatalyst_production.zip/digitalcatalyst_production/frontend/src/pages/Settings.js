import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Settings as SettingsIcon, User, CreditCard, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Settings = () => {
  const { user, logout } = useAuth();

  const handleLogout = () => {
    logout();
    window.location.href = '/';
  };

  return (
    <div className="p-8 max-w-4xl mx-auto fade-in">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
          <SettingsIcon className="text-primary" />
          Settings
        </h1>
        <p className="text-muted-foreground">Manage your account and preferences</p>
      </div>

      <div className="space-y-6">
        <div className="glass-panel p-6">
          <div className="flex items-center gap-3 mb-4">
            <User className="text-primary" />
            <h2 className="text-xl font-semibold">Account Information</h2>
          </div>
          <div className="space-y-3">
            <div>
              <label className="block text-sm text-muted-foreground mb-1">Email</label>
              <p className="font-medium" data-testid="user-email">{user?.email}</p>
            </div>
            <div>
              <label className="block text-sm text-muted-foreground mb-1">Account ID</label>
              <p className="font-mono text-sm text-muted-foreground" data-testid="user-id">{user?.id}</p>
            </div>
          </div>
        </div>

        <div className="glass-panel p-6">
          <div className="flex items-center gap-3 mb-4">
            <CreditCard className="text-primary" />
            <h2 className="text-xl font-semibold">System Mode</h2>
          </div>
          <div className="space-y-4">
            <div className="p-6 bg-gradient-to-br from-primary/20 to-accent/20 border border-primary/30 rounded-lg text-center">
              <h4 className="text-2xl font-bold mb-2 text-primary">PRIVATE UNLIMITED MODE</h4>
              <p className="text-muted-foreground mb-4">No restrictions. No limits. Full power.</p>
              <ul className="text-sm space-y-2 text-left max-w-xs mx-auto">
                <li className="flex items-center gap-2">
                  <span className="text-green-400">✓</span>
                  <span>Unlimited video generation</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-400">✓</span>
                  <span>Unlimited image creation</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-400">✓</span>
                  <span>Unlimited voiceovers</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-400">✓</span>
                  <span>Private, local-only access</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="glass-panel p-6">
          <h2 className="text-xl font-semibold mb-4">Account Actions</h2>
          <Button
            onClick={handleLogout}
            data-testid="logout-button"
            className="btn-secondary"
          >
            <LogOut size={18} className="mr-2" />
            Sign Out
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Settings;