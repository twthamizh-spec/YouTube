import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { TrendingUp, Video, Image, Mic, BarChart3, Calendar } from 'lucide-react';
import axios from 'axios';

const Analytics = () => {
  const { user } = useAuth();
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);

  const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
  const API = `${BACKEND_URL}/api`;

  useEffect(() => {
    if (user) {
      fetchAnalytics();
    }
  }, [user]);

  const fetchAnalytics = async () => {
    try {
      const response = await axios.get(`${API}/analytics/${user.id}`);
      setAnalytics(response.data);
    } catch (error) {
      console.error('Failed to fetch analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="loading-spinner w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full" />
      </div>
    );
  }

  return (
    <div className="p-8 max-w-7xl mx-auto fade-in">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
          <BarChart3 className="text-primary" />
          Analytics Dashboard
        </h1>
        <p className="text-muted-foreground">Track your content creation performance</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div className="glass-panel p-6" data-testid="analytics-total-projects">
          <div className="flex items-center gap-3 mb-2">
            <TrendingUp className="text-primary" size={24} />
            <h3 className="font-semibold">Total Projects</h3>
          </div>
          <p className="text-4xl font-bold">{analytics?.total_projects || 0}</p>
        </div>

        <div className="glass-panel p-6" data-testid="analytics-completed">
          <div className="flex items-center gap-3 mb-2">
            <Calendar className="text-green-400" size={24} />
            <h3 className="font-semibold">Completed</h3>
          </div>
          <p className="text-4xl font-bold text-green-400">{analytics?.completed || 0}</p>
          <p className="text-xs text-muted-foreground mt-1">
            {analytics?.total_projects > 0
              ? `${Math.round((analytics.completed / analytics.total_projects) * 100)}% success rate`
              : '0% success rate'}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="glass-panel p-6" data-testid="analytics-videos">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">Videos</h3>
            <Video className="text-purple-400" size={24} />
          </div>
          <p className="text-3xl font-bold">{analytics?.by_type?.video || 0}</p>
          <div className="mt-3 h-2 bg-white/10 rounded-full overflow-hidden">
            <div
              className="h-full bg-purple-400"
              style={{ width: `${analytics?.total_projects > 0 ? (analytics?.by_type?.video || 0) / analytics.total_projects * 100 : 0}%` }}
            />
          </div>
        </div>

        <div className="glass-panel p-6" data-testid="analytics-images">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">Images</h3>
            <Image className="text-blue-400" size={24} />
          </div>
          <p className="text-3xl font-bold">{analytics?.by_type?.image || 0}</p>
          <div className="mt-3 h-2 bg-white/10 rounded-full overflow-hidden">
            <div
              className="h-full bg-blue-400"
              style={{ width: `${analytics?.total_projects > 0 ? (analytics?.by_type?.image || 0) / analytics.total_projects * 100 : 0}%` }}
            />
          </div>
        </div>

        <div className="glass-panel p-6" data-testid="analytics-voiceovers">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">Voiceovers</h3>
            <Mic className="text-green-400" size={24} />
          </div>
          <p className="text-3xl font-bold">{analytics?.by_type?.voiceover || 0}</p>
          <div className="mt-3 h-2 bg-white/10 rounded-full overflow-hidden">
            <div
              className="h-full bg-green-400"
              style={{ width: `${analytics?.total_projects > 0 ? (analytics?.by_type?.voiceover || 0) / analytics.total_projects * 100 : 0}%` }}
            />
          </div>
        </div>
      </div>

      <div className="glass-panel p-6">
        <h3 className="text-xl font-semibold mb-4">Usage Insights</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Average cost per project</span>
            <span className="font-semibold">
              {analytics?.total_projects > 0
                ? Math.round(analytics.credits_used / analytics.total_projects)
                : 0} credits
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Projects remaining (with current credits)</span>
            <span className="font-semibold">
              {analytics?.total_projects > 0 && analytics.credits_used > 0
                ? Math.floor(analytics.credits_remaining / (analytics.credits_used / analytics.total_projects))
                : 'Unlimited'}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Most used content type</span>
            <span className="font-semibold capitalize">
              {analytics?.by_type
                ? Object.entries(analytics.by_type).sort((a, b) => b[1] - a[1])[0]?.[0] || 'None'
                : 'None'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;