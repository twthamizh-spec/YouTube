import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { toast } from 'sonner';
import {
  Upload, Image as ImageIcon, Shirt, Package, Monitor, Coffee, ShoppingBag,
  Download, Save, Trash2, RotateCw, ZoomIn, ZoomOut, Move, Smartphone,
  Sun, Moon, Camera, User, Users, Layers, Sparkles, Loader2, RefreshCw,
  FlipHorizontal, FlipVertical, Palette, Sliders, Eye, Check, X, Plus,
  Settings, Target, Crop, Wand2, Eraser, Droplet, Grid, Store,
  Globe, Tag, Box, CircleDot, Maximize2, Minimize2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

// ============================================================
// AI MOCKUP STUDIO (ENTERPRISE)
// Full product mockup engine competing with Placeit/Smartmockups
// ============================================================

const AIMockupStudioEnterprise = () => {
  const { user } = useAuth();
  const canvasRef = useRef(null);
  const productInputRef = useRef(null);
  
  // ===== PRODUCT STATE =====
  const [productImage, setProductImage] = useState(null);
  const [productPreview, setProductPreview] = useState(null);
  const [productTransform, setProductTransform] = useState({
    x: 0, y: 0, scale: 100, rotation: 0, opacity: 100
  });
  
  // ===== PRODUCT METADATA =====
  const [productName, setProductName] = useState('');
  const [productSKU, setProductSKU] = useState('');
  const [targetPlatform, setTargetPlatform] = useState('shopify');
  
  // ===== MOCKUP CONFIGURATION =====
  const [productType, setProductType] = useState('tshirt');
  const [mockupMode, setMockupMode] = useState('model'); // model, scene, flatlay
  
  // ===== MODEL CONFIGURATION =====
  const [modelGender, setModelGender] = useState('female');
  const [modelAge, setModelAge] = useState('young-adult');
  const [modelBodyType, setModelBodyType] = useState('athletic');
  const [modelEthnicity, setModelEthnicity] = useState('diverse');
  const [modelPose, setModelPose] = useState('standing');
  const [modelExpression, setModelExpression] = useState('confident');
  
  // ===== SCENE CONFIGURATION =====
  const [sceneType, setSceneType] = useState('studio');
  const [lightingStyle, setLightingStyle] = useState('soft');
  const [cameraAngle, setCameraAngle] = useState('front');
  const [backgroundTone, setBackgroundTone] = useState('neutral');
  
  // ===== GENERATION STATE =====
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [generatedMockup, setGeneratedMockup] = useState(null);
  const [mockupHistory, setMockupHistory] = useState([]);
  
  // ===== EXPORT SETTINGS =====
  const [exportFormat, setExportFormat] = useState('shopify');
  const [exportResolution, setExportResolution] = useState('1080');
  const [exportAspectRatio, setExportAspectRatio] = useState('1:1');
  const [addWatermark, setAddWatermark] = useState(false);
  
  // ===== ENHANCEMENT FLAGS =====
  const [enableFabricRealism, setEnableFabricRealism] = useState(true);
  const [enableShadowMatch, setEnableShadowMatch] = useState(true);
  const [enableAutoColorway, setEnableAutoColorway] = useState(false);

  // ===== PRODUCT TYPES =====
  const productTypes = [
    { id: 'tshirt', name: 'T-Shirt', icon: '👕' },
    { id: 'hoodie', name: 'Hoodie', icon: '🧥' },
    { id: 'shirt', name: 'Shirt', icon: '👔' },
    { id: 'saree', name: 'Saree', icon: '🥻' },
    { id: 'kurti', name: 'Kurti', icon: '👗' },
    { id: 'dress', name: 'Dress', icon: '👗' },
    { id: 'cap', name: 'Cap/Hat', icon: '🧢' },
    { id: 'shoes', name: 'Shoes', icon: '👟' },
    { id: 'bag', name: 'Bag', icon: '👜' },
    { id: 'bottle', name: 'Bottle', icon: '🍶' },
    { id: 'mug', name: 'Mug', icon: '☕' },
    { id: 'poster', name: 'Poster', icon: '🖼️' },
    { id: 'phonecase', name: 'Phone Case', icon: '📱' },
    { id: 'packaging', name: 'Packaging', icon: '📦' }
  ];

  const modelGenders = [
    { id: 'male', name: 'Male' },
    { id: 'female', name: 'Female' },
    { id: 'non-binary', name: 'Non-Binary' }
  ];

  const modelAges = [
    { id: 'teen', name: 'Teen (16-19)' },
    { id: 'young-adult', name: 'Young Adult (20-30)' },
    { id: 'adult', name: 'Adult (30-45)' },
    { id: 'mature', name: 'Mature (45+)' }
  ];

  const modelBodyTypes = [
    { id: 'slim', name: 'Slim' },
    { id: 'athletic', name: 'Athletic' },
    { id: 'average', name: 'Average' },
    { id: 'curvy', name: 'Curvy' },
    { id: 'plus-size', name: 'Plus Size' }
  ];

  const modelEthnicities = [
    { id: 'diverse', name: 'Diverse/Any' },
    { id: 'caucasian', name: 'Caucasian' },
    { id: 'african', name: 'African' },
    { id: 'asian', name: 'Asian' },
    { id: 'hispanic', name: 'Hispanic' },
    { id: 'middle-eastern', name: 'Middle Eastern' },
    { id: 'south-asian', name: 'South Asian' }
  ];

  const modelPoses = [
    { id: 'standing', name: 'Standing' },
    { id: 'walking', name: 'Walking' },
    { id: 'sitting', name: 'Sitting' },
    { id: 'lifestyle', name: 'Lifestyle Action' },
    { id: 'fashion', name: 'Fashion Pose' },
    { id: 'casual', name: 'Casual Relaxed' }
  ];

  const modelExpressions = [
    { id: 'confident', name: 'Confident' },
    { id: 'smiling', name: 'Smiling' },
    { id: 'serious', name: 'Serious' },
    { id: 'relaxed', name: 'Relaxed' },
    { id: 'energetic', name: 'Energetic' }
  ];

  const sceneTypes = [
    { id: 'studio', name: 'Studio (Clean BG)' },
    { id: 'lifestyle', name: 'Lifestyle Scene' },
    { id: 'outdoor', name: 'Outdoor' },
    { id: 'urban', name: 'Urban Street' },
    { id: 'nature', name: 'Nature' },
    { id: 'office', name: 'Office/Work' },
    { id: 'home', name: 'Home Interior' },
    { id: 'ecommerce', name: 'E-commerce White' }
  ];

  const lightingStyles = [
    { id: 'soft', name: 'Soft Diffused' },
    { id: 'hard', name: 'Hard Dramatic' },
    { id: 'natural', name: 'Natural Daylight' },
    { id: 'golden', name: 'Golden Hour' },
    { id: 'studio', name: 'Studio 3-Point' },
    { id: 'cinematic', name: 'Cinematic' }
  ];

  const cameraAngles = [
    { id: 'front', name: 'Front View' },
    { id: 'side', name: 'Side View' },
    { id: 'three-quarter', name: '3/4 Angle' },
    { id: 'back', name: 'Back View' },
    { id: 'high', name: 'High Angle' },
    { id: 'low', name: 'Low Angle' }
  ];

  const backgroundTones = [
    { id: 'neutral', name: 'Neutral Gray' },
    { id: 'white', name: 'Pure White' },
    { id: 'black', name: 'Dark/Black' },
    { id: 'warm', name: 'Warm Tones' },
    { id: 'cool', name: 'Cool Tones' },
    { id: 'gradient', name: 'Gradient' }
  ];

  const platforms = [
    { id: 'shopify', name: 'Shopify', size: '2048x2048' },
    { id: 'amazon', name: 'Amazon', size: '2000x2000' },
    { id: 'etsy', name: 'Etsy', size: '2000x2000' },
    { id: 'instagram', name: 'Instagram', size: '1080x1080' },
    { id: 'facebook', name: 'Facebook Ads', size: '1200x628' },
    { id: 'website', name: 'Website Hero', size: '1920x1080' }
  ];

  // ===== HANDLE PRODUCT UPLOAD =====
  const handleProductUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    if (!file.type.startsWith('image/')) {
      toast.error('Please upload an image file (PNG, JPG)');
      return;
    }
    
    const reader = new FileReader();
    reader.onload = (event) => {
      setProductImage(file);
      setProductPreview(event.target.result);
      toast.success('✅ Product uploaded! Configure mockup settings and generate.');
    };
    reader.readAsDataURL(file);
  };

  const removeProduct = () => {
    setProductImage(null);
    setProductPreview(null);
    setProductTransform({ x: 0, y: 0, scale: 100, rotation: 0, opacity: 100 });
    if (productInputRef.current) productInputRef.current.value = '';
  };

  // ===== BUILD MOCKUP PROMPT =====
  const buildMockupPrompt = () => {
    const product = productTypes.find(p => p.id === productType)?.name || 'product';
    let prompt = 'Professional commercial product photography. ';
    
    if (mockupMode === 'model') {
      const gender = modelGenders.find(g => g.id === modelGender)?.name || '';
      const age = modelAges.find(a => a.id === modelAge)?.name || '';
      const body = modelBodyTypes.find(b => b.id === modelBodyType)?.name || '';
      const ethnicity = modelEthnicities.find(e => e.id === modelEthnicity)?.name || '';
      const pose = modelPoses.find(p => p.id === modelPose)?.name || '';
      const expression = modelExpressions.find(e => e.id === modelExpression)?.name || '';
      
      prompt += `Photorealistic ${gender} model, ${age}, ${body} body type, ${ethnicity !== 'diverse' ? ethnicity + ' ethnicity, ' : ''}${pose} pose, ${expression} expression. `;
      prompt += `Wearing a stylish ${product} with clear chest/front area for design placement. `;
      prompt += `The ${product} should be plain/solid color with visible fabric texture and natural folds. `;
    } else if (mockupMode === 'scene') {
      const scene = sceneTypes.find(s => s.id === sceneType)?.name || '';
      prompt += `${product} product in ${scene} setting. `;
      prompt += `Product prominently displayed with clear area for design/logo placement. `;
    } else if (mockupMode === 'flatlay') {
      prompt += `${product} flatlay photography, top-down view, laid flat on surface. `;
      prompt += `Clean, styled arrangement with clear product visibility. `;
    }
    
    const lighting = lightingStyles.find(l => l.id === lightingStyle)?.name || '';
    const angle = cameraAngles.find(a => a.id === cameraAngle)?.name || '';
    const bg = backgroundTones.find(b => b.id === backgroundTone)?.name || '';
    
    prompt += `${lighting} lighting, ${angle}, ${bg} background. `;
    prompt += 'High-resolution, commercial quality, sharp focus, professional retouching. ';
    
    if (enableFabricRealism && ['tshirt', 'hoodie', 'shirt', 'dress', 'saree', 'kurti'].includes(productType)) {
      prompt += 'Realistic fabric texture, natural wrinkles and folds. ';
    }
    if (enableShadowMatch) {
      prompt += 'Natural shadows matching lighting direction. ';
    }
    
    return prompt;
  };

  // ===== GENERATE MOCKUP =====
  const generateMockup = async () => {
    setIsGenerating(true);
    setGenerationProgress(10);
    toast.info('🎨 Generating AI mockup... This may take 20-40 seconds.');
    
    try {
      const prompt = buildMockupPrompt();
      console.log('Mockup prompt:', prompt);
      
      setGenerationProgress(30);
      
      const response = await fetch(`${BACKEND_URL}/api/generate/image`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: prompt,
          style: 'product',
          aspect_ratio: exportAspectRatio
        })
      });
      
      setGenerationProgress(70);
      
      if (!response.ok) throw new Error('Mockup generation failed');
      
      const data = await response.json();
      
      if (data.success && data.image_base64) {
        setGenerationProgress(90);
        setGeneratedMockup(data.image_base64);
        setMockupHistory(prev => [...prev, {
          id: Date.now(),
          image: data.image_base64,
          config: { productType, mockupMode, modelGender, sceneType },
          timestamp: new Date().toISOString()
        }]);
        setGenerationProgress(100);
        toast.success('✨ Mockup generated! Add your product design.');
      } else {
        throw new Error('No image data received');
      }
    } catch (error) {
      console.error('Mockup generation error:', error);
      toast.error(`Generation failed: ${error.message}`);
    } finally {
      setIsGenerating(false);
      setGenerationProgress(0);
    }
  };

  // ===== CANVAS RENDERING =====
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !generatedMockup) return;
    
    const ctx = canvas.getContext('2d');
    const mockupImg = new Image();
    
    mockupImg.onload = () => {
      canvas.width = mockupImg.width;
      canvas.height = mockupImg.height;
      
      // Draw mockup base
      ctx.drawImage(mockupImg, 0, 0);
      
      // Composite product if uploaded
      if (productPreview) {
        const productImg = new Image();
        productImg.onload = () => {
          ctx.save();
          
          // Calculate placement (center with offset)
          const centerX = canvas.width / 2 + productTransform.x;
          const centerY = canvas.height * 0.4 + productTransform.y; // Upper chest area
          
          // Scale
          const scaleFactor = productTransform.scale / 100;
          const productWidth = canvas.width * 0.25 * scaleFactor;
          const productHeight = (productImg.height / productImg.width) * productWidth;
          
          // Transform
          ctx.translate(centerX, centerY);
          ctx.rotate((productTransform.rotation * Math.PI) / 180);
          ctx.globalAlpha = productTransform.opacity / 100;
          
          // Blend mode for fabric realism
          if (enableFabricRealism) {
            ctx.globalCompositeOperation = 'multiply';
          }
          
          // Shadow
          if (enableShadowMatch) {
            ctx.shadowColor = 'rgba(0, 0, 0, 0.15)';
            ctx.shadowBlur = 8;
            ctx.shadowOffsetX = 2;
            ctx.shadowOffsetY = 3;
          }
          
          // Draw product
          ctx.drawImage(productImg, -productWidth/2, -productHeight/2, productWidth, productHeight);
          
          ctx.restore();
        };
        productImg.src = productPreview;
      }
    };
    mockupImg.src = `data:image/png;base64,${generatedMockup}`;
  }, [generatedMockup, productPreview, productTransform, enableFabricRealism, enableShadowMatch]);

  // ===== EXPORT =====
  const exportMockup = async (format = 'png') => {
    if (!generatedMockup) {
      toast.error('Generate a mockup first');
      return;
    }
    
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const dataUrl = canvas.toDataURL(`image/${format}`, 0.95);
    const link = document.createElement('a');
    link.download = `mockup-${productType}-${targetPlatform}-${Date.now()}.${format}`;
    link.href = dataUrl;
    link.click();
    toast.success(`✅ Exported for ${platforms.find(p => p.id === targetPlatform)?.name || targetPlatform}!`);
  };

  // ===== SAVE TO PROJECTS =====
  const saveToProjects = async () => {
    if (!generatedMockup) {
      toast.error('Generate a mockup first');
      return;
    }
    
    try {
      await fetch(`${BACKEND_URL}/api/projects`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: user?.id,
          type: 'mockup',
          status: 'completed',
          metadata: {
            productType,
            productName,
            productSKU,
            targetPlatform,
            mockupMode,
            hasProductDesign: !!productPreview
          }
        })
      });
      toast.success('✅ Saved to Projects!');
    } catch (error) {
      toast.error('Failed to save');
    }
  };

  return (
    <div className="h-screen flex flex-col bg-background overflow-hidden">
      {/* ===== HEADER ===== */}
      <div className="h-14 border-b border-border flex items-center justify-between px-6 bg-gradient-to-r from-purple-900/20 to-pink-900/20">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
            <Store className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-lg">AI MOCKUP STUDIO</h1>
            <p className="text-xs text-muted-foreground">Enterprise Product Mockup Engine</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button size="sm" variant="outline" onClick={saveToProjects} disabled={!generatedMockup}>
            <Save className="w-4 h-4 mr-2" /> Save Project
          </Button>
          <Button size="sm" onClick={() => exportMockup('png')} disabled={!generatedMockup} 
            className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700">
            <Download className="w-4 h-4 mr-2" /> Export
          </Button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* ===== LEFT PANEL - CONFIGURATION ===== */}
        <div className="w-80 border-r border-border flex flex-col bg-card/30 overflow-y-auto">
          <Tabs defaultValue="product" className="w-full">
            <TabsList className="w-full rounded-none border-b border-border h-11 bg-transparent grid grid-cols-3">
              <TabsTrigger value="product" className="text-xs data-[state=active]:bg-accent/20">
                <Upload className="w-3 h-3 mr-1" /> Product
              </TabsTrigger>
              <TabsTrigger value="model" className="text-xs data-[state=active]:bg-accent/20">
                <User className="w-3 h-3 mr-1" /> Model
              </TabsTrigger>
              <TabsTrigger value="scene" className="text-xs data-[state=active]:bg-accent/20">
                <Camera className="w-3 h-3 mr-1" /> Scene
              </TabsTrigger>
            </TabsList>

            {/* PRODUCT TAB */}
            <TabsContent value="product" className="p-4 space-y-4 mt-0">
              {/* Product Upload */}
              <div className="space-y-2">
                <label className="text-sm font-semibold flex items-center gap-2">
                  <Upload className="w-4 h-4 text-accent" /> Upload Product Design
                </label>
                <input ref={productInputRef} type="file" accept="image/*" onChange={handleProductUpload} className="hidden" />
                {productPreview ? (
                  <div className="relative bg-[#1a1a2e] rounded-lg p-3">
                    <img src={productPreview} alt="Product" className="w-full h-32 object-contain rounded" />
                    <button onClick={removeProduct} 
                      className="absolute top-1 right-1 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center hover:bg-red-600">
                      <X className="w-4 h-4" />
                    </button>
                    <p className="text-xs text-green-400 mt-2 text-center">✓ Design ready for mockup</p>
                  </div>
                ) : (
                  <button onClick={() => productInputRef.current?.click()}
                    className="w-full h-28 border-2 border-dashed border-accent/50 rounded-lg flex flex-col items-center justify-center hover:border-accent transition-colors bg-accent/5">
                    <Upload className="w-7 h-7 text-accent mb-2" />
                    <span className="text-sm font-medium">Upload PNG/JPG</span>
                    <span className="text-xs text-muted-foreground">Transparent BG recommended</span>
                  </button>
                )}
              </div>

              {/* Product Type */}
              <div className="space-y-2">
                <label className="text-sm font-semibold">Product Type</label>
                <div className="grid grid-cols-4 gap-1.5 max-h-36 overflow-y-auto">
                  {productTypes.map(type => (
                    <button key={type.id} onClick={() => setProductType(type.id)}
                      className={`p-2 rounded-lg border flex flex-col items-center gap-0.5 transition-all text-center ${
                        productType === type.id ? 'border-accent bg-accent/20' : 'border-border hover:border-accent/50'
                      }`}>
                      <span className="text-lg">{type.icon}</span>
                      <span className="text-[10px] leading-tight">{type.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Mockup Mode */}
              <div className="space-y-2">
                <label className="text-sm font-semibold">Mockup Mode</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'model', name: 'AI Model', icon: User },
                    { id: 'scene', name: 'Scene', icon: Camera },
                    { id: 'flatlay', name: 'Flat Lay', icon: Layers }
                  ].map(mode => {
                    const Icon = mode.icon;
                    return (
                      <button key={mode.id} onClick={() => setMockupMode(mode.id)}
                        className={`p-2 rounded-lg border flex flex-col items-center gap-1 ${
                          mockupMode === mode.id ? 'border-accent bg-accent/20' : 'border-border'
                        }`}>
                        <Icon className="w-4 h-4" />
                        <span className="text-xs">{mode.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Product Metadata */}
              <div className="space-y-2 pt-2 border-t border-border">
                <label className="text-sm font-semibold">Product Info (Optional)</label>
                <Input value={productName} onChange={(e) => setProductName(e.target.value)} 
                  placeholder="Product name" className="h-8 text-sm" />
                <Input value={productSKU} onChange={(e) => setProductSKU(e.target.value)} 
                  placeholder="SKU / ID" className="h-8 text-sm" />
                <Select value={targetPlatform} onValueChange={setTargetPlatform}>
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue placeholder="Target platform" />
                  </SelectTrigger>
                  <SelectContent>
                    {platforms.map(p => (
                      <SelectItem key={p.id} value={p.id}>{p.name} ({p.size})</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </TabsContent>

            {/* MODEL TAB */}
            <TabsContent value="model" className="p-4 space-y-3 mt-0">
              <div className="space-y-2">
                <label className="text-xs font-semibold text-muted-foreground">GENDER</label>
                <div className="grid grid-cols-3 gap-2">
                  {modelGenders.map(g => (
                    <button key={g.id} onClick={() => setModelGender(g.id)}
                      className={`p-1.5 rounded border text-xs ${modelGender === g.id ? 'border-accent bg-accent/20' : 'border-border'}`}>
                      {g.name}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-semibold text-muted-foreground">AGE RANGE</label>
                <Select value={modelAge} onValueChange={setModelAge}>
                  <SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {modelAges.map(a => <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-semibold text-muted-foreground">BODY TYPE</label>
                <div className="grid grid-cols-3 gap-1.5">
                  {modelBodyTypes.map(b => (
                    <button key={b.id} onClick={() => setModelBodyType(b.id)}
                      className={`p-1.5 rounded border text-xs ${modelBodyType === b.id ? 'border-accent bg-accent/20' : 'border-border'}`}>
                      {b.name}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-semibold text-muted-foreground">ETHNICITY</label>
                <Select value={modelEthnicity} onValueChange={setModelEthnicity}>
                  <SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {modelEthnicities.map(e => <SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-semibold text-muted-foreground">POSE</label>
                <div className="grid grid-cols-3 gap-1.5">
                  {modelPoses.map(p => (
                    <button key={p.id} onClick={() => setModelPose(p.id)}
                      className={`p-1.5 rounded border text-xs ${modelPose === p.id ? 'border-accent bg-accent/20' : 'border-border'}`}>
                      {p.name}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-semibold text-muted-foreground">EXPRESSION</label>
                <div className="grid grid-cols-3 gap-1.5">
                  {modelExpressions.map(e => (
                    <button key={e.id} onClick={() => setModelExpression(e.id)}
                      className={`p-1.5 rounded border text-xs ${modelExpression === e.id ? 'border-accent bg-accent/20' : 'border-border'}`}>
                      {e.name}
                    </button>
                  ))}
                </div>
              </div>
            </TabsContent>

            {/* SCENE TAB */}
            <TabsContent value="scene" className="p-4 space-y-3 mt-0">
              <div className="space-y-2">
                <label className="text-xs font-semibold text-muted-foreground">ENVIRONMENT</label>
                <div className="grid grid-cols-2 gap-1.5">
                  {sceneTypes.map(s => (
                    <button key={s.id} onClick={() => setSceneType(s.id)}
                      className={`p-1.5 rounded border text-xs text-left ${sceneType === s.id ? 'border-accent bg-accent/20' : 'border-border'}`}>
                      {s.name}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-semibold text-muted-foreground">LIGHTING</label>
                <div className="grid grid-cols-2 gap-1.5">
                  {lightingStyles.map(l => (
                    <button key={l.id} onClick={() => setLightingStyle(l.id)}
                      className={`p-1.5 rounded border text-xs ${lightingStyle === l.id ? 'border-accent bg-accent/20' : 'border-border'}`}>
                      {l.name}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-semibold text-muted-foreground">CAMERA ANGLE</label>
                <div className="grid grid-cols-3 gap-1.5">
                  {cameraAngles.map(a => (
                    <button key={a.id} onClick={() => setCameraAngle(a.id)}
                      className={`p-1.5 rounded border text-xs ${cameraAngle === a.id ? 'border-accent bg-accent/20' : 'border-border'}`}>
                      {a.name}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-semibold text-muted-foreground">BACKGROUND</label>
                <div className="grid grid-cols-3 gap-1.5">
                  {backgroundTones.map(b => (
                    <button key={b.id} onClick={() => setBackgroundTone(b.id)}
                      className={`p-1.5 rounded border text-xs ${backgroundTone === b.id ? 'border-accent bg-accent/20' : 'border-border'}`}>
                      {b.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* AI Enhancements */}
              <div className="space-y-2 pt-2 border-t border-border">
                <label className="text-xs font-semibold text-muted-foreground">AI ENHANCEMENTS</label>
                <div className="space-y-1.5">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={enableFabricRealism} 
                      onChange={(e) => setEnableFabricRealism(e.target.checked)} 
                      className="w-4 h-4 rounded" />
                    <span className="text-xs">Fabric texture realism</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={enableShadowMatch} 
                      onChange={(e) => setEnableShadowMatch(e.target.checked)} 
                      className="w-4 h-4 rounded" />
                    <span className="text-xs">Shadow & light matching</span>
                  </label>
                </div>
              </div>
            </TabsContent>
          </Tabs>

          {/* Generate Button */}
          <div className="p-4 border-t border-border mt-auto space-y-2">
            <Button onClick={generateMockup} disabled={isGenerating}
              className="w-full h-11 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-sm">
              {isGenerating ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Generating ({generationProgress}%)</>
              ) : (
                <><Sparkles className="w-4 h-4 mr-2" />Generate AI Mockup</>
              )}
            </Button>
            {isGenerating && (
              <div className="w-full bg-background/50 rounded-full h-1.5">
                <div className="bg-accent h-1.5 rounded-full transition-all" style={{ width: `${generationProgress}%` }} />
              </div>
            )}
          </div>
        </div>

        {/* ===== CENTER - PREVIEW CANVAS ===== */}
        <div className="flex-1 flex items-center justify-center bg-[#0a0a0f] p-6 overflow-auto">
          {generatedMockup ? (
            <div className="relative">
              <canvas ref={canvasRef} className="max-w-full max-h-[calc(100vh-200px)] rounded-lg shadow-2xl" />
              <div className="absolute bottom-3 left-3 right-3 flex justify-between">
                <Button size="sm" variant="secondary" onClick={generateMockup} disabled={isGenerating}>
                  <RefreshCw className="w-3 h-3 mr-1" /> Regenerate
                </Button>
                <div className="flex gap-2">
                  <Button size="sm" variant="secondary" onClick={() => setMockupHistory(prev => prev.slice(0, -1))}>
                    <RotateCw className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center max-w-md">
              <div className="w-24 h-24 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-purple-500/20 to-pink-500/20 flex items-center justify-center">
                <Store className="w-12 h-12 text-purple-400" />
              </div>
              <h3 className="text-xl font-semibold mb-3">AI Mockup Studio</h3>
              <p className="text-muted-foreground mb-6">
                Generate professional product mockups with AI-powered models, scenes, and compositions.
              </p>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="flex items-center gap-2 text-left p-2 rounded-lg bg-card/50">
                  <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                  <span>14 product types</span>
                </div>
                <div className="flex items-center gap-2 text-left p-2 rounded-lg bg-card/50">
                  <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                  <span>AI model generation</span>
                </div>
                <div className="flex items-center gap-2 text-left p-2 rounded-lg bg-card/50">
                  <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                  <span>8 scene environments</span>
                </div>
                <div className="flex items-center gap-2 text-left p-2 rounded-lg bg-card/50">
                  <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                  <span>Platform-ready export</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* ===== RIGHT PANEL - ADJUSTMENTS ===== */}
        <div className="w-64 border-l border-border flex flex-col bg-card/30 overflow-y-auto">
          <div className="p-4 border-b border-border">
            <h3 className="text-sm font-semibold flex items-center gap-2">
              <Sliders className="w-4 h-4" /> Adjustments
            </h3>
          </div>

          {productPreview && generatedMockup && (
            <div className="p-4 space-y-4">
              <div className="space-y-2">
                <label className="text-xs font-semibold text-muted-foreground">POSITION X</label>
                <Slider value={[productTransform.x]} onValueChange={([v]) => setProductTransform(p => ({...p, x: v}))} 
                  min={-300} max={300} />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-semibold text-muted-foreground">POSITION Y</label>
                <Slider value={[productTransform.y]} onValueChange={([v]) => setProductTransform(p => ({...p, y: v}))} 
                  min={-300} max={300} />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-semibold text-muted-foreground">SCALE ({productTransform.scale}%)</label>
                <Slider value={[productTransform.scale]} onValueChange={([v]) => setProductTransform(p => ({...p, scale: v}))} 
                  min={20} max={200} />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-semibold text-muted-foreground">ROTATION ({productTransform.rotation}°)</label>
                <Slider value={[productTransform.rotation]} onValueChange={([v]) => setProductTransform(p => ({...p, rotation: v}))} 
                  min={-180} max={180} />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-semibold text-muted-foreground">OPACITY ({productTransform.opacity}%)</label>
                <Slider value={[productTransform.opacity]} onValueChange={([v]) => setProductTransform(p => ({...p, opacity: v}))} 
                  min={0} max={100} />
              </div>
            </div>
          )}

          {/* Export Settings */}
          <div className="p-4 border-t border-border space-y-3">
            <h4 className="text-xs font-semibold text-muted-foreground">EXPORT SETTINGS</h4>
            <Select value={exportAspectRatio} onValueChange={setExportAspectRatio}>
              <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Aspect Ratio" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="1:1">1:1 Square</SelectItem>
                <SelectItem value="4:5">4:5 Instagram</SelectItem>
                <SelectItem value="16:9">16:9 Wide</SelectItem>
                <SelectItem value="9:16">9:16 Portrait</SelectItem>
              </SelectContent>
            </Select>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={addWatermark} onChange={(e) => setAddWatermark(e.target.checked)} className="w-4 h-4 rounded" />
              <span className="text-xs">Add watermark</span>
            </label>
          </div>

          {/* History */}
          {mockupHistory.length > 0 && (
            <div className="p-4 border-t border-border">
              <h4 className="text-xs font-semibold text-muted-foreground mb-2">HISTORY ({mockupHistory.length})</h4>
              <div className="grid grid-cols-3 gap-1.5">
                {mockupHistory.slice(-6).map((item) => (
                  <button key={item.id} onClick={() => setGeneratedMockup(item.image)}
                    className="aspect-square rounded overflow-hidden border border-border hover:border-accent">
                    <img src={`data:image/png;base64,${item.image}`} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AIMockupStudioEnterprise;
