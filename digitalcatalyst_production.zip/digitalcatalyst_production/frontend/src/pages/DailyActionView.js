import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Zap, TrendingUp, Clock, Target, ArrowRight } from 'lucide-react';
import { Button } from '../components/ui/button';
import { toast } from 'sonner';

const DailyActionView = () => {
  const navigate = useNavigate();
  const [generating, setGenerating] = useState({});

  // Top 3 "Post Now" recommendations (from Market Trends logic)
  const topActions = [
    {
      id: 1,
      topic: 'AI Automation Tools',
      reason: 'Trending +425%, Low competition',
      hook: 'Shocking Statement',
      format: 'Shorts (45s)',
      aspectRatio: '9:16',
      expectedViews: '2.4M',
      priority: 'URGENT'
    },
    {
      id: 2,
      topic: 'Remote Work Setup 2025',
      reason: 'High demand, Strong signals',
      hook: 'Problem → Solution',
      format: 'Shorts (60s)',
      aspectRatio: '9:16',
      expectedViews: '1.8M',
      priority: 'HIGH'
    },
    {
      id: 3,
      topic: 'Budget Travel Hacks',
      reason: 'Rising +89%, Medium competition',
      hook: 'Before/After',
      format: 'Shorts (45s)',
      aspectRatio: '9:16',
      expectedViews: '1.2M',
      priority: 'MEDIUM'
    }
  ];

  const generateAndNavigate = async (action) => {
    setGenerating({ [action.id]: true });

    try {
      const API_URL = process.env.REACT_APP_BACKEND_URL;
      const response = await fetch(`${API_URL}/api/script/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: action.topic,
          hook_style: action.hook,
          format: action.format,
          platform: 'YouTube Shorts'
        })
      });

      if (!response.ok) {
        throw new Error('Script generation failed');
      }

      const data = await response.json();
      
      if (data.success) {
        toast.success('Script generated! Opening Creative Studio...');
        
        // Navigate to Creative Studio with script
        navigate('/creative-studio', {
          state: {
            source: 'Daily Action View',
            topic: action.topic,
            format: action.format,
            aspectRatio: action.aspectRatio,
            hook: action.hook,
            expectedViews: action.expectedViews,
            generatedScript: data.script,
            generatedHooks: data.hooks,
            generatedCaption: data.caption,
            scriptMetadata: data.metadata
          }
        });
      }
    } catch (error) {
      console.error('Generation error:', error);
      toast.error('Failed to generate script. Please try again.');
    } finally {
      setGenerating({ [action.id]: false });
    }
  };

  return (
    <div className="p-8 max-w-[1400px] mx-auto fade-in">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
          <Zap className="text-accent" />
          Daily Action View
        </h1>
        <p className="text-muted-foreground">Your top 3 opportunities today - Click to produce</p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="glass-panel p-6">
          <div className="flex items-center gap-3 mb-2">
            <TrendingUp className="text-green-400" size={24} />
            <h3 className="text-sm font-semibold text-muted-foreground">Hot Opportunities</h3>
          </div>
          <div className="text-4xl font-bold">3</div>
          <div className="text-xs text-muted-foreground mt-1">Ready to produce</div>
        </div>

        <div className="glass-panel p-6">
          <div className="flex items-center gap-3 mb-2">
            <Clock className="text-accent" size={24} />
            <h3 className="text-sm font-semibold text-muted-foreground">Estimated Time</h3>
          </div>
          <div className="text-4xl font-bold">15-20</div>
          <div className="text-xs text-muted-foreground mt-1">Minutes per video</div>
        </div>

        <div className="glass-panel p-6">
          <div className="flex items-center gap-3 mb-2">
            <Target className="text-primary" size={24} />
            <h3 className="text-sm font-semibold text-muted-foreground">Combined Potential</h3>
          </div>
          <div className="text-4xl font-bold">5.4M</div>
          <div className="text-xs text-muted-foreground mt-1">Expected views</div>
        </div>
      </div>

      {/* Action Cards */}
      <div className="space-y-6">
        {topActions.map((action) => (
          <div 
            key={action.id}
            className={`glass-panel p-6 border-l-4 ${
              action.priority === 'URGENT' ? 'border-red-500 bg-red-500/5' :
              action.priority === 'HIGH' ? 'border-orange-500 bg-orange-500/5' :
              'border-blue-500 bg-blue-500/5'
            }`}
          >
            <div className="flex items-start justify-between gap-6">
              {/* Content */}
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-3">
                  <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                    action.priority === 'URGENT' ? 'bg-red-500/20 text-red-400' :
                    action.priority === 'HIGH' ? 'bg-orange-500/20 text-orange-400' :
                    'bg-blue-500/20 text-blue-400'
                  }`}>
                    {action.priority}
                  </span>
                  <h2 className="text-2xl font-bold">{action.topic}</h2>
                </div>

                <p className="text-muted-foreground mb-4">{action.reason}</p>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <div className="text-muted-foreground text-xs mb-1">Hook Style</div>
                    <div className="font-semibold">{action.hook}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground text-xs mb-1">Format</div>
                    <div className="font-semibold">{action.format}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground text-xs mb-1">Aspect Ratio</div>
                    <div className="font-semibold text-accent">{action.aspectRatio}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground text-xs mb-1">Expected Views</div>
                    <div className="font-semibold text-green-400">{action.expectedViews}</div>
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div className="flex flex-col gap-3">
                <Button
                  onClick={() => generateAndNavigate(action)}
                  disabled={generating[action.id]}
                  className="btn-primary px-8 py-6 text-lg"
                >
                  {generating[action.id] ? (
                    <>Generating...</>
                  ) : (
                    <>
                      Generate Script
                      <ArrowRight className="ml-2" size={20} />
                    </>
                  )}
                </Button>
                <div className="text-xs text-center text-muted-foreground">
                  ~2 min to script
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Workflow Guide */}
      <div className="glass-panel p-6 mt-8 bg-primary/10 border border-primary/30">
        <h3 className="font-semibold mb-4">Today's Workflow</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center font-bold">1</div>
            <div>
              <div className="font-semibold">Click Action</div>
              <div className="text-xs text-muted-foreground">Choose topic</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center font-bold">2</div>
            <div>
              <div className="font-semibold">Script Generated</div>
              <div className="text-xs text-muted-foreground">AI writes for you</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center font-bold">3</div>
            <div>
              <div className="font-semibold">Edit & Produce</div>
              <div className="text-xs text-muted-foreground">Creative Studio</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center font-bold">4</div>
            <div>
              <div className="font-semibold">Export & Publish</div>
              <div className="text-xs text-muted-foreground">15-20 min total</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DailyActionView;
