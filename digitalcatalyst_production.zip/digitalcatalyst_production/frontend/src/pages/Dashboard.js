import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Video, Image, Mic, TrendingUp, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';
import axios from 'axios';

const Dashboard = () => {
  const { user } = useAuth();
  const [recentProjects, setRecentProjects] = useState([]);
  const [loading, setLoading] = useState(true);

  const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
  const API = `${BACKEND_URL}/api`;

  useEffect(() => {
    if (user) {
      fetchRecentProjects();
    }
  }, [user]);

  const fetchRecentProjects = async () => {
    try {
      const response = await axios.get(`${API}/projects?user_id=${user.id}`);
      setRecentProjects(response.data.slice(0, 6));
    } catch (error) {
      console.error('Failed to fetch projects:', error);
    } finally {
      setLoading(false);
    }
  };

  const quickActions = [
    {
      title: 'Create Video',
      description: 'YouTube Shorts & Long Videos',
      icon: Video,
      path: '/video-creator',
      gradient: 'from-purple-500 to-pink-500',
      testId: 'quick-action-video'
    },
    {
      title: 'Product Mockup',
      description: 'AI-Powered Apparel Images',
      icon: Image,
      path: '/mockup-studio',
      gradient: 'from-blue-500 to-cyan-500',
      testId: 'quick-action-mockup'
    },
    {
      title: 'AI Voiceover',
      description: 'Natural Text-to-Speech',
      icon: Mic,
      path: '/voiceover',
      gradient: 'from-green-500 to-emerald-500',
      testId: 'quick-action-voiceover'
    },
  ];

  return (
    <div className="p-8 fade-in">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Welcome back, {user?.email?.split('@')[0]}</h1>
        <p className="text-muted-foreground">Ready to create something amazing?</p>
      </div>

      <div className="bento-grid mb-12">
        {quickActions.map((action) => {
          const Icon = action.icon;
          return (
            <Link
              key={action.path}
              to={action.path}
              data-testid={action.testId}
              className="card-interactive p-6 group"
            >
              <div className={`inline-flex items-center justify-center w-12 h-12 rounded-lg bg-gradient-to-br ${action.gradient} mb-4 group-hover:scale-110 transition-transform duration-300`}>
                <Icon size={24} className="text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-1">{action.title}</h3>
              <p className="text-sm text-muted-foreground">{action.description}</p>
            </Link>
          );
        })}
      </div>

      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold">Recent Projects</h2>
          <Link to="/projects" className="text-sm text-primary hover:underline" data-testid="view-all-projects">
            View All
          </Link>
        </div>

        {loading ? (
          <div className="glass-panel p-12 text-center">
            <div className="loading-spinner w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full mx-auto" />
          </div>
        ) : recentProjects.length === 0 ? (
          <div className="glass-panel p-12 text-center" data-testid="no-projects-message">
            <Zap size={48} className="mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-xl font-semibold mb-2">No projects yet</h3>
            <p className="text-muted-foreground">Create your first AI-powered content above</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {recentProjects.map((project) => (
              <div key={project.id} className="glass-panel p-4" data-testid={`project-card-${project.id}`}>
                <div className="flex items-center gap-3 mb-2">
                  {project.type === 'video' && <Video size={20} className="text-purple-400" />}
                  {project.type === 'image' && <Image size={20} className="text-blue-400" />}
                  {project.type === 'voiceover' && <Mic size={20} className="text-green-400" />}
                  <span className="text-xs px-2 py-1 rounded bg-primary/20 text-primary">
                    {project.status}
                  </span>
                </div>
                <h4 className="font-semibold mb-1 truncate">{project.title}</h4>
                <p className="text-xs text-muted-foreground">
                  {new Date(project.created_at).toLocaleDateString()}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="glass-panel p-6">
          <div className="flex items-center gap-3 mb-2">
            <TrendingUp className="text-primary" size={24} />
            <h3 className="font-semibold">Total Generations</h3>
          </div>
          <p className="text-3xl font-bold">Unlimited</p>
          <p className="text-xs text-muted-foreground mt-1">Private power mode active</p>
        </div>
        <div className="glass-panel p-6">
          <div className="flex items-center gap-3 mb-2">
            <Video className="text-green-400" size={24} />
            <h3 className="font-semibold">Projects</h3>
          </div>
          <p className="text-3xl font-bold">{recentProjects.length}</p>
          <p className="text-xs text-muted-foreground mt-1">Total created</p>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;