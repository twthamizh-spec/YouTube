import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { toast } from 'sonner';
import { 
  Rocket, TrendingUp, FileText, Image, Film, Mic, 
  Tags, Download, Loader2, CheckCircle, AlertCircle,
  Play, RefreshCw, Sparkles, Youtube, Clock, Target
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const YouTubeAutomationPipeline = () => {
  const { user } = useAuth();
  
  // Pipeline State
  const [topic, setTopic] = useState('');
  const [niche, setNiche] = useState('finance');
  const [videoFormat, setVideoFormat] = useState('shorts');
  const [voiceStyle, setVoiceStyle] = useState('nova');
  
  // Pipeline Progress
  const [currentStep, setCurrentStep] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  
  // Generated Content
  const [generatedContent, setGeneratedContent] = useState({
    script: null,
    hooks: null,
    scenes: [],
    voiceover: null,
    video: null,
    meta: null
  });

  // Trending Topics (for quick selection)
  const trendingTopics = {
    finance: [
      "5 passive income ideas that actually work in 2025",
      "How to save your first 1 lakh rupees",
      "Stock market mistakes beginners make",
      "Side hustles that pay 50k per month",
      "Crypto vs Gold - where to invest"
    ],
    tech: [
      "AI tools that will replace your job",
      "Free apps that feel illegal to know",
      "ChatGPT tricks nobody talks about",
      "How to learn coding in 30 days",
      "Tech skills that will make you rich"
    ],
    productivity: [
      "Morning routine of successful people",
      "How to stop procrastinating forever",
      "5 habits that changed my life",
      "Time management secrets of CEOs",
      "How to wake up at 5 AM"
    ]
  };

  const voiceOptions = [
    { id: 'nova', name: 'Nova', desc: 'Friendly & energetic - great for Shorts' },
    { id: 'onyx', name: 'Onyx', desc: 'Deep & authoritative - great for finance' },
    { id: 'alloy', name: 'Alloy', desc: 'Neutral & balanced' },
    { id: 'echo', name: 'Echo', desc: 'Warm & engaging' },
    { id: 'shimmer', name: 'Shimmer', desc: 'Soft & expressive' }
  ];

  const pipelineSteps = [
    { id: 1, name: 'Generate Script', icon: FileText, status: 'pending' },
    { id: 2, name: 'Create Visuals', icon: Image, status: 'pending' },
    { id: 3, name: 'Generate Voice', icon: Mic, status: 'pending' },
    { id: 4, name: 'Assemble Video', icon: Film, status: 'pending' },
    { id: 5, name: 'Generate Meta', icon: Tags, status: 'pending' }
  ];

  // STEP 1: Generate Script
  const generateScript = async () => {
    try {
      const response = await fetch(`${BACKEND_URL}/api/script/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: topic,
          hook_style: 'Problem → Solution',
          format: videoFormat === 'shorts' ? 'Shorts (45s)' : 'Long-form (5m)',
          platform: 'YouTube Shorts',
          language: 'English'
        })
      });
      
      if (!response.ok) throw new Error('Script generation failed');
      const data = await response.json();
      
      if (data.success) {
        // Parse scenes from script
        const sceneMatches = data.script.match(/SCENE \d+:.*?(?=SCENE \d+:|$)/gs) || [data.script];
        const scenes = sceneMatches.map((scene, index) => ({
          id: index,
          content: scene.trim(),
          visualPrompt: scene.match(/Visual: (.+)/)?.[1] || `Professional visual for: ${topic}`,
          duration: videoFormat === 'shorts' ? 5 : 10,
          imageBase64: null,
          status: 'pending'
        }));

        setGeneratedContent(prev => ({
          ...prev,
          script: data.script,
          hooks: data.hooks,
          scenes: scenes
        }));
        return true;
      }
      return false;
    } catch (error) {
      console.error('Script error:', error);
      toast.error(`Script failed: ${error.message}`);
      return false;
    }
  };

  // STEP 2: Generate Scene Images
  const generateSceneImages = async () => {
    const scenes = [...generatedContent.scenes];
    
    for (let i = 0; i < Math.min(scenes.length, 4); i++) {
      try {
        const response = await fetch(`${BACKEND_URL}/api/generate/image`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            prompt: `${scenes[i].visualPrompt}. Professional YouTube thumbnail style, high quality, engaging, ${niche} niche aesthetic`,
            style: 'cinematic',
            aspect_ratio: videoFormat === 'shorts' ? '9:16' : '16:9'
          })
        });
        
        if (response.ok) {
          const data = await response.json();
          if (data.success && data.image_base64) {
            scenes[i].imageBase64 = data.image_base64;
            scenes[i].status = 'ready';
            setGeneratedContent(prev => ({ ...prev, scenes: [...scenes] }));
          }
        }
        
        // Small delay between requests
        await new Promise(r => setTimeout(r, 1000));
      } catch (error) {
        console.error(`Scene ${i} error:`, error);
        scenes[i].status = 'failed';
      }
    }
    
    return scenes.some(s => s.status === 'ready');
  };

  // STEP 3: Generate Voiceover
  const generateVoiceover = async () => {
    try {
      // Extract spoken text from script (remove visual descriptions)
      const spokenText = generatedContent.script
        .replace(/Visual:.*$/gm, '')
        .replace(/SCENE \d+:.*$/gm, '')
        .replace(/\[.*?\]/g, '')
        .trim();
      
      const response = await fetch(`${BACKEND_URL}/api/generate/voice`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: spokenText.substring(0, 1000), // Limit text length
          voice: voiceStyle,
          speed: videoFormat === 'shorts' ? 1.1 : 1.0
        })
      });
      
      if (response.ok) {
        const data = await response.json();
        if (data.success && data.audio_base64) {
          setGeneratedContent(prev => ({ ...prev, voiceover: data.audio_base64 }));
          return true;
        }
      }
      return false;
    } catch (error) {
      console.error('Voice error:', error);
      toast.error(`Voice failed: ${error.message}`);
      return false;
    }
  };

  // STEP 4: Assemble Video
  const assembleVideo = async () => {
    try {
      const readyScenes = generatedContent.scenes.filter(s => s.status === 'ready');
      if (readyScenes.length === 0) {
        toast.error('No scenes ready for video');
        return false;
      }
      
      const response = await fetch(`${BACKEND_URL}/api/video/assemble`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          scenes: readyScenes.map(s => ({
            image_base64: s.imageBase64,
            duration: s.duration
          })),
          audio_base64: generatedContent.voiceover,
          fps: 30
        })
      });
      
      if (response.ok) {
        const data = await response.json();
        if (data.success && data.video_base64) {
          setGeneratedContent(prev => ({ ...prev, video: data.video_base64 }));
          return true;
        }
      }
      return false;
    } catch (error) {
      console.error('Video error:', error);
      toast.error(`Video assembly failed: ${error.message}`);
      return false;
    }
  };

  // STEP 5: Generate YouTube Meta
  const generateMeta = async () => {
    try {
      // Generate title, description, tags based on the content
      const hookText = generatedContent.hooks || '';
      let parsedHooks = [];
      try {
        parsedHooks = JSON.parse(hookText);
      } catch {
        parsedHooks = [{ hook: topic }];
      }
      
      const title = parsedHooks[0]?.hook || `${topic} | Must Watch!`;
      
      const description = `${title}

${generatedContent.script?.substring(0, 200)}...

🔔 Subscribe for more ${niche} content!
👍 Like & Share if this helped you!

#${niche} #youtube #viral #trending #2025`;

      const tags = [
        niche,
        'youtube shorts',
        'viral',
        'trending',
        '2025',
        topic.split(' ').slice(0, 3).join(' '),
        'money',
        'success',
        'motivation'
      ];

      setGeneratedContent(prev => ({
        ...prev,
        meta: {
          title: title.substring(0, 100),
          description: description,
          tags: tags
        }
      }));
      
      return true;
    } catch (error) {
      console.error('Meta error:', error);
      return false;
    }
  };

  // Run Full Pipeline
  const runPipeline = async () => {
    if (!topic.trim()) {
      toast.error('Please enter a topic first!');
      return;
    }

    setIsRunning(true);
    setCurrentStep(1);

    try {
      // Step 1: Script
      toast.info('📝 Step 1/5: Generating script...');
      const scriptOk = await generateScript();
      if (!scriptOk) throw new Error('Script generation failed');
      setCurrentStep(2);

      // Step 2: Images
      toast.info('🎨 Step 2/5: Creating visuals...');
      const imagesOk = await generateSceneImages();
      if (!imagesOk) throw new Error('Image generation failed');
      setCurrentStep(3);

      // Step 3: Voice
      toast.info('🎤 Step 3/5: Generating voiceover...');
      const voiceOk = await generateVoiceover();
      if (!voiceOk) throw new Error('Voice generation failed');
      setCurrentStep(4);

      // Step 4: Video
      toast.info('🎬 Step 4/5: Assembling video...');
      const videoOk = await assembleVideo();
      if (!videoOk) throw new Error('Video assembly failed');
      setCurrentStep(5);

      // Step 5: Meta
      toast.info('🏷️ Step 5/5: Generating metadata...');
      await generateMeta();
      
      setCurrentStep(6);
      toast.success('🎉 Pipeline complete! Your video is ready!');
      
    } catch (error) {
      toast.error(`Pipeline stopped: ${error.message}`);
    } finally {
      setIsRunning(false);
    }
  };

  // Download Video
  const downloadVideo = () => {
    if (!generatedContent.video) return;
    const link = document.createElement('a');
    link.download = `${topic.replace(/\s+/g, '_')}_${Date.now()}.mp4`;
    link.href = `data:video/mp4;base64,${generatedContent.video}`;
    link.click();
    toast.success('Video downloaded!');
  };

  // Copy Meta
  const copyMeta = () => {
    if (!generatedContent.meta) return;
    const text = `TITLE:\n${generatedContent.meta.title}\n\nDESCRIPTION:\n${generatedContent.meta.description}\n\nTAGS:\n${generatedContent.meta.tags.join(', ')}`;
    navigator.clipboard.writeText(text);
    toast.success('Metadata copied to clipboard!');
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-3 rounded-xl bg-red-500/20">
              <Youtube className="w-8 h-8 text-red-500" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">YouTube Automation Pipeline</h1>
              <p className="text-muted-foreground">Topic → Script → Video → Ready to Upload</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Panel - Configuration */}
          <div className="lg:col-span-1 space-y-4">
            {/* Topic Selection */}
            <div className="p-5 rounded-xl border border-border bg-card">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <Target className="w-5 h-5 text-primary" />
                1. Choose Topic
              </h3>
              
              <div className="space-y-3">
                <Select value={niche} onValueChange={setNiche}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select niche" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="finance">💰 Finance & Money</SelectItem>
                    <SelectItem value="tech">💻 Tech & AI</SelectItem>
                    <SelectItem value="productivity">⚡ Productivity</SelectItem>
                  </SelectContent>
                </Select>

                <Input
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  placeholder="Enter your video topic..."
                  className="bg-background"
                />

                <div className="space-y-2">
                  <p className="text-xs text-muted-foreground">🔥 Trending in {niche}:</p>
                  {trendingTopics[niche]?.slice(0, 3).map((t, i) => (
                    <button
                      key={i}
                      onClick={() => setTopic(t)}
                      className="w-full text-left text-xs p-2 rounded bg-background/50 hover:bg-primary/10 transition-colors border border-transparent hover:border-primary/30"
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Video Settings */}
            <div className="p-5 rounded-xl border border-border bg-card">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <Film className="w-5 h-5 text-primary" />
                2. Video Settings
              </h3>
              
              <div className="space-y-3">
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">Format</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setVideoFormat('shorts')}
                      className={`p-3 rounded-lg border text-sm transition-all ${
                        videoFormat === 'shorts' 
                          ? 'border-primary bg-primary/20' 
                          : 'border-border hover:border-primary/50'
                      }`}
                    >
                      <div className="font-semibold">Shorts</div>
                      <div className="text-xs text-muted-foreground">9:16 • 45-60s</div>
                    </button>
                    <button
                      onClick={() => setVideoFormat('long')}
                      className={`p-3 rounded-lg border text-sm transition-all ${
                        videoFormat === 'long' 
                          ? 'border-primary bg-primary/20' 
                          : 'border-border hover:border-primary/50'
                      }`}
                    >
                      <div className="font-semibold">Long-form</div>
                      <div className="text-xs text-muted-foreground">16:9 • 5-10m</div>
                    </button>
                  </div>
                </div>

                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">Voice Style</label>
                  <Select value={voiceStyle} onValueChange={setVoiceStyle}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {voiceOptions.map(v => (
                        <SelectItem key={v.id} value={v.id}>
                          {v.name} - {v.desc}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* Run Pipeline Button */}
            <Button
              onClick={runPipeline}
              disabled={isRunning || !topic.trim()}
              className="w-full h-14 text-lg bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-700 hover:to-orange-700"
            >
              {isRunning ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Running Pipeline... Step {currentStep}/5
                </>
              ) : (
                <>
                  <Rocket className="w-5 h-5 mr-2" />
                  Generate Video
                </>
              )}
            </Button>
          </div>

          {/* Right Panel - Pipeline Progress & Output */}
          <div className="lg:col-span-2 space-y-4">
            {/* Pipeline Progress */}
            <div className="p-5 rounded-xl border border-border bg-card">
              <h3 className="font-semibold mb-4">Pipeline Progress</h3>
              <div className="flex items-center justify-between">
                {pipelineSteps.map((step, idx) => {
                  const Icon = step.icon;
                  const isComplete = currentStep > step.id;
                  const isCurrent = currentStep === step.id;
                  
                  return (
                    <React.Fragment key={step.id}>
                      <div className="flex flex-col items-center">
                        <div className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
                          isComplete ? 'bg-green-500/20 text-green-500' :
                          isCurrent ? 'bg-primary/20 text-primary animate-pulse' :
                          'bg-muted/20 text-muted-foreground'
                        }`}>
                          {isComplete ? (
                            <CheckCircle className="w-6 h-6" />
                          ) : isCurrent ? (
                            <Loader2 className="w-6 h-6 animate-spin" />
                          ) : (
                            <Icon className="w-6 h-6" />
                          )}
                        </div>
                        <span className="text-xs mt-2 text-center">{step.name}</span>
                      </div>
                      {idx < pipelineSteps.length - 1 && (
                        <div className={`flex-1 h-1 mx-2 rounded ${
                          currentStep > step.id ? 'bg-green-500' : 'bg-muted/30'
                        }`} />
                      )}
                    </React.Fragment>
                  );
                })}
              </div>
            </div>

            {/* Generated Script */}
            {generatedContent.script && (
              <div className="p-5 rounded-xl border border-border bg-card">
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-blue-500" />
                  Generated Script
                </h3>
                <div className="bg-background/50 rounded-lg p-4 max-h-48 overflow-y-auto text-sm">
                  <pre className="whitespace-pre-wrap font-mono text-xs">{generatedContent.script}</pre>
                </div>
              </div>
            )}

            {/* Scene Images */}
            {generatedContent.scenes.length > 0 && generatedContent.scenes.some(s => s.imageBase64) && (
              <div className="p-5 rounded-xl border border-border bg-card">
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <Image className="w-5 h-5 text-purple-500" />
                  Generated Scenes ({generatedContent.scenes.filter(s => s.imageBase64).length})
                </h3>
                <div className="grid grid-cols-4 gap-3">
                  {generatedContent.scenes.filter(s => s.imageBase64).map((scene, idx) => (
                    <div key={idx} className="aspect-video rounded-lg overflow-hidden bg-muted">
                      <img 
                        src={`data:image/png;base64,${scene.imageBase64}`} 
                        alt={`Scene ${idx + 1}`}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Final Video */}
            {generatedContent.video && (
              <div className="p-5 rounded-xl border border-green-500/30 bg-green-500/5">
                <h3 className="font-semibold mb-3 flex items-center gap-2 text-green-500">
                  <CheckCircle className="w-5 h-5" />
                  Video Ready!
                </h3>
                <div className="rounded-lg overflow-hidden bg-black mb-4">
                  <video 
                    controls 
                    className="w-full max-h-64"
                    src={`data:video/mp4;base64,${generatedContent.video}`}
                  />
                </div>
                <Button onClick={downloadVideo} className="w-full">
                  <Download className="w-4 h-4 mr-2" />
                  Download Video
                </Button>
              </div>
            )}

            {/* YouTube Meta */}
            {generatedContent.meta && (
              <div className="p-5 rounded-xl border border-border bg-card">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold flex items-center gap-2">
                    <Tags className="w-5 h-5 text-red-500" />
                    YouTube Metadata
                  </h3>
                  <Button size="sm" variant="outline" onClick={copyMeta}>
                    Copy All
                  </Button>
                </div>
                <div className="space-y-3 text-sm">
                  <div>
                    <label className="text-xs text-muted-foreground">Title</label>
                    <p className="font-medium bg-background/50 p-2 rounded">{generatedContent.meta.title}</p>
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground">Description</label>
                    <p className="bg-background/50 p-2 rounded whitespace-pre-wrap text-xs">{generatedContent.meta.description}</p>
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground">Tags</label>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {generatedContent.meta.tags.map((tag, i) => (
                        <span key={i} className="px-2 py-1 bg-primary/20 rounded text-xs">#{tag}</span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Empty State */}
            {!generatedContent.script && !isRunning && (
              <div className="p-12 rounded-xl border border-dashed border-border bg-card/50 text-center">
                <Sparkles className="w-16 h-16 mx-auto mb-4 text-muted-foreground/30" />
                <h3 className="text-xl font-semibold mb-2">Ready to Create</h3>
                <p className="text-muted-foreground mb-4">
                  Enter a topic and click "Generate Video" to start the automation pipeline
                </p>
                <p className="text-xs text-muted-foreground">
                  The system will generate: Script → Images → Voiceover → Video → Metadata
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default YouTubeAutomationPipeline;
