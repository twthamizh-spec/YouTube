import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { FolderOpen, Video, Image, Mic, Trash2, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import axios from 'axios';

const Projects = () => {
  const { user } = useAuth();
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
  const API = `${BACKEND_URL}/api`;

  useEffect(() => {
    if (user) {
      fetchProjects();
    }
  }, [user]);

  const fetchProjects = async () => {
    try {
      const response = await axios.get(`${API}/projects?user_id=${user.id}`);
      setProjects(response.data);
    } catch (error) {
      console.error('Failed to fetch projects:', error);
      toast.error('Failed to load projects');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (projectId) => {
    if (!window.confirm('Are you sure you want to delete this project?')) return;

    try {
      await axios.delete(`${API}/projects/${projectId}`);
      setProjects(projects.filter(p => p.id !== projectId));
      toast.success('Project deleted');
    } catch (error) {
      toast.error('Failed to delete project');
    }
  };

  const handleDownload = (project) => {
    if (project.output_base64) {
      const link = document.createElement('a');
      if (project.type === 'video') {
        link.href = `data:video/mp4;base64,${project.output_base64}`;
        link.download = `${project.title}.mp4`;
      } else if (project.type === 'image') {
        link.href = `data:image/png;base64,${project.output_base64}`;
        link.download = `${project.title}.png`;
      } else if (project.type === 'voiceover') {
        link.href = `data:audio/mp3;base64,${project.output_base64}`;
        link.download = `${project.title}.mp3`;
      }
      link.click();
      toast.success('Download started!');
    }
  };

  const filteredProjects = projects.filter(p => {
    if (filter === 'all') return true;
    return p.type === filter;
  });

  return (
    <div className="p-8 fade-in">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
          <FolderOpen className="text-primary" />
          Projects Library
        </h1>
        <p className="text-muted-foreground">Manage all your AI-generated content</p>
      </div>

      <div className="flex gap-2 mb-6">
        {['all', 'video', 'image', 'voiceover'].map((type) => (
          <Button
            key={type}
            onClick={() => setFilter(type)}
            data-testid={`filter-${type}`}
            className={filter === type ? 'btn-primary' : 'btn-secondary'}
          >
            {type.charAt(0).toUpperCase() + type.slice(1)}
          </Button>
        ))}
      </div>

      {loading ? (
        <div className="glass-panel p-12 text-center">
          <div className="loading-spinner w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full mx-auto" />
        </div>
      ) : filteredProjects.length === 0 ? (
        <div className="glass-panel p-12 text-center" data-testid="no-projects">
          <FolderOpen size={64} className="mx-auto mb-4 text-muted-foreground" />
          <h3 className="text-xl font-semibold mb-2">No projects found</h3>
          <p className="text-muted-foreground">Create your first project to see it here</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.map((project) => (
            <div key={project.id} className="glass-panel p-4" data-testid={`project-${project.id}`}>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  {project.type === 'video' && <Video size={20} className="text-purple-400" />}
                  {project.type === 'image' && <Image size={20} className="text-blue-400" />}
                  {project.type === 'voiceover' && <Mic size={20} className="text-green-400" />}
                  <span className={`text-xs px-2 py-1 rounded ${
                    project.status === 'completed' ? 'bg-green-500/20 text-green-400' :
                    project.status === 'generating' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-red-500/20 text-red-400'
                  }`}>
                    {project.status}
                  </span>
                </div>
              </div>

              <h4 className="font-semibold mb-2 truncate" data-testid={`project-title-${project.id}`}>{project.title}</h4>
              <p className="text-xs text-muted-foreground mb-4">
                {new Date(project.created_at).toLocaleDateString()}
              </p>

              {project.status === 'completed' && project.output_base64 && (
                <div className="mb-3">
                  {project.type === 'video' && (
                    <video
                      className="w-full rounded-lg"
                      src={`data:video/mp4;base64,${project.output_base64}`}
                      controls
                    />
                  )}
                  {project.type === 'image' && (
                    <img
                      className="w-full rounded-lg"
                      src={`data:image/png;base64,${project.output_base64}`}
                      alt={project.title}
                    />
                  )}
                  {project.type === 'voiceover' && (
                    <audio
                      className="w-full"
                      src={`data:audio/mp3;base64,${project.output_base64}`}
                      controls
                    />
                  )}
                </div>
              )}

              <div className="flex gap-2">
                {project.status === 'completed' && (
                  <Button
                    onClick={() => handleDownload(project)}
                    data-testid={`download-${project.id}`}
                    className="flex-1 btn-secondary text-xs py-2"
                  >
                    <Download size={14} className="mr-1" />
                    Download
                  </Button>
                )}
                <Button
                  onClick={() => handleDelete(project.id)}
                  data-testid={`delete-${project.id}`}
                  className="btn-secondary text-xs py-2"
                >
                  <Trash2 size={14} />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Projects;