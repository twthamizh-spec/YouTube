import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { LogIn, UserPlus, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

const AuthPage = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { login, register } = useAuth();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const result = isLogin ? await login(email, password) : await register(email, password);

    if (result.success) {
      toast.success(isLogin ? 'Welcome back!' : 'Account created successfully!');
    } else {
      toast.error(result.error);
    }

    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        <div className="glass-panel p-8 fade-in">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br from-primary to-accent mb-4">
              <Sparkles size={32} className="text-white" />
            </div>
            <h1 className="text-3xl font-bold mb-2">DIGITAL CATALYZT</h1>
            <p className="text-muted-foreground">Autonomous AI Growth OS</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                data-testid="auth-email-input"
                className="bg-background/50 border-border focus:border-primary"
              />
            </div>
            <div>
              <Input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                data-testid="auth-password-input"
                className="bg-background/50 border-border focus:border-primary"
              />
            </div>
            <Button
              type="submit"
              disabled={loading}
              data-testid="auth-submit-button"
              className="w-full btn-primary"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <div className="loading-spinner w-4 h-4 border-2 border-white/20 border-t-white rounded-full" />
                  Processing...
                </span>
              ) : (
                <span className="flex items-center gap-2">
                  {isLogin ? <LogIn size={18} /> : <UserPlus size={18} />}
                  {isLogin ? 'Sign In' : 'Create Account'}
                </span>
              )}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <button
              onClick={() => setIsLogin(!isLogin)}
              data-testid="auth-toggle-button"
              className="text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              {isLogin ? "Don't have an account? Sign up" : 'Already have an account? Sign in'}
            </button>
          </div>

          {!isLogin && (
            <div className="mt-6 p-4 bg-gradient-to-br from-primary/20 to-accent/20 border border-primary/30 rounded-lg">
              <p className="text-xs text-center font-semibold text-primary">
                🚀 PRIVATE UNLIMITED MODE - No restrictions, full power!
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AuthPage;