import React, { useState, useEffect } from 'react';
import { Store, Video, Image, Tag, Search } from 'lucide-react';
import { Input } from '../components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import axios from 'axios';
import { Link } from 'react-router-dom';

const TemplateMarketplace = () => {
  const [templates, setTemplates] = useState([]);
  const [categories, setCategories] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedType, setSelectedType] = useState('all');

  const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
  const API = `${BACKEND_URL}/api`;

  useEffect(() => {
    fetchTemplates();
    fetchCategories();
  }, []);

  const fetchTemplates = async () => {
    try {
      const response = await axios.get(`${API}/templates`);
      setTemplates(response.data);
    } catch (error) {
      console.error('Failed to fetch templates:', error);
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await axios.get(`${API}/templates/categories`);
      setCategories(response.data.categories);
    } catch (error) {
      console.error('Failed to fetch categories:', error);
    }
  };

  const filteredTemplates = templates.filter(template => {
    const matchesSearch = template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         template.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || template.category === selectedCategory;
    const matchesType = selectedType === 'all' || template.type === selectedType;
    return matchesSearch && matchesCategory && matchesType;
  });

  const getTypeColor = (type) => {
    switch (type) {
      case 'video': return 'purple';
      case 'image': return 'blue';
      case 'voiceover': return 'green';
      default: return 'gray';
    }
  };

  const getTypeLink = (template) => {
    switch (template.type) {
      case 'video': return '/video-creator';
      case 'image': return '/mockup-studio';
      case 'voiceover': return '/voiceover';
      default: return '/dashboard';
    }
  };

  return (
    <div className="p-8 max-w-7xl mx-auto fade-in">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
          <Store className="text-primary" />
          Template Marketplace
        </h1>
        <p className="text-muted-foreground">Browse {templates.length}+ professional templates for every need</p>
      </div>

      <div className="glass-panel p-6 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
            <Input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search templates..."
              data-testid="template-search"
              className="pl-10"
            />
          </div>

          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger data-testid="category-filter">
              <SelectValue placeholder="All Categories" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map((cat) => (
                <SelectItem key={cat} value={cat}>
                  {cat.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={selectedType} onValueChange={setSelectedType}>
            <SelectTrigger data-testid="type-filter">
              <SelectValue placeholder="All Types" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="video">Videos</SelectItem>
              <SelectItem value="image">Images</SelectItem>
              <SelectItem value="voiceover">Voiceovers</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTemplates.map((template) => {
          const color = getTypeColor(template.type);
          return (
            <Link
              key={template.id}
              to={getTypeLink(template)}
              data-testid={`template-card-${template.id}`}
              className="card-interactive p-6 group"
            >
              <div className="flex items-start justify-between mb-4">
                <div className={`inline-flex items-center justify-center w-12 h-12 rounded-lg bg-gradient-to-br from-${color}-500 to-${color}-600 group-hover:scale-110 transition-transform duration-300`}>
                  {template.type === 'video' && <Video size={24} className="text-white" />}
                  {template.type === 'image' && <Image size={24} className="text-white" />}
                  {template.type === 'voiceover' && <Video size={24} className="text-white" />}
                </div>
                <span className="text-xs px-3 py-1 rounded-full bg-primary/20 text-primary font-medium">
                  {template.cost} credits
                </span>
              </div>

              <h3 className="text-xl font-semibold mb-2">{template.name}</h3>
              <p className="text-sm text-muted-foreground mb-4">{template.description}</p>

              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs px-2 py-1 rounded bg-white/5 border border-white/10 capitalize">
                  {template.type}
                </span>
                {template.category && (
                  <span className="text-xs px-2 py-1 rounded bg-white/5 border border-white/10 capitalize flex items-center gap-1">
                    <Tag size={12} />
                    {template.category.replace('_', ' ')}
                  </span>
                )}
              </div>
            </Link>
          );
        })}
      </div>

      {filteredTemplates.length === 0 && (
        <div className="glass-panel p-12 text-center" data-testid="no-templates-found">
          <Store size={64} className="mx-auto mb-4 text-muted-foreground" />
          <h3 className="text-xl font-semibold mb-2">No templates found</h3>
          <p className="text-muted-foreground">Try adjusting your filters or search term</p>
        </div>
      )}
    </div>
  );
};

export default TemplateMarketplace;