import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Palette, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import axios from 'axios';

const BrandKit = () => {
  const { user, refreshUser } = useAuth();
  const [logoUrl, setLogoUrl] = useState(user?.brand_kit?.logo_url || '');
  const [colors, setColors] = useState(user?.brand_kit?.colors?.join(', ') || '');
  const [fonts, setFonts] = useState(user?.brand_kit?.fonts?.join(', ') || '');
  const [tone, setTone] = useState(user?.brand_kit?.tone || '');
  const [saving, setSaving] = useState(false);

  const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
  const API = `${BACKEND_URL}/api`;

  const handleSave = async () => {
    setSaving(true);

    try {
      await axios.put(`${API}/users/${user.id}/brand-kit`, {
        logo_url: logoUrl || null,
        colors: colors ? colors.split(',').map(c => c.trim()) : null,
        fonts: fonts ? fonts.split(',').map(f => f.trim()) : null,
        tone: tone || null
      });

      toast.success('Brand kit saved successfully!');
      refreshUser();
    } catch (error) {
      toast.error('Failed to save brand kit');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-8 max-w-4xl mx-auto fade-in">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
          <Palette className="text-primary" />
          Brand Kit
        </h1>
        <p className="text-muted-foreground">Save your brand identity for consistent content</p>
      </div>

      <div className="glass-panel p-6 space-y-6">
        <div>
          <label className="block text-sm font-medium mb-2">Logo URL</label>
          <Input
            value={logoUrl}
            onChange={(e) => setLogoUrl(e.target.value)}
            placeholder="https://example.com/logo.png"
            data-testid="logo-url-input"
          />
          <p className="text-xs text-muted-foreground mt-1">
            Enter a URL to your logo image
          </p>
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Brand Colors</label>
          <Input
            value={colors}
            onChange={(e) => setColors(e.target.value)}
            placeholder="#6366f1, #d946ef, #0ea5e9"
            data-testid="colors-input"
          />
          <p className="text-xs text-muted-foreground mt-1">
            Enter hex color codes separated by commas
          </p>
          {colors && (
            <div className="flex gap-2 mt-3">
              {colors.split(',').map((color, i) => (
                <div
                  key={i}
                  className="w-12 h-12 rounded-lg border-2 border-white/10 shadow-lg"
                  style={{ backgroundColor: color.trim() }}
                />
              ))}
            </div>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Brand Fonts</label>
          <Input
            value={fonts}
            onChange={(e) => setFonts(e.target.value)}
            placeholder="Outfit, Manrope, Inter"
            data-testid="fonts-input"
          />
          <p className="text-xs text-muted-foreground mt-1">
            Enter font names separated by commas
          </p>
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Brand Tone</label>
          <Textarea
            value={tone}
            onChange={(e) => setTone(e.target.value)}
            placeholder="Professional, friendly, innovative..."
            rows={4}
            data-testid="tone-input"
            className="bg-background/50 border-border focus:border-primary resize-none"
          />
          <p className="text-xs text-muted-foreground mt-1">
            Describe your brand's voice and tone
          </p>
        </div>

        <Button
          onClick={handleSave}
          disabled={saving}
          data-testid="save-brand-kit-button"
          className="w-full btn-primary"
        >
          {saving ? (
            <span className="flex items-center gap-2">
              <div className="loading-spinner w-4 h-4 border-2 border-white/20 border-t-white rounded-full" />
              Saving...
            </span>
          ) : (
            <span className="flex items-center gap-2">
              <Save size={18} />
              Save Brand Kit
            </span>
          )}
        </Button>
      </div>

      <div className="mt-8 glass-panel p-6">
        <h3 className="text-lg font-semibold mb-4">Why Brand Kit?</h3>
        <ul className="space-y-2 text-sm text-muted-foreground">
          <li>• Maintain consistent branding across all AI-generated content</li>
          <li>• Automatically apply your colors and style to videos and images</li>
          <li>• Save time by not having to specify brand details every time</li>
          <li>• Professional results that match your brand identity</li>
        </ul>
      </div>
    </div>
  );
};

export default BrandKit;