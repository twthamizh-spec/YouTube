import React from 'react';
import { useNavigate } from 'react-router-dom';
import { BarChart3, Target, TrendingUp, Zap, Clock, DollarSign, CheckCircle, AlertCircle } from 'lucide-react';

const ExecutiveDecisionCenter = () => {
  const navigate = useNavigate();

  const takeAction = (action) => {
    // Extract topic from action
    let topic = '';
    let hook = 'Problem → Solution';
    
    if (action.action.includes('AI automation')) {
      topic = 'AI Automation Tools';
      hook = 'Shocking Statement';
    } else if (action.action.includes('remote work')) {
      topic = 'Remote Work Setup';
      hook = 'Problem → Solution';
    }

    navigate('/creative-studio', {
      state: {
        source: 'Decision Center',
        topic,
        hook,
        format: 'Shorts (45s)',
        aspectRatio: '9:16',
        captionStyle: 'pop',
        impact: action.impact,
        timeframe: action.timeframe
      }
    });
  };

  const queueContent = (recommendation) => {
    navigate('/creative-studio', {
      state: {
        source: 'Decision Center',
        topic: recommendation.topic,
        format: recommendation.format,
        aspectRatio: recommendation.format.includes('Shorts') ? '9:16' : '16:9',
        captionStyle: 'pop',
        expectedViews: recommendation.expectedViews,
        bestTime: recommendation.bestTime,
        confidence: recommendation.confidence
      }
    });
  };
  // Weekly Summary Data
  const weeklyMetrics = {
    videosCreated: 12,
    totalViews: '2.8M',
    avgRetention: '67%',
    topPerformer: 'AI Tool Showcase #3',
    revenue: '$3,450',
    trend: '+156%'
  };

  // Priority Actions
  const priorityActions = [
    {
      action: 'Create AI automation content',
      reason: 'Trending +425%, Low competition',
      impact: 'Very High',
      effort: 'Low',
      timeframe: '24 hours',
      status: 'urgent'
    },
    {
      action: 'Publish remote work setup video',
      reason: 'High demand, Strong engagement signals',
      impact: 'High',
      effort: 'Medium',
      timeframe: '48 hours',
      status: 'important'
    },
    {
      action: 'Avoid crypto content',
      reason: 'Trend falling -45%, Over-saturated',
      impact: 'Medium',
      effort: 'None',
      timeframe: 'Now',
      status: 'warning'
    }
  ];

  // Content Recommendations
  const contentRecommendations = [
    {
      topic: 'AI Image Generation Tutorial',
      format: 'Shorts (45s)',
      expectedViews: '2.4M',
      confidence: '92%',
      bestTime: 'Today 6-8 PM'
    },
    {
      topic: 'Remote Work Productivity Hacks',
      format: 'Long-form (8m)',
      expectedViews: '890K',
      confidence: '85%',
      bestTime: 'Tomorrow 7-9 AM'
    },
    {
      topic: 'Budget Travel Tips 2025',
      format: 'Shorts (60s)',
      expectedViews: '1.2M',
      confidence: '78%',
      bestTime: 'Friday 12-2 PM'
    }
  ];

  // ROI Projections
  const roiData = [
    { category: 'AI/Tech Content', investment: '$500', expectedReturn: '$4,200', roi: '740%' },
    { category: 'Productivity', investment: '$300', expectedReturn: '$1,800', roi: '500%' },
    { category: 'Lifestyle', investment: '$200', expectedReturn: '$800', roi: '300%' }
  ];

  // Resource Allocation
  const resourceAllocation = [
    { resource: 'Video Production', current: '40%', recommended: '30%', reason: 'Automate more' },
    { resource: 'Research & Trends', current: '20%', recommended: '35%', reason: 'Critical for trending topics' },
    { resource: 'Editing', current: '30%', recommended: '25%', reason: 'Use AI tools' },
    { resource: 'Distribution', current: '10%', recommended: '10%', reason: 'Optimal' }
  ];

  const getImpactColor = (impact) => {
    if (impact === 'Very High') return 'text-green-400';
    if (impact === 'High') return 'text-blue-400';
    return 'text-yellow-400';
  };

  const getStatusBadge = (status) => {
    if (status === 'urgent') {
      return <span className="px-3 py-1 rounded-full text-xs font-bold bg-red-500/20 text-red-400 border border-red-500/50">🚨 URGENT</span>;
    }
    if (status === 'important') {
      return <span className="px-3 py-1 rounded-full text-xs font-bold bg-blue-500/20 text-blue-400 border border-blue-500/50">⭐ IMPORTANT</span>;
    }
    return <span className="px-3 py-1 rounded-full text-xs font-bold bg-yellow-500/20 text-yellow-400 border border-yellow-500/50">⚠️ WARNING</span>;
  };

  return (
    <div className="p-8 max-w-[1800px] mx-auto fade-in">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
          <BarChart3 className="text-primary" />
          Executive Decision Center
        </h1>
        <p className="text-muted-foreground">Strategic overview, ROI projections & priority actions</p>
      </div>

      {/* Weekly Performance Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        <div className="glass-panel p-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-semibold text-muted-foreground">Videos Created</h3>
            <Zap className="text-primary" size={20} />
          </div>
          <div className="text-4xl font-bold mb-1">{weeklyMetrics.videosCreated}</div>
          <div className="text-xs text-muted-foreground">This week</div>
        </div>

        <div className="glass-panel p-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-semibold text-muted-foreground">Total Views</h3>
            <TrendingUp className="text-green-400" size={20} />
          </div>
          <div className="text-4xl font-bold mb-1">{weeklyMetrics.totalViews}</div>
          <div className="text-xs text-green-400 font-semibold">{weeklyMetrics.trend} vs last week</div>
        </div>

        <div className="glass-panel p-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-semibold text-muted-foreground">Avg Retention</h3>
            <Target className="text-accent" size={20} />
          </div>
          <div className="text-4xl font-bold mb-1">{weeklyMetrics.avgRetention}</div>
          <div className="text-xs text-muted-foreground">Industry avg: 52%</div>
        </div>

        <div className="glass-panel p-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-semibold text-muted-foreground">Revenue</h3>
            <DollarSign className="text-green-400" size={20} />
          </div>
          <div className="text-4xl font-bold mb-1">{weeklyMetrics.revenue}</div>
          <div className="text-xs text-muted-foreground">This week</div>
        </div>

        <div className="glass-panel p-6 lg:col-span-2">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-semibold text-muted-foreground">Top Performer</h3>
            <Target className="text-primary" size={20} />
          </div>
          <div className="text-2xl font-bold mb-1">{weeklyMetrics.topPerformer}</div>
          <div className="text-xs text-green-400">1.2M views • 89% retention</div>
        </div>
      </div>

      {/* Priority Actions */}
      <div className="glass-panel p-6 mb-8">
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          <AlertCircle className="text-red-400" />
          Priority Actions (Next 48 Hours)
        </h2>
        <div className="space-y-4">
          {priorityActions.map((item, idx) => (
            <div key={idx} className="p-5 bg-background/50 rounded-lg border-l-4 border-primary">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <h3 className="font-bold text-lg mb-1">{item.action}</h3>
                  <p className="text-sm text-muted-foreground mb-2">{item.reason}</p>
                </div>
                {getStatusBadge(item.status)}
              </div>
              <div className="grid grid-cols-4 gap-4 text-sm">
                <div>
                  <div className="text-muted-foreground text-xs mb-1">Impact</div>
                  <div className={`font-bold ${getImpactColor(item.impact)}`}>{item.impact}</div>
                </div>
                <div>
                  <div className="text-muted-foreground text-xs mb-1">Effort</div>
                  <div className="font-semibold">{item.effort}</div>
                </div>
                <div>
                  <div className="text-muted-foreground text-xs mb-1">Timeframe</div>
                  <div className="font-semibold text-accent">{item.timeframe}</div>
                </div>
                <div className="flex items-end">
                  <button 
                    onClick={() => takeAction(item)}
                    className="px-4 py-2 rounded bg-primary text-primary-foreground font-semibold text-xs hover:bg-primary/90 transition-colors"
                  >
                    Take Action →
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Content Recommendations */}
      <div className="glass-panel p-6 mb-8">
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          <Zap className="text-accent" />
          Recommended Content Pipeline
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {contentRecommendations.map((rec, idx) => (
            <div key={idx} className="p-5 bg-background/50 rounded-lg border border-border hover:border-primary/50 transition-colors">
              <div className="mb-4">
                <span className="px-2 py-1 rounded text-xs bg-primary/20 text-primary font-semibold">
                  Rank #{idx + 1}
                </span>
              </div>
              <h3 className="font-bold text-lg mb-2">{rec.topic}</h3>
              <div className="space-y-2 text-sm mb-4">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Format:</span>
                  <span className="font-semibold">{rec.format}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Expected Views:</span>
                  <span className="font-bold text-green-400">{rec.expectedViews}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Confidence:</span>
                  <span className="font-bold text-primary">{rec.confidence}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Best Time:</span>
                  <span className="font-semibold text-accent">{rec.bestTime}</span>
                </div>
              </div>
              <button 
                onClick={() => queueContent(rec)}
                className="w-full px-4 py-2 rounded bg-primary text-primary-foreground font-semibold text-sm hover:bg-primary/90 transition-colors"
              >
                Queue for Production
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* ROI Projections */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="glass-panel p-6">
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
            <DollarSign className="text-green-400" />
            ROI Projections
          </h2>
          <div className="space-y-4">
            {roiData.map((item, idx) => (
              <div key={idx} className="p-4 bg-background/50 rounded-lg border border-border">
                <h3 className="font-semibold mb-3">{item.category}</h3>
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div>
                    <div className="text-muted-foreground text-xs mb-1">Investment</div>
                    <div className="font-bold">{item.investment}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground text-xs mb-1">Expected Return</div>
                    <div className="font-bold text-green-400">{item.expectedReturn}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground text-xs mb-1">ROI</div>
                    <div className="font-bold text-primary text-xl">{item.roi}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Resource Allocation */}
        <div className="glass-panel p-6">
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
            <Target className="text-primary" />
            Resource Allocation
          </h2>
          <div className="space-y-4">
            {resourceAllocation.map((resource, idx) => (
              <div key={idx} className="p-4 bg-background/50 rounded-lg border border-border">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-semibold">{resource.resource}</h3>
                  <span className="text-xs text-muted-foreground">{resource.reason}</span>
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <div className="text-muted-foreground text-xs mb-1">Current</div>
                    <div className="font-bold">{resource.current}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground text-xs mb-1">Recommended</div>
                    <div className={`font-bold ${resource.current === resource.recommended ? 'text-green-400' : 'text-yellow-400'}`}>
                      {resource.recommended}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick Wins */}
      <div className="glass-panel p-6 mb-8 bg-gradient-to-r from-green-500/10 to-blue-500/10 border-green-500/30">
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          <CheckCircle className="text-green-400" />
          Quick Wins This Week
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-background/80 rounded-lg">
            <div className="text-3xl mb-2">🎯</div>
            <h3 className="font-semibold mb-1">Post AI content NOW</h3>
            <p className="text-xs text-muted-foreground">Low competition, high demand window open</p>
          </div>
          <div className="p-4 bg-background/80 rounded-lg">
            <div className="text-3xl mb-2">⏰</div>
            <h3 className="font-semibold mb-1">Schedule for 6-8 PM EST</h3>
            <p className="text-xs text-muted-foreground">Peak engagement time for your niche</p>
          </div>
          <div className="p-4 bg-background/80 rounded-lg">
            <div className="text-3xl mb-2">💰</div>
            <h3 className="font-semibold mb-1">Focus on Shorts</h3>
            <p className="text-xs text-muted-foreground">740% ROI potential this week</p>
          </div>
        </div>
      </div>

      {/* Info Banner */}
      <div className="glass-panel p-6 bg-primary/10 border border-primary/30">
        <div className="flex items-start gap-4">
          <AlertCircle className="text-primary mt-1" size={24} />
          <div>
            <h3 className="font-semibold mb-2">Dashboard Status: Mock Data</h3>
            <p className="text-sm text-muted-foreground">
              Currently displaying simulated decision intelligence. Future updates will integrate real-time performance data, automated ROI tracking, and AI-powered content recommendations.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExecutiveDecisionCenter;
