import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Mic, Play, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import axios from 'axios';

const Voiceover = () => {
  const { user, refreshUser } = useAuth();
  const [text, setText] = useState('');
  const [voice, setVoice] = useState('alloy');
  const [model, setModel] = useState('tts-1');
  const [generating, setGenerating] = useState(false);
  const [result, setResult] = useState(null);

  const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
  const API = `${BACKEND_URL}/api`;

  const voices = [
    { value: 'alloy', label: 'Alloy (Neutral, Balanced)' },
    { value: 'echo', label: 'Echo (Smooth, Calm)' },
    { value: 'fable', label: 'Fable (Expressive, Storytelling)' },
    { value: 'onyx', label: 'Onyx (Deep, Authoritative)' },
    { value: 'nova', label: 'Nova (Energetic, Upbeat)' },
    { value: 'shimmer', label: 'Shimmer (Bright, Cheerful)' },
  ];

  const handleGenerate = async () => {
    if (!text.trim()) {
      toast.error('Please enter some text');
      return;
    }

    if (text.length > 4096) {
      toast.error('Text must be less than 4096 characters');
      return;
    }

    setGenerating(true);
    setResult(null);

    try {
      const response = await axios.post(`${API}/voiceover/generate`, {
        user_id: user.id,
        text,
        voice,
        model
      });

      setResult(response.data);
      toast.success('Voiceover generated successfully!');
      refreshUser();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Voiceover generation failed');
    } finally {
      setGenerating(false);
    }
  };

  const handleDownload = () => {
    if (result?.audio_base64) {
      const link = document.createElement('a');
      link.href = `data:audio/mp3;base64,${result.audio_base64}`;
      link.download = 'voiceover.mp3';
      link.click();
      toast.success('Download started!');
    }
  };

  return (
    <div className="p-8 max-w-6xl mx-auto fade-in">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
          <Mic className="text-primary" />
          AI Voiceover Studio
        </h1>
        <p className="text-muted-foreground">Convert text to natural-sounding speech</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="glass-panel p-6">
          <h2 className="text-xl font-semibold mb-4">Configuration</h2>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Text (max 4096 chars)</label>
              <Textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Enter the text you want to convert to speech..."
                rows={8}
                data-testid="voiceover-text-input"
                className="bg-background/50 border-border focus:border-primary resize-none"
              />
              <p className="text-xs text-muted-foreground mt-1">{text.length} / 4096 characters</p>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Voice</label>
              <Select value={voice} onValueChange={setVoice}>
                <SelectTrigger data-testid="voice-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {voices.map((v) => (
                    <SelectItem key={v.value} value={v.value}>
                      {v.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Quality</label>
              <Select value={model} onValueChange={setModel}>
                <SelectTrigger data-testid="quality-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="tts-1">Standard (Faster)</SelectItem>
                  <SelectItem value="tts-1-hd">HD (Higher Quality)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="pt-4">
              <Button
                onClick={handleGenerate}
                disabled={generating || !text.trim()}
                data-testid="generate-voiceover-button"
                className="w-full btn-primary"
              >
                {generating ? (
                  <span className="flex items-center gap-2">
                    <div className="loading-spinner w-4 h-4 border-2 border-white/20 border-t-white rounded-full" />
                    Generating...
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    <Play size={18} />
                    Generate Voiceover (3 credits)
                  </span>
                )}
              </Button>
            </div>
          </div>
        </div>

        <div className="glass-panel p-6">
          <h2 className="text-xl font-semibold mb-4">Audio Player</h2>

          {result ? (
            <div className="space-y-4" data-testid="voiceover-result">
              <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 rounded-lg p-8 border border-green-500/20">
                <audio
                  controls
                  className="w-full"
                  src={`data:audio/mp3;base64,${result.audio_base64}`}
                  data-testid="audio-player"
                >
                  Your browser does not support the audio tag.
                </audio>
              </div>
              <Button
                onClick={handleDownload}
                data-testid="download-audio-button"
                className="w-full btn-secondary"
              >
                <Download size={18} className="mr-2" />
                Download Audio
              </Button>
            </div>
          ) : (
            <div className="aspect-square bg-gradient-to-br from-green-500/10 to-emerald-500/10 rounded-lg flex items-center justify-center border-2 border-dashed border-border" data-testid="voiceover-placeholder">
              <div className="text-center">
                <Mic size={64} className="mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground">Your voiceover will appear here</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Voiceover;