import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { 
  Scissors, Type, Sparkles, Download, Upload, Layers, 
  RotateCw, ZoomIn, ZoomOut, Crop, Palette, Sliders,
  Play, Pause, SkipBack, SkipForward, Volume2, Film
} from 'lucide-react';
import { Button } from '../components/ui/button';
import { Slider } from '../components/ui/slider';
import { Input } from '../components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { toast } from 'sonner';

const CreativeStudio = () => {
  const { user } = useAuth();
  const [mode, setMode] = useState('image'); // 'image' or 'video'
  const [file, setFile] = useState(null);
  const [fileURL, setFileURL] = useState(null);
  const [brightness, setBrightness] = useState(100);
  const [contrast, setContrast] = useState(100);
  const [saturation, setSaturation] = useState(100);
  const [rotation, setRotation] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [filters, setFilters] = useState([]);
  const [textOverlays, setTextOverlays] = useState([]);
  const [newText, setNewText] = useState('');
  
  // Video specific states
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  
  const canvasRef = useRef(null);
  const videoRef = useRef(null);
  const fileInputRef = useRef(null);

  const presetFilters = [
    { name: 'None', value: 'none' },
    { name: 'Vintage', value: 'sepia(0.6) contrast(1.2)' },
    { name: 'B&W', value: 'grayscale(1)' },
    { name: 'Cool', value: 'hue-rotate(180deg)' },
    { name: 'Warm', value: 'sepia(0.3) saturate(1.4)' },
    { name: 'High Contrast', value: 'contrast(1.5) saturate(1.2)' },
    { name: 'Dreamy', value: 'brightness(1.1) contrast(0.9) blur(0.5px)' },
  ];

  useEffect(() => {
    if (file && mode === 'image') {
      drawCanvas();
    }
  }, [brightness, contrast, saturation, rotation, zoom, filters, textOverlays]);

  const handleFileUpload = (e) => {
    const uploadedFile = e.target.files[0];
    if (!uploadedFile) return;

    const url = URL.createObjectURL(uploadedFile);
    setFile(uploadedFile);
    setFileURL(url);

    if (mode === 'image') {
      const img = new Image();
      img.onload = () => drawCanvas();
      img.src = url;
    } else {
      // Video mode
      if (videoRef.current) {
        videoRef.current.src = url;
      }
    }
    
    toast.success(`${mode === 'image' ? 'Image' : 'Video'} loaded successfully!`);
  };

  const drawCanvas = () => {
    if (!canvasRef.current || !fileURL || mode !== 'image') return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const img = new Image();
    
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.save();
      
      // Apply transforms
      ctx.translate(canvas.width / 2, canvas.height / 2);
      ctx.rotate((rotation * Math.PI) / 180);
      ctx.scale(zoom, zoom);
      ctx.translate(-canvas.width / 2, -canvas.height / 2);
      
      // Apply filters
      const filterString = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%)`;
      ctx.filter = filters.length > 0 ? filters[0].value : filterString;
      
      ctx.drawImage(img, 0, 0);
      ctx.restore();
      
      // Draw text overlays
      textOverlays.forEach((overlay, index) => {
        ctx.font = `${overlay.size || 48}px ${overlay.font || 'Arial'}`;
        ctx.fillStyle = overlay.color || '#ffffff';
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 2;
        ctx.strokeText(overlay.text, overlay.x || 50, overlay.y || 100 + (index * 60));
        ctx.fillText(overlay.text, overlay.x || 50, overlay.y || 100 + (index * 60));
      });
    };
    
    img.src = fileURL;
  };

  const addTextOverlay = () => {
    if (!newText.trim()) {
      toast.error('Please enter text');
      return;
    }
    
    setTextOverlays([...textOverlays, {
      text: newText,
      x: 50,
      y: 100 + (textOverlays.length * 60),
      size: 48,
      color: '#ffffff',
      font: 'Arial'
    }]);
    setNewText('');
    toast.success('Text overlay added!');
  };

  const applyFilter = (filter) => {
    if (filter.value === 'none') {
      setFilters([]);
    } else {
      setFilters([filter]);
    }
  };

  const handleDownload = () => {
    if (mode === 'image' && canvasRef.current) {
      const link = document.createElement('a');
      link.download = `edited-image-${Date.now()}.png`;
      link.href = canvasRef.current.toDataURL('image/png');
      link.click();
      toast.success('Image downloaded!');
    } else if (mode === 'video') {
      toast.info('Video export coming soon! Use screen recording for now.');
    }
  };

  const resetAll = () => {
    setBrightness(100);
    setContrast(100);
    setSaturation(100);
    setRotation(0);
    setZoom(1);
    setFilters([]);
    setTextOverlays([]);
    toast.info('All adjustments reset');
  };

  // Video controls
  const togglePlayPause = () => {
    if (!videoRef.current) return;
    
    if (isPlaying) {
      videoRef.current.pause();
    } else {
      videoRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const handleVideoTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
    }
  };

  const handleVideoLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
    }
  };

  const handleSeek = (value) => {
    if (videoRef.current) {
      videoRef.current.currentTime = value[0];
      setCurrentTime(value[0]);
    }
  };

  const handleVolumeChange = (value) => {
    if (videoRef.current) {
      videoRef.current.volume = value[0];
      setVolume(value[0]);
    }
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="p-8 max-w-7xl mx-auto fade-in">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
          <Sparkles className="text-primary" />
          Creative Studio
        </h1>
        <p className="text-muted-foreground">Professional image and video editing suite</p>
      </div>

      {/* Mode Selector */}
      <div className="glass-panel p-4 mb-6">
        <div className="flex gap-4">
          <Button
            onClick={() => { setMode('image'); setFile(null); setFileURL(null); }}
            className={mode === 'image' ? 'btn-primary' : 'btn-secondary'}
          >
            <Palette size={18} className="mr-2" />
            Image Editor
          </Button>
          <Button
            onClick={() => { setMode('video'); setFile(null); setFileURL(null); }}
            className={mode === 'video' ? 'btn-primary' : 'btn-secondary'}
          >
            <Film size={18} className="mr-2" />
            Video Editor
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Tools Panel */}
        <div className="glass-panel p-6 space-y-6">
          <div>
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <Sliders size={20} className="text-primary" />
              Tools & Controls
            </h2>
            
            <input
              ref={fileInputRef}
              type="file"
              accept={mode === 'image' ? 'image/*' : 'video/*'}
              onChange={handleFileUpload}
              className="hidden"
            />
            
            <Button
              onClick={() => fileInputRef.current?.click()}
              className="btn-primary w-full mb-4"
            >
              <Upload size={18} className="mr-2" />
              Upload {mode === 'image' ? 'Image' : 'Video'}
            </Button>
          </div>

          {file && (
            <>
              {mode === 'image' && (
                <>
                  {/* Adjustments */}
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium mb-2 block">Brightness</label>
                      <Slider
                        value={[brightness]}
                        onValueChange={(val) => setBrightness(val[0])}
                        min={0}
                        max={200}
                        step={1}
                        className="w-full"
                      />
                      <span className="text-xs text-muted-foreground">{brightness}%</span>
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Contrast</label>
                      <Slider
                        value={[contrast]}
                        onValueChange={(val) => setContrast(val[0])}
                        min={0}
                        max={200}
                        step={1}
                        className="w-full"
                      />
                      <span className="text-xs text-muted-foreground">{contrast}%</span>
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Saturation</label>
                      <Slider
                        value={[saturation]}
                        onValueChange={(val) => setSaturation(val[0])}
                        min={0}
                        max={200}
                        step={1}
                        className="w-full"
                      />
                      <span className="text-xs text-muted-foreground">{saturation}%</span>
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Rotation</label>
                      <Slider
                        value={[rotation]}
                        onValueChange={(val) => setRotation(val[0])}
                        min={0}
                        max={360}
                        step={1}
                        className="w-full"
                      />
                      <span className="text-xs text-muted-foreground">{rotation}°</span>
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Zoom</label>
                      <Slider
                        value={[zoom]}
                        onValueChange={(val) => setZoom(val[0])}
                        min={0.5}
                        max={3}
                        step={0.1}
                        className="w-full"
                      />
                      <span className="text-xs text-muted-foreground">{zoom.toFixed(1)}x</span>
                    </div>
                  </div>

                  {/* Filters */}
                  <div>
                    <label className="text-sm font-medium mb-2 block">Preset Filters</label>
                    <div className="grid grid-cols-2 gap-2">
                      {presetFilters.map((filter) => (
                        <Button
                          key={filter.name}
                          onClick={() => applyFilter(filter)}
                          className={`btn-secondary text-xs ${
                            filters[0]?.name === filter.name ? 'ring-2 ring-primary' : ''
                          }`}
                          size="sm"
                        >
                          {filter.name}
                        </Button>
                      ))}
                    </div>
                  </div>

                  {/* Text Overlay */}
                  <div>
                    <label className="text-sm font-medium mb-2 block flex items-center gap-2">
                      <Type size={16} />
                      Add Text
                    </label>
                    <div className="flex gap-2">
                      <Input
                        value={newText}
                        onChange={(e) => setNewText(e.target.value)}
                        placeholder="Enter text..."
                        className="flex-1"
                      />
                      <Button onClick={addTextOverlay} className="btn-primary" size="sm">
                        Add
                      </Button>
                    </div>
                    {textOverlays.length > 0 && (
                      <div className="mt-2 text-xs text-muted-foreground">
                        {textOverlays.length} text overlay(s) added
                      </div>
                    )}
                  </div>
                </>
              )}

              {mode === 'video' && (
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Volume</label>
                    <Slider
                      value={[volume]}
                      onValueChange={handleVolumeChange}
                      min={0}
                      max={1}
                      step={0.01}
                      className="w-full"
                    />
                    <span className="text-xs text-muted-foreground">{Math.round(volume * 100)}%</span>
                  </div>

                  <div className="p-4 bg-primary/10 border border-primary/20 rounded-lg">
                    <p className="text-sm text-muted-foreground mb-2">
                      Advanced video editing features including:
                    </p>
                    <ul className="text-xs space-y-1 text-muted-foreground">
                      <li>• Trim & Cut (Coming Soon)</li>
                      <li>• Transitions (Coming Soon)</li>
                      <li>• Audio Tracks (Coming Soon)</li>
                      <li>• Effects Library (Coming Soon)</li>
                      <li>• 4K Export (Coming Soon)</li>
                    </ul>
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="space-y-2 pt-4 border-t border-border">
                <Button onClick={handleDownload} className="btn-primary w-full">
                  <Download size={18} className="mr-2" />
                  Download
                </Button>
                <Button onClick={resetAll} className="btn-secondary w-full">
                  <RotateCw size={18} className="mr-2" />
                  Reset All
                </Button>
              </div>
            </>
          )}

          {!file && (
            <div className="text-center py-12 text-muted-foreground">
              <Upload size={48} className="mx-auto mb-4 opacity-50" />
              <p className="text-sm">Upload a {mode} to get started</p>
            </div>
          )}
        </div>

        {/* Canvas/Preview Area */}
        <div className="lg:col-span-2 glass-panel p-6">
          <h2 className="text-xl font-semibold mb-4">Preview</h2>
          
          {!file && (
            <div className="aspect-video bg-background/50 rounded-lg flex items-center justify-center border-2 border-dashed border-border">
              <div className="text-center">
                <Sparkles size={64} className="mx-auto mb-4 text-muted-foreground opacity-50" />
                <p className="text-muted-foreground">Your {mode} will appear here</p>
              </div>
            </div>
          )}

          {mode === 'image' && file && (
            <div className="relative bg-background/50 rounded-lg overflow-hidden">
              <canvas
                ref={canvasRef}
                className="w-full h-auto max-h-[600px] object-contain"
              />
            </div>
          )}

          {mode === 'video' && file && (
            <div className="space-y-4">
              <div className="relative bg-black rounded-lg overflow-hidden">
                <video
                  ref={videoRef}
                  className="w-full h-auto max-h-[500px]"
                  onTimeUpdate={handleVideoTimeUpdate}
                  onLoadedMetadata={handleVideoLoadedMetadata}
                  onEnded={() => setIsPlaying(false)}
                />
              </div>

              {/* Video Controls */}
              <div className="glass-panel p-4 space-y-4">
                <div className="flex items-center gap-4">
                  <Button onClick={togglePlayPause} className="btn-primary" size="sm">
                    {isPlaying ? <Pause size={18} /> : <Play size={18} />}
                  </Button>
                  
                  <div className="flex-1 flex items-center gap-3">
                    <span className="text-xs text-muted-foreground min-w-[40px]">
                      {formatTime(currentTime)}
                    </span>
                    <Slider
                      value={[currentTime]}
                      onValueChange={handleSeek}
                      min={0}
                      max={duration || 0}
                      step={0.1}
                      className="flex-1"
                    />
                    <span className="text-xs text-muted-foreground min-w-[40px]">
                      {formatTime(duration)}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 min-w-[100px]">
                    <Volume2 size={18} className="text-muted-foreground" />
                    <Slider
                      value={[volume]}
                      onValueChange={handleVolumeChange}
                      min={0}
                      max={1}
                      step={0.01}
                      className="w-20"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CreativeStudio;
