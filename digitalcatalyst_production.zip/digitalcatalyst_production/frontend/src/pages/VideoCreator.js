import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Video, Play, Download, Loader2, CheckCircle2, XCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import axios from 'axios';

const VideoCreator = () => {
  const { user, refreshUser } = useAuth();
  const [templates, setTemplates] = useState([]);
  const [selectedTemplate, setSelectedTemplate] = useState('');
  const [topic, setTopic] = useState('');
  const [style, setStyle] = useState('luxury');
  const [duration, setDuration] = useState(4);
  const [generating, setGenerating] = useState(false);
  const [result, setResult] = useState(null);
  const [projectId, setProjectId] = useState(null);
  const [progress, setProgress] = useState(0);
  const [statusMessage, setStatusMessage] = useState('');
  const pollingRef = useRef(null);

  const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
  const API = `${BACKEND_URL}/api`;

  useEffect(() => {
    fetchTemplates();
  }, []);

  const fetchTemplates = async () => {
    try {
      const response = await axios.get(`${API}/templates?type=video`);
      setTemplates(response.data);
      if (response.data.length > 0) {
        setSelectedTemplate(response.data[0].id);
      }
    } catch (error) {
      console.error('Failed to fetch templates:', error);
    }
  };

  const handleGenerate = async () => {
    if (!topic.trim()) {
      toast.error('Please enter a topic');
      return;
    }

    setGenerating(true);
    setResult(null);
    setProgress(0);
    setStatusMessage('Starting video generation...');

    try {
      const response = await axios.post(`${API}/video/generate`, {
        user_id: user.id,
        template: selectedTemplate,
        topic,
        style,
        duration
      });

      const { project_id } = response.data;
      setProjectId(project_id);
      toast.info('Video generation started! This may take several minutes...');
      
      // Start polling for project status
      startPolling(project_id);
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Video generation failed');
      setGenerating(false);
    }
  };

  const startPolling = (projectId) => {
    // Clear any existing polling
    if (pollingRef.current) {
      clearInterval(pollingRef.current);
    }

    let pollCount = 0;
    const maxPolls = 180; // 15 minutes max (every 5 seconds)

    pollingRef.current = setInterval(async () => {
      pollCount++;
      
      try {
        const response = await axios.get(`${API}/projects/${projectId}`);
        const project = response.data;
        
        setProgress(project.progress || 0);
        
        if (project.status === 'completed' && project.output_base64) {
          clearInterval(pollingRef.current);
          setResult({ video_base64: project.output_base64 });
          setGenerating(false);
          setStatusMessage('Video generated successfully!');
          toast.success('Video generated successfully!');
          refreshUser();
        } else if (project.status === 'failed') {
          clearInterval(pollingRef.current);
          setGenerating(false);
          setStatusMessage('Video generation failed');
          toast.error('Video generation failed. Please try again.');
        } else {
          // Still generating
          const estimatedTime = Math.max(0, Math.ceil((100 - project.progress) / 10));
          setStatusMessage(`Generating... ${project.progress || 0}% complete. Est. ${estimatedTime} min remaining`);
        }
      } catch (error) {
        console.error('Polling error:', error);
      }

      // Stop polling after max attempts
      if (pollCount >= maxPolls) {
        clearInterval(pollingRef.current);
        setGenerating(false);
        setStatusMessage('Generation timed out. Check Projects page for results.');
        toast.warning('Video generation is taking longer than expected. Check the Projects page for your video.');
      }
    }, 5000); // Poll every 5 seconds
  };

  // Cleanup polling on unmount
  useEffect(() => {
    return () => {
      if (pollingRef.current) {
        clearInterval(pollingRef.current);
      }
    };
  }, []);

  const handleDownload = () => {
    if (result?.video_base64) {
      const link = document.createElement('a');
      link.href = `data:video/mp4;base64,${result.video_base64}`;
      link.download = `video-${Date.now()}.mp4`;
      link.click();
      toast.success('Download started!');
    }
  };

  const selectedTemplateData = templates.find(t => t.id === selectedTemplate);

  return (
    <div className="p-8 max-w-6xl mx-auto fade-in">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
          <Video className="text-primary" />
          Video Creator
        </h1>
        <p className="text-muted-foreground">Create stunning YouTube videos with AI</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="glass-panel p-6">
          <h2 className="text-xl font-semibold mb-4">Configuration</h2>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Template</label>
              <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                <SelectTrigger data-testid="template-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {templates.map((template) => (
                    <SelectItem key={template.id} value={template.id}>
                      {template.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {selectedTemplateData && (
                <p className="text-xs text-muted-foreground mt-2">{selectedTemplateData.description}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Topic</label>
              <Input
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="e.g., AI in healthcare, Future of technology..."
                data-testid="topic-input"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Style</label>
              <Select value={style} onValueChange={setStyle}>
                <SelectTrigger data-testid="style-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="luxury">Cinematic Luxury</SelectItem>
                  <SelectItem value="motivational">Motivational</SelectItem>
                  <SelectItem value="tech">Tech & Modern</SelectItem>
                  <SelectItem value="minimal">Minimal & Clean</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Duration: {duration}s</label>
              <Select value={duration.toString()} onValueChange={(v) => setDuration(parseInt(v))}>
                <SelectTrigger data-testid="duration-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="4">4 seconds (Quick)</SelectItem>
                  <SelectItem value="8">8 seconds (Standard)</SelectItem>
                  <SelectItem value="12">12 seconds (Max)</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground mt-1">Sora-2 supports 4-12 second clips. Generation takes 2-5 minutes.</p>
            </div>

            <div className="pt-4">
              <Button
                onClick={handleGenerate}
                disabled={generating || !topic.trim()}
                data-testid="generate-video-button"
                className="w-full btn-primary"
              >
                {generating ? (
                  <span className="flex items-center gap-2">
                    <Loader2 size={18} className="animate-spin" />
                    Generating... ({progress}%)
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    <Play size={18} />
                    Generate Video
                  </span>
                )}
              </Button>
              
              {/* Progress indicator */}
              {generating && (
                <div className="mt-4 space-y-2">
                  <div className="w-full bg-background/50 rounded-full h-2">
                    <div 
                      className="bg-primary h-2 rounded-full transition-all duration-500"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                  <p className="text-xs text-muted-foreground text-center">{statusMessage}</p>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="glass-panel p-6">
          <h2 className="text-xl font-semibold mb-4">Preview</h2>

          {result && result.video_base64 ? (
            <div className="space-y-4" data-testid="video-result">
              <div className="flex items-center gap-2 text-green-500 mb-2">
                <CheckCircle2 size={20} />
                <span className="font-semibold">Video Ready!</span>
              </div>
              <div className="aspect-video bg-black rounded-lg overflow-hidden">
                <video
                  controls
                  autoPlay
                  className="w-full h-full"
                  src={`data:video/mp4;base64,${result.video_base64}`}
                  data-testid="video-player"
                >
                  Your browser does not support the video tag.
                </video>
              </div>
              <Button
                onClick={handleDownload}
                data-testid="download-video-button"
                className="w-full btn-secondary"
              >
                <Download size={18} className="mr-2" />
                Download Video
              </Button>
            </div>
          ) : generating ? (
            <div className="aspect-video bg-gradient-to-br from-primary/10 to-accent/10 rounded-lg flex items-center justify-center border-2 border-dashed border-border">
              <div className="text-center">
                <Loader2 size={64} className="mx-auto mb-4 text-primary animate-spin" />
                <p className="text-primary font-semibold">Generating your video...</p>
                <p className="text-muted-foreground text-sm mt-2">{statusMessage}</p>
              </div>
            </div>
          ) : (
            <div className="aspect-video bg-gradient-to-br from-primary/10 to-accent/10 rounded-lg flex items-center justify-center border-2 border-dashed border-border" data-testid="video-placeholder">
              <div className="text-center">
                <Video size={64} className="mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground">Your video will appear here</p>
                <p className="text-xs text-muted-foreground mt-2">Enter a topic and click Generate</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default VideoCreator;