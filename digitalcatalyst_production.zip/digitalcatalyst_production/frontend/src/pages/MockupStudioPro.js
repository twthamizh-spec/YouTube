import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { toast } from 'sonner';
import {
  Upload, Image as ImageIcon, Shirt, Package, Monitor, Coffee,
  Download, Save, Trash2, RotateCw, ZoomIn, ZoomOut, Move,
  Sun, Moon, Camera, User, Users, Layers, Sparkles, Loader2,
  FlipHorizontal, FlipVertical, Palette, Sliders, Eye, RefreshCw,
  Square, Circle, Triangle, Maximize, Grid, Check, X, Plus
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const MockupStudioPro = () => {
  const { user } = useAuth();
  const canvasRef = useRef(null);
  const productInputRef = useRef(null);
  
  // ===== PRODUCT STATE =====
  const [productImage, setProductImage] = useState(null);
  const [productPreview, setProductPreview] = useState(null);
  const [productPosition, setProductPosition] = useState({ x: 0, y: 0 });
  const [productScale, setProductScale] = useState(100);
  const [productRotation, setProductRotation] = useState(0);
  
  // ===== MOCKUP SETTINGS =====
  const [productType, setProductType] = useState('tshirt');
  const [modelType, setModelType] = useState('male');
  const [environment, setEnvironment] = useState('studio');
  const [lighting, setLighting] = useState('soft');
  const [pose, setPose] = useState('front');
  
  // ===== GENERATION STATE =====
  const [generationMode, setGenerationMode] = useState('upload'); // upload, text, hybrid
  const [textPrompt, setTextPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedMockup, setGeneratedMockup] = useState(null);
  const [generationProgress, setGenerationProgress] = useState(0);
  
  // ===== EDITING STATE =====
  const [brightness, setBrightness] = useState(100);
  const [contrast, setContrast] = useState(100);
  const [saturation, setSaturation] = useState(100);
  const [blur, setBlur] = useState(0);
  const [shadowIntensity, setShadowIntensity] = useState(50);
  
  // ===== PRODUCT TYPES =====
  const productTypes = [
    { id: 'tshirt', name: 'T-Shirt', icon: Shirt },
    { id: 'hoodie', name: 'Hoodie', icon: Shirt },
    { id: 'bottle', name: 'Bottle', icon: Coffee },
    { id: 'poster', name: 'Poster', icon: Square },
    { id: 'device', name: 'Device', icon: Monitor },
    { id: 'packaging', name: 'Packaging', icon: Package }
  ];
  
  // ===== MODEL TYPES =====
  const modelTypes = [
    { id: 'male', name: 'Male Model' },
    { id: 'female', name: 'Female Model' },
    { id: 'flatlay', name: 'Flat Lay' },
    { id: 'hanger', name: 'On Hanger' },
    { id: 'ghost', name: 'Ghost Mannequin' },
    { id: 'none', name: 'No Model' }
  ];
  
  // ===== ENVIRONMENTS =====
  const environments = [
    { id: 'studio', name: 'Studio' },
    { id: 'street', name: 'Street' },
    { id: 'lifestyle', name: 'Lifestyle' },
    { id: 'desk', name: 'Desk/Office' },
    { id: 'outdoor', name: 'Outdoor' },
    { id: 'minimal', name: 'Minimal White' }
  ];
  
  // ===== LIGHTING OPTIONS =====
  const lightingOptions = [
    { id: 'soft', name: 'Soft Light' },
    { id: 'hard', name: 'Hard Light' },
    { id: 'cinematic', name: 'Cinematic' },
    { id: 'natural', name: 'Natural' },
    { id: 'golden', name: 'Golden Hour' },
    { id: 'dramatic', name: 'Dramatic' }
  ];
  
  // ===== POSES =====
  const poses = [
    { id: 'front', name: 'Front View' },
    { id: 'side', name: 'Side View' },
    { id: 'back', name: 'Back View' },
    { id: 'angle', name: '3/4 Angle' },
    { id: 'dynamic', name: 'Dynamic Pose' },
    { id: 'casual', name: 'Casual Pose' }
  ];

  // ===== HANDLE PRODUCT UPLOAD =====
  const handleProductUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    if (!file.type.startsWith('image/')) {
      toast.error('Please upload an image file (PNG, JPG)');
      return;
    }
    
    const reader = new FileReader();
    reader.onload = (event) => {
      setProductImage(file);
      setProductPreview(event.target.result);
      toast.success('Product image uploaded! Ready for mockup generation.');
    };
    reader.readAsDataURL(file);
  };

  // ===== REMOVE PRODUCT =====
  const removeProduct = () => {
    setProductImage(null);
    setProductPreview(null);
    setProductPosition({ x: 0, y: 0 });
    setProductScale(100);
    setProductRotation(0);
    if (productInputRef.current) {
      productInputRef.current.value = '';
    }
  };

  // ===== BUILD MOCKUP PROMPT =====
  const buildMockupPrompt = () => {
    const productName = productTypes.find(p => p.id === productType)?.name || 'product';
    const modelName = modelTypes.find(m => m.id === modelType)?.name || '';
    const envName = environments.find(e => e.id === environment)?.name || '';
    const lightName = lightingOptions.find(l => l.id === lighting)?.name || '';
    const poseName = poses.find(p => p.id === pose)?.name || '';
    
    let prompt = `Professional product mockup photography. `;
    
    if (productType === 'tshirt' || productType === 'hoodie') {
      if (modelType === 'flatlay') {
        prompt += `${productName} laid flat on ${envName.toLowerCase()} background, top-down view. `;
      } else if (modelType === 'hanger') {
        prompt += `${productName} on a hanger, ${envName.toLowerCase()} setting. `;
      } else if (modelType === 'ghost') {
        prompt += `${productName} on ghost mannequin, professional product shot. `;
      } else if (modelType !== 'none') {
        prompt += `${modelName} wearing a ${productName}, ${poseName.toLowerCase()}, ${envName.toLowerCase()} setting. `;
      } else {
        prompt += `${productName} product shot, ${envName.toLowerCase()} background. `;
      }
    } else if (productType === 'bottle') {
      prompt += `${productName} product photography, ${envName.toLowerCase()} setting, ${poseName.toLowerCase()}. `;
    } else if (productType === 'poster') {
      prompt += `Poster/print mockup in ${envName.toLowerCase()} setting, ${poseName.toLowerCase()} angle. `;
    } else if (productType === 'device') {
      prompt += `Device/tech product mockup, ${envName.toLowerCase()} setting, clean and modern. `;
    } else if (productType === 'packaging') {
      prompt += `Product packaging mockup, ${envName.toLowerCase()} setting, commercial photography. `;
    }
    
    prompt += `${lightName} lighting. High-resolution, photorealistic, commercial quality, sharp focus. `;
    
    if (textPrompt.trim()) {
      prompt += textPrompt + '. ';
    }
    
    // Add design placement instruction if product is uploaded
    if (productPreview && (productType === 'tshirt' || productType === 'hoodie')) {
      prompt += `The ${productName} should have a clear, centered area for design placement on the chest. `;
    }
    
    return prompt;
  };

  // ===== GENERATE MOCKUP =====
  const generateMockup = async () => {
    if (generationMode === 'upload' && !productPreview) {
      toast.error('Please upload a product image first');
      return;
    }
    
    if (generationMode === 'text' && !textPrompt.trim()) {
      toast.error('Please enter a description for text-based generation');
      return;
    }
    
    setIsGenerating(true);
    setGenerationProgress(10);
    toast.info('🎨 Generating professional mockup...');
    
    try {
      const prompt = buildMockupPrompt();
      setGenerationProgress(30);
      
      const response = await fetch(`${BACKEND_URL}/api/generate/image`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: prompt,
          style: 'product',
          aspect_ratio: productType === 'poster' ? '3:2' : '1:1'
        })
      });
      
      setGenerationProgress(70);
      
      if (!response.ok) {
        throw new Error('Mockup generation failed');
      }
      
      const data = await response.json();
      
      if (data.success && data.image_base64) {
        setGenerationProgress(90);
        setGeneratedMockup(data.image_base64);
        setGenerationProgress(100);
        toast.success('✨ Professional mockup generated!');
      } else {
        throw new Error('No image data received');
      }
    } catch (error) {
      console.error('Mockup generation error:', error);
      toast.error(`Generation failed: ${error.message}`);
    } finally {
      setIsGenerating(false);
      setGenerationProgress(0);
    }
  };

  // ===== COMPOSITE PRODUCT ONTO MOCKUP =====
  const compositeProductOnMockup = useCallback(() => {
    if (!generatedMockup || !productPreview) return null;
    
    const canvas = canvasRef.current;
    if (!canvas) return null;
    
    const ctx = canvas.getContext('2d');
    const mockupImg = new Image();
    const productImg = new Image();
    
    return new Promise((resolve) => {
      mockupImg.onload = () => {
        canvas.width = mockupImg.width;
        canvas.height = mockupImg.height;
        
        // Apply filters
        ctx.filter = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%) blur(${blur}px)`;
        
        // Draw mockup base
        ctx.drawImage(mockupImg, 0, 0);
        
        // Reset filter for product
        ctx.filter = 'none';
        
        productImg.onload = () => {
          ctx.save();
          
          // Calculate product placement (center of mockup with offset)
          const centerX = canvas.width / 2 + productPosition.x;
          const centerY = canvas.height / 2 + productPosition.y - (canvas.height * 0.1); // Slightly above center for shirt
          
          // Calculate scaled size
          const scaleFactor = productScale / 100;
          const productWidth = canvas.width * 0.3 * scaleFactor;
          const productHeight = (productImg.height / productImg.width) * productWidth;
          
          // Apply transformations
          ctx.translate(centerX, centerY);
          ctx.rotate((productRotation * Math.PI) / 180);
          
          // Apply shadow for realism
          ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
          ctx.shadowBlur = shadowIntensity / 5;
          ctx.shadowOffsetX = 2;
          ctx.shadowOffsetY = 2;
          
          // Draw product
          ctx.drawImage(
            productImg,
            -productWidth / 2,
            -productHeight / 2,
            productWidth,
            productHeight
          );
          
          ctx.restore();
          resolve(canvas.toDataURL('image/png'));
        };
        productImg.src = productPreview;
      };
      mockupImg.src = `data:image/png;base64,${generatedMockup}`;
    });
  }, [generatedMockup, productPreview, productPosition, productScale, productRotation, brightness, contrast, saturation, blur, shadowIntensity]);

  // ===== RENDER CANVAS =====
  useEffect(() => {
    if (generatedMockup) {
      const canvas = canvasRef.current;
      if (!canvas) return;
      
      const ctx = canvas.getContext('2d');
      const img = new Image();
      
      img.onload = () => {
        canvas.width = img.width;
        canvas.height = img.height;
        
        // Apply filters
        ctx.filter = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%) blur(${blur}px)`;
        ctx.drawImage(img, 0, 0);
        ctx.filter = 'none';
        
        // If product is uploaded, composite it
        if (productPreview) {
          const productImg = new Image();
          productImg.onload = () => {
            ctx.save();
            
            const centerX = canvas.width / 2 + productPosition.x;
            const centerY = canvas.height / 2 + productPosition.y - (canvas.height * 0.1);
            
            const scaleFactor = productScale / 100;
            const productWidth = canvas.width * 0.3 * scaleFactor;
            const productHeight = (productImg.height / productImg.width) * productWidth;
            
            ctx.translate(centerX, centerY);
            ctx.rotate((productRotation * Math.PI) / 180);
            ctx.globalAlpha = 0.95;
            
            ctx.shadowColor = 'rgba(0, 0, 0, 0.2)';
            ctx.shadowBlur = shadowIntensity / 5;
            ctx.shadowOffsetX = 1;
            ctx.shadowOffsetY = 1;
            
            ctx.drawImage(
              productImg,
              -productWidth / 2,
              -productHeight / 2,
              productWidth,
              productHeight
            );
            
            ctx.restore();
          };
          productImg.src = productPreview;
        }
      };
      img.src = `data:image/png;base64,${generatedMockup}`;
    }
  }, [generatedMockup, productPreview, productPosition, productScale, productRotation, brightness, contrast, saturation, blur, shadowIntensity]);

  // ===== EXPORT =====
  const exportMockup = async () => {
    if (!generatedMockup) {
      toast.error('Generate a mockup first');
      return;
    }
    
    let dataUrl;
    if (productPreview) {
      dataUrl = await compositeProductOnMockup();
    } else {
      const canvas = canvasRef.current;
      dataUrl = canvas?.toDataURL('image/png');
    }
    
    if (dataUrl) {
      const link = document.createElement('a');
      link.download = `mockup-${productType}-${Date.now()}.png`;
      link.href = dataUrl;
      link.click();
      toast.success('Mockup exported!');
    }
  };

  // ===== SAVE TO PROJECTS =====
  const saveToProjects = async () => {
    if (!generatedMockup) {
      toast.error('Generate a mockup first');
      return;
    }
    
    try {
      const response = await fetch(`${BACKEND_URL}/api/projects`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: user?.id,
          type: 'mockup',
          status: 'completed',
          metadata: {
            productType,
            modelType,
            environment,
            lighting,
            pose,
            prompt: buildMockupPrompt(),
            hasUploadedProduct: !!productPreview
          }
        })
      });
      
      if (response.ok) {
        toast.success('Saved to Projects!');
      }
    } catch (error) {
      toast.error('Failed to save');
    }
  };

  return (
    <div className="h-screen flex flex-col bg-background overflow-hidden">
      {/* Header */}
      <div className="h-14 border-b border-border flex items-center justify-between px-6 bg-card/50 backdrop-blur">
        <div className="flex items-center gap-3">
          <Package className="w-6 h-6 text-accent" />
          <span className="font-bold text-lg">PROFESSIONAL MOCKUP STUDIO</span>
        </div>
        <div className="flex items-center gap-2">
          <Button size="sm" variant="outline" onClick={saveToProjects} disabled={!generatedMockup}>
            <Save className="w-4 h-4 mr-2" /> Save
          </Button>
          <Button size="sm" onClick={exportMockup} disabled={!generatedMockup} className="bg-accent hover:bg-accent/80">
            <Download className="w-4 h-4 mr-2" /> Export PNG
          </Button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Left Panel - Controls */}
        <div className="w-80 border-r border-border flex flex-col bg-card/30 overflow-y-auto">
          <Tabs defaultValue="product" className="w-full">
            <TabsList className="w-full rounded-none border-b border-border h-12 bg-transparent grid grid-cols-3">
              <TabsTrigger value="product" className="data-[state=active]:bg-accent/20">
                <Upload className="w-4 h-4 mr-1" /> Product
              </TabsTrigger>
              <TabsTrigger value="scene" className="data-[state=active]:bg-accent/20">
                <Camera className="w-4 h-4 mr-1" /> Scene
              </TabsTrigger>
              <TabsTrigger value="edit" className="data-[state=active]:bg-accent/20">
                <Sliders className="w-4 h-4 mr-1" /> Edit
              </TabsTrigger>
            </TabsList>

            {/* PRODUCT TAB */}
            <TabsContent value="product" className="p-4 space-y-4 mt-0">
              {/* Product Upload */}
              <div className="space-y-2">
                <label className="text-sm font-semibold flex items-center gap-2">
                  <Upload className="w-4 h-4 text-accent" /> Upload Product Design
                </label>
                <input
                  ref={productInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/jpg"
                  onChange={handleProductUpload}
                  className="hidden"
                />
                {productPreview ? (
                  <div className="relative bg-background/50 rounded-lg p-4">
                    <img 
                      src={productPreview} 
                      alt="Product" 
                      className="w-full h-40 object-contain rounded"
                    />
                    <button
                      onClick={removeProduct}
                      className="absolute top-2 right-2 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center hover:bg-red-600"
                    >
                      <X className="w-4 h-4" />
                    </button>
                    <p className="text-xs text-green-400 mt-2 text-center">✓ Product ready for mockup</p>
                  </div>
                ) : (
                  <button
                    onClick={() => productInputRef.current?.click()}
                    className="w-full h-32 border-2 border-dashed border-accent/50 rounded-lg flex flex-col items-center justify-center hover:border-accent transition-colors bg-accent/5"
                  >
                    <Upload className="w-8 h-8 text-accent mb-2" />
                    <span className="text-sm font-medium">Click to upload</span>
                    <span className="text-xs text-muted-foreground">PNG or JPG (transparent preferred)</span>
                  </button>
                )}
              </div>

              {/* Product Type */}
              <div className="space-y-2">
                <label className="text-sm font-semibold">Product Type</label>
                <div className="grid grid-cols-3 gap-2">
                  {productTypes.map(type => {
                    const Icon = type.icon;
                    return (
                      <button
                        key={type.id}
                        onClick={() => setProductType(type.id)}
                        className={`p-3 rounded-lg border flex flex-col items-center gap-1 transition-all ${
                          productType === type.id
                            ? 'border-accent bg-accent/20'
                            : 'border-border hover:border-accent/50'
                        }`}
                      >
                        <Icon className="w-5 h-5" />
                        <span className="text-xs">{type.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Generation Mode */}
              <div className="space-y-2">
                <label className="text-sm font-semibold">Generation Mode</label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => setGenerationMode('upload')}
                    className={`p-2 rounded-lg border text-xs ${
                      generationMode === 'upload' ? 'border-accent bg-accent/20' : 'border-border'
                    }`}
                  >
                    Upload+Scene
                  </button>
                  <button
                    onClick={() => setGenerationMode('text')}
                    className={`p-2 rounded-lg border text-xs ${
                      generationMode === 'text' ? 'border-accent bg-accent/20' : 'border-border'
                    }`}
                  >
                    Text Only
                  </button>
                  <button
                    onClick={() => setGenerationMode('hybrid')}
                    className={`p-2 rounded-lg border text-xs ${
                      generationMode === 'hybrid' ? 'border-accent bg-accent/20' : 'border-border'
                    }`}
                  >
                    Hybrid
                  </button>
                </div>
              </div>

              {/* Text Prompt */}
              <div className="space-y-2">
                <label className="text-sm font-semibold">Additional Details</label>
                <textarea
                  value={textPrompt}
                  onChange={(e) => setTextPrompt(e.target.value)}
                  placeholder="Add specific details: colors, branding, style..."
                  className="w-full h-20 p-3 rounded-lg bg-background border border-border resize-none text-sm"
                />
              </div>

              {/* Product Position (when product uploaded) */}
              {productPreview && generatedMockup && (
                <div className="space-y-3 p-3 rounded-lg bg-background/50 border border-border">
                  <label className="text-sm font-semibold">Product Placement</label>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs">X Position</span>
                      <span className="text-xs">{productPosition.x}px</span>
                    </div>
                    <Slider
                      value={[productPosition.x]}
                      onValueChange={([v]) => setProductPosition(p => ({ ...p, x: v }))}
                      min={-200}
                      max={200}
                    />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs">Y Position</span>
                      <span className="text-xs">{productPosition.y}px</span>
                    </div>
                    <Slider
                      value={[productPosition.y]}
                      onValueChange={([v]) => setProductPosition(p => ({ ...p, y: v }))}
                      min={-200}
                      max={200}
                    />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs">Scale</span>
                      <span className="text-xs">{productScale}%</span>
                    </div>
                    <Slider
                      value={[productScale]}
                      onValueChange={([v]) => setProductScale(v)}
                      min={20}
                      max={200}
                    />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs">Rotation</span>
                      <span className="text-xs">{productRotation}°</span>
                    </div>
                    <Slider
                      value={[productRotation]}
                      onValueChange={([v]) => setProductRotation(v)}
                      min={-180}
                      max={180}
                    />
                  </div>
                </div>
              )}
            </TabsContent>

            {/* SCENE TAB */}
            <TabsContent value="scene" className="p-4 space-y-4 mt-0">
              {/* Model Type */}
              <div className="space-y-2">
                <label className="text-sm font-semibold flex items-center gap-2">
                  <User className="w-4 h-4" /> Model Type
                </label>
                <Select value={modelType} onValueChange={setModelType}>
                  <SelectTrigger className="bg-background">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {modelTypes.map(m => (
                      <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Pose */}
              <div className="space-y-2">
                <label className="text-sm font-semibold">Pose / Angle</label>
                <div className="grid grid-cols-3 gap-2">
                  {poses.map(p => (
                    <button
                      key={p.id}
                      onClick={() => setPose(p.id)}
                      className={`p-2 rounded-lg border text-xs transition-all ${
                        pose === p.id ? 'border-accent bg-accent/20' : 'border-border hover:border-accent/50'
                      }`}
                    >
                      {p.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Environment */}
              <div className="space-y-2">
                <label className="text-sm font-semibold flex items-center gap-2">
                  <Camera className="w-4 h-4" /> Environment
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {environments.map(env => (
                    <button
                      key={env.id}
                      onClick={() => setEnvironment(env.id)}
                      className={`p-2 rounded-lg border text-xs transition-all ${
                        environment === env.id ? 'border-accent bg-accent/20' : 'border-border hover:border-accent/50'
                      }`}
                    >
                      {env.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Lighting */}
              <div className="space-y-2">
                <label className="text-sm font-semibold flex items-center gap-2">
                  <Sun className="w-4 h-4" /> Lighting
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {lightingOptions.map(l => (
                    <button
                      key={l.id}
                      onClick={() => setLighting(l.id)}
                      className={`p-2 rounded-lg border text-xs transition-all ${
                        lighting === l.id ? 'border-accent bg-accent/20' : 'border-border hover:border-accent/50'
                      }`}
                    >
                      {l.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Shadow Intensity */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-semibold">Shadow Intensity</label>
                  <span className="text-xs">{shadowIntensity}%</span>
                </div>
                <Slider
                  value={[shadowIntensity]}
                  onValueChange={([v]) => setShadowIntensity(v)}
                  min={0}
                  max={100}
                />
              </div>
            </TabsContent>

            {/* EDIT TAB */}
            <TabsContent value="edit" className="p-4 space-y-4 mt-0">
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-sm">Brightness</label>
                    <span className="text-xs">{brightness}%</span>
                  </div>
                  <Slider
                    value={[brightness]}
                    onValueChange={([v]) => setBrightness(v)}
                    min={50}
                    max={150}
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-sm">Contrast</label>
                    <span className="text-xs">{contrast}%</span>
                  </div>
                  <Slider
                    value={[contrast]}
                    onValueChange={([v]) => setContrast(v)}
                    min={50}
                    max={150}
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-sm">Saturation</label>
                    <span className="text-xs">{saturation}%</span>
                  </div>
                  <Slider
                    value={[saturation]}
                    onValueChange={([v]) => setSaturation(v)}
                    min={0}
                    max={200}
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-sm">Blur</label>
                    <span className="text-xs">{blur}px</span>
                  </div>
                  <Slider
                    value={[blur]}
                    onValueChange={([v]) => setBlur(v)}
                    min={0}
                    max={10}
                  />
                </div>
              </div>

              {/* Quick Actions */}
              <div className="space-y-2 pt-4 border-t border-border">
                <label className="text-sm font-semibold">Quick Actions</label>
                <div className="flex gap-2 flex-wrap">
                  <Button size="sm" variant="outline" onClick={() => {
                    setBrightness(100);
                    setContrast(100);
                    setSaturation(100);
                    setBlur(0);
                  }}>
                    <RefreshCw className="w-3 h-3 mr-1" /> Reset
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => {
                    setBrightness(110);
                    setContrast(110);
                    setSaturation(90);
                  }}>
                    <Sun className="w-3 h-3 mr-1" /> Enhance
                  </Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>

          {/* Generate Button */}
          <div className="p-4 border-t border-border mt-auto">
            <Button
              onClick={generateMockup}
              disabled={isGenerating || (generationMode === 'upload' && !productPreview && !textPrompt)}
              className="w-full h-12 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Generating ({generationProgress}%)
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 mr-2" />
                  Generate Mockup
                </>
              )}
            </Button>
            {generationMode === 'upload' && !productPreview && (
              <p className="text-xs text-muted-foreground text-center mt-2">
                Upload a product image to enable generation
              </p>
            )}
          </div>
        </div>

        {/* Main Preview Area */}
        <div className="flex-1 flex items-center justify-center bg-[#0a0a0f] p-8 overflow-auto">
          {generatedMockup ? (
            <div className="relative max-w-4xl max-h-full">
              <canvas
                ref={canvasRef}
                className="max-w-full max-h-full rounded-lg shadow-2xl"
              />
              <div className="absolute bottom-4 right-4 flex gap-2">
                <Button size="sm" variant="secondary" onClick={generateMockup}>
                  <RefreshCw className="w-4 h-4 mr-1" /> Regenerate
                </Button>
              </div>
            </div>
          ) : (
            <div className="text-center">
              <Package className="w-24 h-24 mx-auto mb-6 text-muted-foreground opacity-30" />
              <h3 className="text-xl font-semibold mb-2">Professional Mockup Studio</h3>
              <p className="text-muted-foreground mb-4">
                Upload your product design and generate realistic mockups
              </p>
              <div className="flex flex-col gap-2 text-sm text-muted-foreground">
                <div className="flex items-center gap-2 justify-center">
                  <Check className="w-4 h-4 text-green-500" /> Upload PNG/JPG designs
                </div>
                <div className="flex items-center gap-2 justify-center">
                  <Check className="w-4 h-4 text-green-500" /> AI-powered scene composition
                </div>
                <div className="flex items-center gap-2 justify-center">
                  <Check className="w-4 h-4 text-green-500" /> Multiple product types & models
                </div>
                <div className="flex items-center gap-2 justify-center">
                  <Check className="w-4 h-4 text-green-500" /> Export high-resolution images
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MockupStudioPro;
