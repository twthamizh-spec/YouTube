import React, { useState, useEffect } from 'react';
import { X, Sparkles, Video, Image, Mic, ArrowRight, Check } from 'lucide-react';
import { Button } from '../components/ui/button';
import axios from 'axios';
import { useAuth } from '../contexts/AuthContext';

const Onboarding = ({ onComplete }) => {
  const { user } = useAuth();
  const [step, setStep] = useState(1);
  const [preferences, setPreferences] = useState({
    primaryUse: '',
    contentType: [],
    experience: ''
  });

  const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
  const API = `${BACKEND_URL}/api`;

  const steps = [
    {
      title: "Welcome to CreatorAI",
      description: "Let's personalize your experience in 3 quick steps",
      icon: Sparkles
    },
    {
      title: "What's your primary use case?",
      description: "This helps us customize templates for you",
      options: [
        { value: 'social_media', label: 'Social Media Content', icon: Video },
        { value: 'ecommerce', label: 'eCommerce & Products', icon: Image },
        { value: 'marketing', label: 'Marketing Campaigns', icon: Sparkles },
        { value: 'personal', label: 'Personal Projects', icon: Mic }
      ]
    },
    {
      title: "What content do you create most?",
      description: "Select all that apply",
      multiple: true,
      options: [
        { value: 'videos', label: 'Videos', icon: Video },
        { value: 'images', label: 'Images & Mockups', icon: Image },
        { value: 'voiceovers', label: 'Voiceovers', icon: Mic }
      ]
    },
    {
      title: "Your experience level?",
      description: "We'll adjust our recommendations",
      options: [
        { value: 'beginner', label: 'Beginner', desc: 'New to AI content creation' },
        { value: 'intermediate', label: 'Intermediate', desc: 'Some experience with tools' },
        { value: 'advanced', label: 'Advanced', desc: 'Professional creator' }
      ]
    }
  ];

  const handleComplete = async () => {
    try {
      await axios.put(`${API}/users/${user.id}/preferences`, preferences);
      await axios.put(`${API}/users/${user.id}/onboarding`);
      onComplete();
    } catch (error) {
      console.error('Failed to save preferences:', error);
    }
  };

  const handleNext = () => {
    if (step < steps.length) {
      setStep(step + 1);
    } else {
      handleComplete();
    }
  };

  const handleSelect = (field, value) => {
    if (field === 'contentType') {
      const current = preferences.contentType || [];
      if (current.includes(value)) {
        setPreferences({ ...preferences, contentType: current.filter(v => v !== value) });
      } else {
        setPreferences({ ...preferences, contentType: [...current, value] });
      }
    } else {
      setPreferences({ ...preferences, [field]: value });
    }
  };

  const currentStep = steps[step - 1];
  const Icon = currentStep?.icon;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-6">
      <div className="glass-panel max-w-2xl w-full p-8 fade-in" data-testid="onboarding-modal">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-2">
            {Array.from({ length: steps.length }).map((_, i) => (
              <div
                key={i}
                className={`h-2 w-12 rounded-full transition-all ${
                  i + 1 <= step ? 'bg-primary' : 'bg-white/10'
                }`}
              />
            ))}
          </div>
          <button onClick={onComplete} className="text-muted-foreground hover:text-foreground">
            <X size={20} />
          </button>
        </div>

        <div className="text-center mb-8">
          {Icon && (
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br from-primary to-accent mb-4">
              <Icon size={32} className="text-white" />
            </div>
          )}
          <h2 className="text-3xl font-bold mb-2">{currentStep.title}</h2>
          <p className="text-muted-foreground">{currentStep.description}</p>
        </div>

        {currentStep.options && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
            {currentStep.options.map((option) => {
              const OptionIcon = option.icon;
              const isSelected = step === 2 ? preferences.primaryUse === option.value :
                               step === 3 ? preferences.contentType?.includes(option.value) :
                               preferences.experience === option.value;

              return (
                <button
                  key={option.value}
                  onClick={() => handleSelect(
                    step === 2 ? 'primaryUse' : step === 3 ? 'contentType' : 'experience',
                    option.value
                  )}
                  data-testid={`onboarding-option-${option.value}`}
                  className={`p-6 rounded-lg border-2 transition-all text-left ${
                    isSelected
                      ? 'border-primary bg-primary/10'
                      : 'border-border hover:border-primary/50'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    {OptionIcon && <OptionIcon size={24} className="text-primary" />}
                    <div className="flex-1">
                      <div className="font-semibold mb-1">{option.label}</div>
                      {option.desc && <div className="text-sm text-muted-foreground">{option.desc}</div>}
                    </div>
                    {isSelected && <Check size={20} className="text-primary" />}
                  </div>
                </button>
              );
            })}
          </div>
        )}

        <Button
          onClick={handleNext}
          disabled={step === 2 && !preferences.primaryUse || 
                   step === 3 && preferences.contentType?.length === 0 ||
                   step === 4 && !preferences.experience}
          data-testid="onboarding-next-button"
          className="w-full btn-primary"
        >
          <span className="flex items-center gap-2">
            {step === steps.length ? 'Get Started' : 'Continue'}
            <ArrowRight size={18} />
          </span>
        </Button>
      </div>
    </div>
  );
};

export default Onboarding;