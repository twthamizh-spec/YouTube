import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Video, Image, Mic, Palette, FolderOpen, Settings, Sparkles, BarChart3, Layers, Store, Scissors, TrendingUp, Target, Trophy, Zap, Brain } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const Sidebar = () => {
  const location = useLocation();
  const { user } = useAuth();

  const navItems = [
    { name: '🧠 UNIFIED STUDIO', path: '/unified-studio', icon: Brain, highlight: true },
    { name: 'Daily Actions', path: '/daily-actions', icon: Zap },
    { name: 'Dashboard', path: '/dashboard', icon: Sparkles },
    { name: 'Video Creator', path: '/video-creator', icon: Video },
    { name: 'Mockup Studio', path: '/mockup-studio', icon: Image },
    { name: 'Voiceover', path: '/voiceover', icon: Mic },
    { name: 'Creative Studio', path: '/creative-studio', icon: Scissors },
    { name: 'Templates', path: '/templates', icon: Store },
    { name: 'Batch Generate', path: '/batch-generation', icon: Layers },
    { name: 'Analytics', path: '/analytics', icon: BarChart3 },
    { name: 'Market Trends', path: '/market-trends', icon: TrendingUp },
    { name: 'YouTube Engine', path: '/youtube-engine', icon: Trophy },
    { name: 'Decision Center', path: '/decision-center', icon: Target },
    { name: 'Brand Kit', path: '/brand-kit', icon: Palette },
    { name: 'Projects', path: '/projects', icon: FolderOpen },
    { name: 'Settings', path: '/settings', icon: Settings },
  ];

  return (
    <div className="sidebar glass-panel p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
          DIGITAL CATALYZT
        </h1>
        <p className="text-xs text-muted-foreground mt-1">Autonomous AI Growth OS</p>
      </div>

      <nav className="space-y-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              data-testid={`nav-${item.name.toLowerCase().replace(' ', '-')}`}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-300 ${
                isActive
                  ? 'bg-primary text-primary-foreground shadow-[0_0_15px_-3px_hsl(var(--primary))]'
                  : item.highlight
                    ? 'text-accent bg-accent/10 border border-accent/30 hover:bg-accent/20'
                    : 'text-muted-foreground hover:bg-white/5 hover:text-foreground'
              }`}
            >
              <Icon size={20} />
              <span className="font-medium">{item.name}</span>
            </Link>
          );
        })}
      </nav>

      {user && (
        <div className="mt-8 p-4 rounded-lg bg-gradient-to-br from-primary/10 to-accent/10 border border-primary/20">
          <div className="flex flex-col items-center justify-center text-center py-2">
            <span className="text-xs text-muted-foreground mb-1">Private Mode</span>
            <span className="text-lg font-bold text-primary">UNLIMITED</span>
            <span className="text-xs text-accent mt-1">No Restrictions</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default Sidebar;