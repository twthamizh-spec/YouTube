import React, { useState } from 'react';
import '@/App.css';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { Toaster } from 'sonner';
import Sidebar from './components/Sidebar';
import Onboarding from './components/Onboarding';
import AuthPage from './pages/AuthPage';
import Dashboard from './pages/Dashboard';
import VideoCreator from './pages/VideoCreator';
import MockupStudio from './pages/MockupStudio';
import MockupStudioPro from './pages/MockupStudioPro';
import Voiceover from './pages/Voiceover';
import BrandKit from './pages/BrandKit';
import Projects from './pages/Projects';
import Settings from './pages/Settings';
import DailyActionView from './pages/DailyActionView';
import Analytics from './pages/Analytics';
import BatchGeneration from './pages/BatchGeneration';
import TemplateMarketplace from './pages/TemplateMarketplace';
import CreativeStudioPro from './pages/CreativeStudioPro';
import MarketTrendIntelligence from './pages/MarketTrendIntelligence';
import YouTubeSuperiorityEngine from './pages/YouTubeSuperiorityEngine';
import ExecutiveDecisionCenter from './pages/ExecutiveDecisionCenter';
import UnifiedCreativeStudio from './pages/UnifiedCreativeStudio';

const PrivateRoute = ({ children }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="loading-spinner w-12 h-12 border-4 border-primary/20 border-t-primary rounded-full" />
      </div>
    );
  }

  return user ? children : <Navigate to="/" replace />;
};

const AppContent = () => {
  const { user, loading } = useAuth();
  const [showOnboarding, setShowOnboarding] = useState(false);

  React.useEffect(() => {
    if (user && !user.onboarding_completed) {
      setShowOnboarding(true);
    }
  }, [user]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="loading-spinner w-12 h-12 border-4 border-primary/20 border-t-primary rounded-full" />
      </div>
    );
  }

  if (!user) {
    return <AuthPage />;
  }

  return (
    <>
      {showOnboarding && (
        <Onboarding onComplete={() => setShowOnboarding(false)} />
      )}
      <div className="App">
        <Sidebar />
        <div className="main-content">
          <Routes>
            <Route path="/dashboard" element={<PrivateRoute><Dashboard /></PrivateRoute>} />
            <Route path="/daily-actions" element={<PrivateRoute><DailyActionView /></PrivateRoute>} />
            <Route path="/unified-studio" element={<PrivateRoute><UnifiedCreativeStudio /></PrivateRoute>} />
            <Route path="/video-creator" element={<PrivateRoute><VideoCreator /></PrivateRoute>} />
            <Route path="/mockup-studio" element={<PrivateRoute><MockupStudioPro /></PrivateRoute>} />
            <Route path="/voiceover" element={<PrivateRoute><Voiceover /></PrivateRoute>} />
            <Route path="/creative-studio" element={<PrivateRoute><CreativeStudioPro /></PrivateRoute>} />
            <Route path="/brand-kit" element={<PrivateRoute><BrandKit /></PrivateRoute>} />
            <Route path="/projects" element={<PrivateRoute><Projects /></PrivateRoute>} />
            <Route path="/settings" element={<PrivateRoute><Settings /></PrivateRoute>} />
            <Route path="/analytics" element={<PrivateRoute><Analytics /></PrivateRoute>} />
            <Route path="/batch-generation" element={<PrivateRoute><BatchGeneration /></PrivateRoute>} />
            <Route path="/templates" element={<PrivateRoute><TemplateMarketplace /></PrivateRoute>} />
            <Route path="/market-trends" element={<PrivateRoute><MarketTrendIntelligence /></PrivateRoute>} />
            <Route path="/youtube-engine" element={<PrivateRoute><YouTubeSuperiorityEngine /></PrivateRoute>} />
            <Route path="/decision-center" element={<PrivateRoute><ExecutiveDecisionCenter /></PrivateRoute>} />
            <Route path="*" element={<Navigate to="/unified-studio" replace />} />
          </Routes>
        </div>
      </div>
    </>
  );
};

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppContent />
        <Toaster position="top-right" richColors />
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
