from fastapi import FastAPI, APIRouter, HTTPException, File, UploadFile, WebSocket, WebSocketDisconnect
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os, logging, uuid, base64, asyncio, json, subprocess, tempfile
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional, Dict, Any
from datetime import datetime, timezone
from openai import AsyncOpenAI

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

openai_client = AsyncOpenAI(api_key=os.environ['OPENAI_API_KEY'])

app = FastAPI()
api_router = APIRouter(prefix="/api")

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# ─── WebSocket Manager ───────────────────────────────────────────────────────
class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}

    async def connect(self, websocket: WebSocket, user_id: str):
        await websocket.accept()
        self.active_connections[user_id] = websocket

    def disconnect(self, user_id: str):
        self.active_connections.pop(user_id, None)

    async def send_progress(self, user_id: str, data: dict):
        if user_id in self.active_connections:
            try:
                await self.active_connections[user_id].send_json(data)
            except:
                self.disconnect(user_id)

manager = ConnectionManager()

# ─── Models ──────────────────────────────────────────────────────────────────
class User(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    email: str
    password: str
    brand_kit: Optional[Dict[str, Any]] = None
    onboarding_completed: bool = False
    preferences: Optional[Dict[str, Any]] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class UserCreate(BaseModel):
    email: str
    password: str

class UserLogin(BaseModel):
    email: str
    password: str

class UserResponse(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    email: str
    brand_kit: Optional[Dict[str, Any]] = None
    onboarding_completed: bool = False
    preferences: Optional[Dict[str, Any]] = None

class BrandKitUpdate(BaseModel):
    logo_url: Optional[str] = None
    colors: Optional[List[str]] = None
    fonts: Optional[List[str]] = None
    tone: Optional[str] = None

class Project(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    type: str
    title: str
    status: str = "pending"
    progress: int = 0
    output_url: Optional[str] = None
    output_base64: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    analytics: Optional[Dict[str, Any]] = None
    is_draft: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: Optional[datetime] = None

class VideoGenerateRequest(BaseModel):
    user_id: str
    template: str
    topic: Optional[str] = None
    style: Optional[str] = "luxury"
    duration: Optional[int] = 4
    variations: Optional[int] = 1

class ImageGenerateRequest(BaseModel):
    user_id: str
    template: str
    product_type: Optional[str] = "t-shirt"
    model_style: Optional[str] = "female"
    scene: Optional[str] = "studio"
    variations: Optional[int] = 1

class VoiceoverGenerateRequest(BaseModel):
    user_id: str
    text: str
    voice: Optional[str] = "alloy"
    model: Optional[str] = "tts-1"
    speed: Optional[float] = 1.0

class Template(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    type: str
    name: str
    description: str
    prompt_template: str
    config: Dict[str, Any]
    category: Optional[str] = "general"
    cost: int

# ─── Built-in Templates ───────────────────────────────────────────────────────
BUILT_IN_TEMPLATES = [
    {"id":"viral_short","type":"video","category":"social_media","name":"Viral YouTube Short","description":"45-60 second faceless cinematic YouTube Short","prompt_template":"Create a {duration}-second YouTube Short script about {topic}. Hook in first 2 seconds. Fast-paced. Style: {style}.","config":{"duration":4,"size":"720x1280"},"cost":0},
    {"id":"long_video","type":"video","category":"youtube","name":"Long YouTube Video","description":"8-12 minute structured YouTube video","prompt_template":"Generate a structured YouTube video script about {topic}. Include hook, 3 key points, examples, CTA. Style: {style}.","config":{"duration":8,"size":"1280x720"},"cost":0},
    {"id":"finance_short","type":"video","category":"finance","name":"Finance Short","description":"Finance/money tip for YouTube Shorts","prompt_template":"Write a 45-second YouTube Shorts script about {topic}. Finance/money advice angle. Hook + value + CTA. India context. Style: {style}.","config":{"duration":4,"size":"720x1280"},"cost":0},
    {"id":"motivation_short","type":"video","category":"motivation","name":"Motivation Short","description":"Motivational content for Shorts","prompt_template":"Write a 60-second motivational YouTube Shorts script about {topic}. Energetic. Inspiring. Personal growth angle. Style: {style}.","config":{"duration":4,"size":"720x1280"},"cost":0},
    {"id":"tshirt_mockup","type":"image","category":"apparel","name":"T-Shirt Mockup","description":"Photorealistic t-shirt mockup with model","prompt_template":"Professional product photography. {model_style} model wearing a {product_type}. Scene: {scene}. Studio lighting. High-quality, commercial photography style.","config":{"model":"dall-e-3","number_of_images":1},"cost":0},
    {"id":"hoodie_mockup","type":"image","category":"apparel","name":"Hoodie Mockup","description":"Photorealistic hoodie mockup","prompt_template":"Professional product photography. {model_style} model wearing a {product_type} hoodie. Scene: {scene}. Natural lighting. Commercial photography.","config":{"model":"dall-e-3","number_of_images":1},"cost":0},
    {"id":"social_ad","type":"image","category":"social_ads","name":"Social Media Ad","description":"Instagram/Facebook ad creative","prompt_template":"High-converting social media ad for {product_type}. Bold visuals. {scene} setting. Modern aesthetic. Professional commercial style.","config":{"model":"dall-e-3","number_of_images":1},"cost":0},
]

MUSIC_LIBRARY = [
    {"id":"cinematic_1","name":"Epic Cinematic","duration":120,"mood":"dramatic","url":"#"},
    {"id":"upbeat_1","name":"Upbeat Pop","duration":90,"mood":"energetic","url":"#"},
    {"id":"ambient_1","name":"Calm Ambient","duration":150,"mood":"relaxing","url":"#"},
    {"id":"corporate_1","name":"Corporate Inspire","duration":100,"mood":"professional","url":"#"},
]

# ─── Auth Endpoints ───────────────────────────────────────────────────────────
@api_router.post("/auth/register", response_model=UserResponse)
async def register(user: UserCreate):
    existing = await db.users.find_one({"email": user.email}, {"_id": 0})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    user_obj = User(email=user.email, password=user.password)
    doc = user_obj.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    await db.users.insert_one(doc)
    return UserResponse(**{k: v for k, v in user_obj.model_dump().items() if k in UserResponse.model_fields})

@api_router.post("/auth/login", response_model=UserResponse)
async def login(credentials: UserLogin):
    user_doc = await db.users.find_one({"email": credentials.email, "password": credentials.password}, {"_id": 0})
    if not user_doc:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    return UserResponse(**user_doc)

@api_router.get("/users/{user_id}", response_model=UserResponse)
async def get_user(user_id: str):
    user_doc = await db.users.find_one({"id": user_id}, {"_id": 0})
    if not user_doc:
        raise HTTPException(status_code=404, detail="User not found")
    return UserResponse(**user_doc)

@api_router.put("/users/{user_id}/brand-kit", response_model=UserResponse)
async def update_brand_kit(user_id: str, brand_kit: BrandKitUpdate):
    await db.users.update_one({"id": user_id}, {"$set": {"brand_kit": brand_kit.model_dump(exclude_none=True)}})
    user_doc = await db.users.find_one({"id": user_id}, {"_id": 0})
    if not user_doc:
        raise HTTPException(status_code=404, detail="User not found")
    return UserResponse(**user_doc)

@api_router.put("/users/{user_id}/onboarding")
async def complete_onboarding(user_id: str):
    await db.users.update_one({"id": user_id}, {"$set": {"onboarding_completed": True}})
    return {"message": "Onboarding completed"}

@api_router.put("/users/{user_id}/preferences")
async def update_preferences(user_id: str, preferences: Dict[str, Any]):
    await db.users.update_one({"id": user_id}, {"$set": {"preferences": preferences}})
    return {"message": "Preferences updated"}

# ─── Template Endpoints ───────────────────────────────────────────────────────
@api_router.get("/templates", response_model=List[Template])
async def get_templates(type: Optional[str] = None, category: Optional[str] = None):
    templates = BUILT_IN_TEMPLATES
    if type:
        templates = [t for t in templates if t["type"] == type]
    if category:
        templates = [t for t in templates if t.get("category") == category]
    return templates

@api_router.get("/templates/categories")
async def get_template_categories():
    categories = sorted(set(t.get("category", "") for t in BUILT_IN_TEMPLATES if t.get("category")))
    return {"categories": categories}

@api_router.get("/music/library")
async def get_music_library(mood: Optional[str] = None):
    tracks = [t for t in MUSIC_LIBRARY if not mood or t["mood"] == mood]
    return {"tracks": tracks}

# ─── Project Endpoints ────────────────────────────────────────────────────────
@api_router.get("/projects", response_model=List[Project])
async def get_projects(user_id: str, is_draft: Optional[bool] = None):
    query = {"user_id": user_id}
    if is_draft is not None:
        query["is_draft"] = is_draft
    projects = await db.projects.find(query, {"_id": 0}).sort("created_at", -1).to_list(100)
    for p in projects:
        if isinstance(p.get('created_at'), str):
            p['created_at'] = datetime.fromisoformat(p['created_at'])
    return projects

@api_router.post("/projects")
async def create_project_endpoint(request: dict):
    project_id = str(uuid.uuid4())
    project_data = {
        "id": project_id,
        "user_id": request.get("user_id"),
        "type": request.get("type"),
        "title": request.get("title", "Untitled"),
        "status": request.get("status", "completed"),
        "lifecycle_status": request.get("lifecycle_status", "produced"),
        "metadata": request.get("metadata", {}),
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.projects.insert_one(project_data)
    return {"success": True, "project_id": project_id}

@api_router.get("/projects/{project_id}", response_model=Project)
async def get_project(project_id: str):
    project = await db.projects.find_one({"id": project_id}, {"_id": 0})
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    if isinstance(project.get('created_at'), str):
        project['created_at'] = datetime.fromisoformat(project['created_at'])
    return Project(**project)

@api_router.patch("/projects/{project_id}/status")
async def update_project_status(project_id: str, request: dict):
    await db.projects.update_one({"id": project_id}, {"$set": {"lifecycle_status": request.get("status")}})
    return {"success": True}

@api_router.delete("/projects/{project_id}")
async def delete_project(project_id: str):
    result = await db.projects.delete_one({"id": project_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Project not found")
    return {"message": "Project deleted"}

@api_router.post("/projects/bulk-delete")
async def bulk_delete_projects(project_ids: List[str]):
    result = await db.projects.delete_many({"id": {"$in": project_ids}})
    return {"deleted_count": result.deleted_count}

@api_router.put("/projects/{project_id}/analytics")
async def update_project_analytics(project_id: str, analytics: Dict[str, Any]):
    await db.projects.update_one({"id": project_id}, {"$set": {"analytics": analytics, "updated_at": datetime.now(timezone.utc).isoformat()}})
    return {"message": "Analytics updated"}

@api_router.get("/analytics/{user_id}")
async def get_analytics(user_id: str):
    projects = await db.projects.find({"user_id": user_id}, {"_id": 0}).to_list(1000)
    total = len(projects)
    completed = len([p for p in projects if p.get("status") == "completed"])
    failed = len([p for p in projects if p.get("status") == "failed"])
    by_type = {}
    for p in projects:
        ptype = p.get("type", "unknown")
        by_type[ptype] = by_type.get(ptype, 0) + 1
    return {"total_projects": total, "completed": completed, "failed": failed, "by_type": by_type}

# ─── WebSocket ────────────────────────────────────────────────────────────────
@app.websocket("/ws/{user_id}")
async def websocket_endpoint(websocket: WebSocket, user_id: str):
    await manager.connect(websocket, user_id)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(user_id)

# ─── Script Generation (GPT-4o) ────────────────────────────────────────────────
@api_router.post("/script/generate")
async def generate_script(request: dict):
    try:
        topic = request.get("topic", "")
        hook_style = request.get("hook_style", "Problem → Solution")
        format_type = request.get("format", "Shorts (45s)")
        platform = request.get("platform", "YouTube Shorts")
        language = request.get("language", "English")

        system = "You are an expert content strategist and scriptwriter specializing in viral YouTube and social media content. Focus on India-specific context when relevant."

        # Generate hooks
        hooks_resp = await openai_client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": f"""Generate 3 hook variants for a {format_type} video about "{topic}".
Hook style: {hook_style} | Platform: {platform} | Language: {language}
Punchy, attention-grabbing, first 3 seconds, conversational.
Return ONLY JSON array:
[{{"variant":1,"hook":"..."}},{{"variant":2,"hook":"..."}},{{"variant":3,"hook":"..."}}]"""}
            ],
            temperature=0.8
        )
        hooks = hooks_resp.choices[0].message.content

        # Generate full script
        script_resp = await openai_client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": f"""Write a complete SCENE-BASED {format_type} script for {platform} about "{topic}".
Language: {language} | Hook style: {hook_style}

Requirements:
- Natural, conversational tone
- Hook in first 3 seconds
- Total: 45-60 seconds
- Use "you" language, short sentences
- India context where relevant (₹ currency, local examples)

Format:
SCENE 1: HOOK (0-3s)
[Hook]
Visual: [description]

SCENE 2: SETUP (3-10s)
[Content]
Visual: [description]

SCENE 3: VALUE (10-30s)
[Main content]
Visual: [description]

SCENE 4: PROOF (30-45s)
[Supporting content]
Visual: [description]

SCENE 5: CTA (45-60s)
[Call to action]
Visual: [description]"""}
            ],
            temperature=0.7
        )
        script = script_resp.choices[0].message.content

        # Generate caption
        caption_resp = await openai_client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": f'Write a short {platform} caption for a video about "{topic}". 1-2 sentences, 3-5 hashtags, CTA. Language: {language}. Return only the caption.'}
            ],
            temperature=0.7
        )
        caption = caption_resp.choices[0].message.content

        return {
            "success": True,
            "hooks": hooks,
            "script": script,
            "caption": caption,
            "metadata": {"topic": topic, "hook_style": hook_style, "format": format_type, "platform": platform, "language": language}
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Script generation failed: {str(e)}")

# ─── Image Generation (DALL-E 3) ──────────────────────────────────────────────
@api_router.post("/generate/image")
async def generate_ai_image(request: dict):
    try:
        prompt = request.get("prompt", "")
        style = request.get("style", "natural")
        aspect_ratio = request.get("aspect_ratio", "1:1")

        size_map = {"1:1": "1024x1024", "16:9": "1792x1024", "9:16": "1024x1792", "4:5": "1024x1024"}
        size = size_map.get(aspect_ratio, "1024x1024")

        style_map = {
            "cinematic": "cinematic lighting, film grain, dramatic composition",
            "photoreal": "hyper-realistic, professional photography, high detail",
            "product": "product photography, clean background, studio lighting, commercial",
            "illustration": "digital illustration, artistic, vibrant colors",
            "minimal": "minimalist design, clean, simple composition",
        }
        enhanced_prompt = f"{prompt}, {style_map.get(style, 'high quality, professional')}"

        response = await openai_client.images.generate(
            model="dall-e-3",
            prompt=enhanced_prompt,
            size=size,
            quality="standard",
            response_format="b64_json",
            n=1
        )

        image_base64 = response.data[0].b64_json
        return {"success": True, "image_base64": image_base64, "prompt": enhanced_prompt, "style": style, "aspect_ratio": aspect_ratio}

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Image generation failed: {str(e)}")

# ─── Voice Generation (TTS) ───────────────────────────────────────────────────
@api_router.post("/generate/voice")
async def generate_ai_voice(request: dict):
    try:
        text = request.get("text", "")
        voice = request.get("voice", "alloy")
        speed = request.get("speed", 1.0)

        response = await openai_client.audio.speech.create(
            model="tts-1",
            voice=voice,
            input=text,
            speed=speed
        )

        audio_bytes = response.content
        audio_base64 = base64.b64encode(audio_bytes).decode('utf-8')
        return {"success": True, "audio_base64": audio_base64, "text": text, "voice": voice, "speed": speed}

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Voice generation failed: {str(e)}")

# ─── Voiceover (Project-based) ────────────────────────────────────────────────
@api_router.post("/voiceover/generate")
async def generate_voiceover(request: VoiceoverGenerateRequest):
    user = await db.users.find_one({"id": request.user_id}, {"_id": 0})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    project = Project(
        user_id=request.user_id,
        type="voiceover",
        title=f"Voiceover - {request.text[:30]}...",
        status="generating",
        metadata={"text": request.text, "voice": request.voice}
    )
    doc = project.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    await db.projects.insert_one(doc)

    try:
        response = await openai_client.audio.speech.create(
            model=request.model,
            voice=request.voice,
            input=request.text,
            speed=request.speed
        )
        audio_base64 = base64.b64encode(response.content).decode('utf-8')
        await db.projects.update_one({"id": project.id}, {"$set": {"status": "completed", "output_base64": audio_base64}})
        return {"project_id": project.id, "status": "completed", "audio_base64": audio_base64}
    except Exception as e:
        await db.projects.update_one({"id": project.id}, {"$set": {"status": "failed"}})
        raise HTTPException(status_code=500, detail=str(e))

# ─── Image Generation (Project-based) ────────────────────────────────────────
@api_router.post("/image/generate")
async def generate_image(request: ImageGenerateRequest):
    user = await db.users.find_one({"id": request.user_id}, {"_id": 0})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    template = next((t for t in BUILT_IN_TEMPLATES if t["id"] == request.template), None)
    if not template or template["type"] != "image":
        raise HTTPException(status_code=404, detail="Template not found")

    project = Project(
        user_id=request.user_id,
        type="image",
        title=f"{template['name']} - {request.product_type}",
        status="generating",
        metadata={"template": request.template, "product_type": request.product_type}
    )
    doc = project.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    await db.projects.insert_one(doc)
    asyncio.create_task(generate_image_async(request, template, project))
    return {"project_id": project.id, "status": "generating"}

async def generate_image_async(request: ImageGenerateRequest, template: dict, project: Project):
    try:
        await manager.send_progress(request.user_id, {"type": "progress", "project_id": project.id, "progress": 20, "message": "Generating image..."})
        prompt = template["prompt_template"].format(product_type=request.product_type, model_style=request.model_style, scene=request.scene)
        response = await openai_client.images.generate(model="dall-e-3", prompt=prompt, size="1024x1024", quality="standard", response_format="b64_json", n=1)
        image_base64 = response.data[0].b64_json
        await db.projects.update_one({"id": project.id}, {"$set": {"status": "completed", "progress": 100, "output_base64": image_base64}})
        await manager.send_progress(request.user_id, {"type": "complete", "project_id": project.id, "progress": 100})
    except Exception as e:
        await db.projects.update_one({"id": project.id}, {"$set": {"status": "failed"}})
        await manager.send_progress(request.user_id, {"type": "error", "project_id": project.id, "message": str(e)})

# ─── Video Assembly (FFmpeg) ──────────────────────────────────────────────────
@api_router.post("/video/assemble")
async def assemble_video(request: dict):
    try:
        scenes = request.get("scenes", [])
        audio_base64 = request.get("audio_base64")
        fps = request.get("fps", 30)

        if not scenes:
            raise HTTPException(status_code=400, detail="No scenes provided")

        with tempfile.TemporaryDirectory() as tmpdir:
            image_files, durations = [], []
            for i, scene in enumerate(scenes):
                img_path = os.path.join(tmpdir, f"scene_{i:04d}.png")
                with open(img_path, "wb") as f:
                    f.write(base64.b64decode(scene.get("image_base64", "")))
                image_files.append(img_path)
                durations.append(scene.get("duration", 5))

            concat_path = os.path.join(tmpdir, "concat.txt")
            with open(concat_path, "w") as f:
                for img_path, duration in zip(image_files, durations):
                    f.write(f"file '{img_path}'\nduration {duration}\n")
                f.write(f"file '{image_files[-1]}'\n")

            output_path = os.path.join(tmpdir, "output.mp4")
            cmd = ["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", concat_path, "-vf", f"fps={fps},format=yuv420p", "-c:v", "libx264", "-preset", "fast", "-crf", "23"]

            if audio_base64:
                audio_path = os.path.join(tmpdir, "audio.mp3")
                with open(audio_path, "wb") as f:
                    f.write(base64.b64decode(audio_base64))
                cmd.extend(["-i", audio_path, "-c:a", "aac", "-shortest"])

            cmd.append(output_path)
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)

            if result.returncode != 0:
                raise Exception(f"FFmpeg error: {result.stderr}")

            with open(output_path, "rb") as f:
                video_base64 = base64.b64encode(f.read()).decode('utf-8')

            return {"success": True, "video_base64": video_base64, "scene_count": len(scenes), "total_duration": sum(durations), "has_audio": bool(audio_base64)}

    except subprocess.TimeoutExpired:
        raise HTTPException(status_code=500, detail="Video assembly timed out")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Video assembly failed: {str(e)}")

# ─── Music (placeholder) ──────────────────────────────────────────────────────
@api_router.post("/generate/music")
async def generate_music(request: dict):
    raise HTTPException(status_code=501, detail="Music generation: Use Suno.ai directly or upload your own MP3 files.")

# ─── Health Check ─────────────────────────────────────────────────────────────
@api_router.get("/health")
async def health():
    return {"status": "ok", "service": "Digital Catalyzt API"}

# ─── App Setup ────────────────────────────────────────────────────────────────
app.include_router(api_router)
app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
