# DIGITAL CATALYZT — Complete Production Setup

## What's Inside
```
digitalcatalyst_production/
├── backend/
│   ├── server.py          ← FastAPI backend (FIXED — no Emergent dependency)
│   ├── requirements.txt   ← Python packages needed
│   └── .env.example       ← Copy to .env and fill in your keys
├── frontend/
│   ├── src/               ← All React components (20 pages)
│   ├── public/            ← index.html
│   ├── package.json       ← Node dependencies
│   ├── tailwind.config.js
│   ├── craco.config.js
│   └── .env.example       ← Copy to .env
└── README.md              ← This file
```

---

## STEP 1 — Get Your API Keys (Free tiers available)

### OpenAI API Key (REQUIRED)
1. Go to https://platform.openai.com/api-keys
2. Click "Create new secret key"
3. Copy it — looks like: `sk-proj-...`
4. Free credits: $5 when you sign up

### MongoDB (REQUIRED — Free)
**Option A: MongoDB Atlas (Easiest, Free)**
1. Go to https://cloud.mongodb.com
2. Sign up → Create free cluster (M0 Free Tier)
3. Get connection string — looks like:
   `mongodb+srv://username:password@cluster.mongodb.net`

**Option B: Local MongoDB**
```bash
# Mac
brew install mongodb-community
brew services start mongodb-community

# Connection string: mongodb://localhost:27017
```

---

## STEP 2 — Setup Backend

```bash
cd backend

# Create .env file
cp .env.example .env

# Edit .env with your values:
# MONGO_URL=mongodb+srv://user:pass@cluster.mongodb.net
# DB_NAME=digital_catalyzt
# OPENAI_API_KEY=sk-proj-your-key-here
# CORS_ORIGINS=http://localhost:3000

# Install Python dependencies
pip install -r requirements.txt

# Install FFmpeg (for video assembly)
# Mac:
brew install ffmpeg
# Ubuntu/Linux:
sudo apt install ffmpeg

# Start the backend
uvicorn server:app --host 0.0.0.0 --port 8001 --reload
```

✅ Backend runs at: http://localhost:8001
✅ API docs at: http://localhost:8001/docs

---

## STEP 3 — Setup Frontend

```bash
cd frontend

# Create .env file
cp .env.example .env
# Edit: REACT_APP_BACKEND_URL=http://localhost:8001

# Install Node dependencies (requires Node 18+)
npm install
# OR if you have yarn:
yarn install

# Start the frontend
npm start
# OR:
yarn start
```

✅ App runs at: http://localhost:3000

---

## STEP 4 — Deploy to Cloud (Free Hosting)

### Deploy Backend → Railway (Free)
1. Go to https://railway.app → Login with GitHub
2. "New Project" → "Deploy from GitHub repo"
3. Add environment variables in Railway dashboard:
   - MONGO_URL
   - DB_NAME
   - OPENAI_API_KEY
   - CORS_ORIGINS=https://your-frontend.vercel.app
4. Railway auto-detects Python and deploys

### Deploy Frontend → Vercel (Free)
1. Go to https://vercel.com → Login with GitHub
2. "New Project" → Import your repo
3. Add environment variable:
   - REACT_APP_BACKEND_URL=https://your-backend.railway.app
4. Vercel auto-detects React and deploys

---

## What Each Feature Uses

| Feature | API Used | Cost |
|---|---|---|
| Script Generation | OpenAI GPT-4o-mini | ~$0.001/script |
| Image Generation | DALL-E 3 | ~$0.04/image |
| Voice Generation | OpenAI TTS | ~$0.015/1K chars |
| Video Assembly | FFmpeg (local) | FREE |
| All other features | Claude AI (this tool) | FREE |

---

## Troubleshooting

**"Module not found" error:**
```bash
pip install -r requirements.txt
```

**CORS error in browser:**
- Check CORS_ORIGINS in backend .env includes your frontend URL

**MongoDB connection error:**
- Check your MONGO_URL is correct
- Make sure MongoDB is running or Atlas cluster is active

**FFmpeg not found:**
- Install FFmpeg: `brew install ffmpeg` (Mac) or `sudo apt install ffmpeg` (Linux)

**OpenAI quota error:**
- Add payment method at platform.openai.com (starts at $5)
- Check your API key is correct

---

## Support
Built with Claude AI — for issues, bring your questions to claude.ai
